jmp main

;===========Tela Amarela============

inicial_start : var #1200
  ;Linha 0
  static inicial_start + #0, #3967
  static inicial_start + #1, #3967
  static inicial_start + #2, #3967
  static inicial_start + #3, #3967
  static inicial_start + #4, #3967
  static inicial_start + #5, #3967
  static inicial_start + #6, #3967
  static inicial_start + #7, #3967
  static inicial_start + #8, #3967
  static inicial_start + #9, #3967
  static inicial_start + #10, #3967
  static inicial_start + #11, #3967
  static inicial_start + #12, #3967
  static inicial_start + #13, #3967
  static inicial_start + #14, #3967
  static inicial_start + #15, #3967
  static inicial_start + #16, #3967
  static inicial_start + #17, #3967
  static inicial_start + #18, #3967
  static inicial_start + #19, #3967
  static inicial_start + #20, #3967
  static inicial_start + #21, #3967
  static inicial_start + #22, #3967
  static inicial_start + #23, #3967
  static inicial_start + #24, #3967
  static inicial_start + #25, #3967
  static inicial_start + #26, #3967
  static inicial_start + #27, #3967
  static inicial_start + #28, #3967
  static inicial_start + #29, #3967
  static inicial_start + #30, #3967
  static inicial_start + #31, #3967
  static inicial_start + #32, #3967
  static inicial_start + #33, #3967
  static inicial_start + #34, #3967
  static inicial_start + #35, #3967
  static inicial_start + #36, #3967
  static inicial_start + #37, #3967
  static inicial_start + #38, #3967
  static inicial_start + #39, #3967

  ;Linha 1
  static inicial_start + #40, #3967
  static inicial_start + #41, #3967
  static inicial_start + #42, #3967
  static inicial_start + #43, #3967
  static inicial_start + #44, #3967
  static inicial_start + #45, #3967
  static inicial_start + #46, #3967
  static inicial_start + #47, #3967
  static inicial_start + #48, #3967
  static inicial_start + #49, #3967
  static inicial_start + #50, #70
  static inicial_start + #51, #101
  static inicial_start + #52, #105
  static inicial_start + #53, #116
  static inicial_start + #54, #111
  static inicial_start + #55, #3967
  static inicial_start + #56, #112
  static inicial_start + #57, #111
  static inicial_start + #58, #114
  static inicial_start + #59, #3967
  static inicial_start + #60, #72
  static inicial_start + #61, #101
  static inicial_start + #62, #108
  static inicial_start + #63, #101
  static inicial_start + #64, #110
  static inicial_start + #65, #97
  static inicial_start + #66, #3967
  static inicial_start + #67, #80
  static inicial_start + #68, #46
  static inicial_start + #69, #3967
  static inicial_start + #70, #3967
  static inicial_start + #71, #3967
  static inicial_start + #72, #3967
  static inicial_start + #73, #3967
  static inicial_start + #74, #3967
  static inicial_start + #75, #3967
  static inicial_start + #76, #3967
  static inicial_start + #77, #3967
  static inicial_start + #78, #3967
  static inicial_start + #79, #3967

  ;Linha 2
  static inicial_start + #80, #3967
  static inicial_start + #81, #3967
  static inicial_start + #82, #3967
  static inicial_start + #83, #3967
  static inicial_start + #84, #3967
  static inicial_start + #85, #3967
  static inicial_start + #86, #3967
  static inicial_start + #87, #3967
  static inicial_start + #88, #3967
  static inicial_start + #89, #3967
  static inicial_start + #90, #3967
  static inicial_start + #91, #3967
  static inicial_start + #92, #3967
  static inicial_start + #93, #3967
  static inicial_start + #94, #3967
  static inicial_start + #95, #82
  static inicial_start + #96, #101
  static inicial_start + #97, #110
  static inicial_start + #98, #97
  static inicial_start + #99, #110
  static inicial_start + #100, #3967
  static inicial_start + #101, #80
  static inicial_start + #102, #46
  static inicial_start + #103, #3967
  static inicial_start + #104, #3967
  static inicial_start + #105, #3967
  static inicial_start + #106, #3967
  static inicial_start + #107, #3967
  static inicial_start + #108, #3967
  static inicial_start + #109, #3967
  static inicial_start + #110, #3967
  static inicial_start + #111, #3967
  static inicial_start + #112, #3967
  static inicial_start + #113, #3967
  static inicial_start + #114, #3967
  static inicial_start + #115, #3967
  static inicial_start + #116, #3967
  static inicial_start + #117, #3967
  static inicial_start + #118, #3967
  static inicial_start + #119, #3967

  ;Linha 3
  static inicial_start + #120, #3967
  static inicial_start + #121, #3967
  static inicial_start + #122, #3967
  static inicial_start + #123, #3967
  static inicial_start + #124, #3967
  static inicial_start + #125, #3967
  static inicial_start + #126, #3967
  static inicial_start + #127, #3967
  static inicial_start + #128, #3967
  static inicial_start + #129, #3967
  static inicial_start + #130, #3967
  static inicial_start + #131, #3967
  static inicial_start + #132, #3967
  static inicial_start + #133, #3967
  static inicial_start + #134, #86
  static inicial_start + #135, #105
  static inicial_start + #136, #116
  static inicial_start + #137, #111
  static inicial_start + #138, #114
  static inicial_start + #139, #105
  static inicial_start + #140, #97
  static inicial_start + #141, #3967
  static inicial_start + #142, #66
  static inicial_start + #143, #46
  static inicial_start + #144, #3967
  static inicial_start + #145, #3967
  static inicial_start + #146, #3967
  static inicial_start + #147, #3967
  static inicial_start + #148, #3967
  static inicial_start + #149, #3967
  static inicial_start + #150, #3967
  static inicial_start + #151, #3967
  static inicial_start + #152, #3967
  static inicial_start + #153, #3967
  static inicial_start + #154, #3967
  static inicial_start + #155, #3967
  static inicial_start + #156, #3967
  static inicial_start + #157, #3967
  static inicial_start + #158, #3967
  static inicial_start + #159, #3967

  ;Linha 4
  static inicial_start + #160, #3967
  static inicial_start + #161, #3967
  static inicial_start + #162, #3967
  static inicial_start + #163, #3967
  static inicial_start + #164, #3967
  static inicial_start + #165, #3967
  static inicial_start + #166, #3967
  static inicial_start + #167, #3967
  static inicial_start + #168, #3967
  static inicial_start + #169, #3967
  static inicial_start + #170, #3967
  static inicial_start + #171, #3967
  static inicial_start + #172, #3967
  static inicial_start + #173, #3967
  static inicial_start + #174, #3967
  static inicial_start + #175, #3967
  static inicial_start + #176, #3967
  static inicial_start + #177, #3967
  static inicial_start + #178, #3967
  static inicial_start + #179, #3967
  static inicial_start + #180, #3967
  static inicial_start + #181, #3967
  static inicial_start + #182, #3967
  static inicial_start + #183, #3967
  static inicial_start + #184, #3967
  static inicial_start + #185, #3967
  static inicial_start + #186, #3967
  static inicial_start + #187, #3967
  static inicial_start + #188, #3967
  static inicial_start + #189, #3967
  static inicial_start + #190, #3967
  static inicial_start + #191, #3967
  static inicial_start + #192, #3967
  static inicial_start + #193, #3967
  static inicial_start + #194, #3967
  static inicial_start + #195, #3967
  static inicial_start + #196, #3967
  static inicial_start + #197, #3967
  static inicial_start + #198, #3967
  static inicial_start + #199, #3967

  ;Linha 5
  static inicial_start + #200, #3967
  static inicial_start + #201, #3967
  static inicial_start + #202, #3967
  static inicial_start + #203, #3967
  static inicial_start + #204, #3967
  static inicial_start + #205, #3967
  static inicial_start + #206, #3967
  static inicial_start + #207, #3967
  static inicial_start + #208, #3967
  static inicial_start + #209, #3967
  static inicial_start + #210, #3967
  static inicial_start + #211, #3967
  static inicial_start + #212, #3967
  static inicial_start + #213, #3967
  static inicial_start + #214, #3967
  static inicial_start + #215, #3967
  static inicial_start + #216, #3967
  static inicial_start + #217, #3967
  static inicial_start + #218, #3967
  static inicial_start + #219, #3967
  static inicial_start + #220, #3967
  static inicial_start + #221, #3967
  static inicial_start + #222, #3967
  static inicial_start + #223, #3967
  static inicial_start + #224, #3967
  static inicial_start + #225, #3967
  static inicial_start + #226, #3967
  static inicial_start + #227, #3967
  static inicial_start + #228, #3967
  static inicial_start + #229, #3967
  static inicial_start + #230, #3967
  static inicial_start + #231, #3967
  static inicial_start + #232, #3967
  static inicial_start + #233, #3967
  static inicial_start + #234, #3967
  static inicial_start + #235, #3967
  static inicial_start + #236, #3967
  static inicial_start + #237, #3967
  static inicial_start + #238, #3967
  static inicial_start + #239, #3967

  ;Linha 6
  static inicial_start + #240, #3967
  static inicial_start + #241, #2602
  static inicial_start + #242, #3967
  static inicial_start + #243, #3967
  static inicial_start + #244, #3967
  static inicial_start + #245, #3967
  static inicial_start + #246, #3967
  static inicial_start + #247, #3967
  static inicial_start + #248, #3967
  static inicial_start + #249, #3967
  static inicial_start + #250, #3967
  static inicial_start + #251, #3967
  static inicial_start + #252, #3967
  static inicial_start + #253, #3967
  static inicial_start + #254, #3967
  static inicial_start + #255, #3967
  static inicial_start + #256, #3967
  static inicial_start + #257, #3967
  static inicial_start + #258, #3967
  static inicial_start + #259, #3967
  static inicial_start + #260, #3967
  static inicial_start + #261, #3967
  static inicial_start + #262, #3967
  static inicial_start + #263, #3967
  static inicial_start + #264, #3967
  static inicial_start + #265, #3967
  static inicial_start + #266, #3967
  static inicial_start + #267, #3967
  static inicial_start + #268, #3967
  static inicial_start + #269, #3967
  static inicial_start + #270, #3967
  static inicial_start + #271, #3967
  static inicial_start + #272, #3967
  static inicial_start + #273, #3967
  static inicial_start + #274, #3967
  static inicial_start + #275, #3967
  static inicial_start + #276, #3967
  static inicial_start + #277, #3967
  static inicial_start + #278, #2858
  static inicial_start + #279, #3967

  ;Linha 7
  static inicial_start + #280, #3967
  static inicial_start + #281, #3967
  static inicial_start + #282, #3967
  static inicial_start + #283, #3967
  static inicial_start + #284, #3967
  static inicial_start + #285, #3967
  static inicial_start + #286, #3967
  static inicial_start + #287, #3967
  static inicial_start + #288, #3967
  static inicial_start + #289, #3967
  static inicial_start + #290, #3967
  static inicial_start + #291, #3967
  static inicial_start + #292, #3967
  static inicial_start + #293, #3967
  static inicial_start + #294, #3967
  static inicial_start + #295, #3967
  static inicial_start + #296, #3967
  static inicial_start + #297, #3967
  static inicial_start + #298, #3967
  static inicial_start + #299, #3967
  static inicial_start + #300, #3967
  static inicial_start + #301, #3967
  static inicial_start + #302, #3967
  static inicial_start + #303, #3967
  static inicial_start + #304, #3967
  static inicial_start + #305, #3967
  static inicial_start + #306, #3967
  static inicial_start + #307, #3967
  static inicial_start + #308, #3967
  static inicial_start + #309, #3967
  static inicial_start + #310, #3967
  static inicial_start + #311, #3967
  static inicial_start + #312, #3967
  static inicial_start + #313, #3967
  static inicial_start + #314, #3967
  static inicial_start + #315, #3967
  static inicial_start + #316, #3967
  static inicial_start + #317, #3967
  static inicial_start + #318, #3967
  static inicial_start + #319, #3967

  ;Linha 8
  static inicial_start + #320, #3967
  static inicial_start + #321, #3967
  static inicial_start + #322, #3967
  static inicial_start + #323, #3967
  static inicial_start + #324, #3967
  static inicial_start + #325, #3967
  static inicial_start + #326, #3967
  static inicial_start + #327, #3967
  static inicial_start + #328, #3967
  static inicial_start + #329, #3967
  static inicial_start + #330, #3967
  static inicial_start + #331, #3967
  static inicial_start + #332, #3967
  static inicial_start + #333, #3967
  static inicial_start + #334, #3967
  static inicial_start + #335, #3967
  static inicial_start + #336, #3967
  static inicial_start + #337, #3967
  static inicial_start + #338, #3967
  static inicial_start + #339, #3967
  static inicial_start + #340, #3967
  static inicial_start + #341, #3967
  static inicial_start + #342, #3967
  static inicial_start + #343, #3967
  static inicial_start + #344, #3967
  static inicial_start + #345, #3967
  static inicial_start + #346, #3967
  static inicial_start + #347, #3967
  static inicial_start + #348, #3967
  static inicial_start + #349, #3967
  static inicial_start + #350, #3967
  static inicial_start + #351, #3967
  static inicial_start + #352, #3967
  static inicial_start + #353, #3967
  static inicial_start + #354, #3967
  static inicial_start + #355, #3967
  static inicial_start + #356, #3967
  static inicial_start + #357, #3967
  static inicial_start + #358, #3967
  static inicial_start + #359, #3967

  ;Linha 9
  static inicial_start + #360, #3967
  static inicial_start + #361, #3967
  static inicial_start + #362, #3967
  static inicial_start + #363, #2816
  static inicial_start + #364, #2816
  static inicial_start + #365, #2816
  static inicial_start + #366, #2816
  static inicial_start + #367, #2848
  static inicial_start + #368, #2848
  static inicial_start + #369, #2848
  static inicial_start + #370, #2816
  static inicial_start + #371, #2816
  static inicial_start + #372, #2816
  static inicial_start + #373, #2816
  static inicial_start + #374, #2848
  static inicial_start + #375, #2848
  static inicial_start + #376, #2816
  static inicial_start + #377, #2848
  static inicial_start + #378, #3967
  static inicial_start + #379, #3967
  static inicial_start + #380, #2816
  static inicial_start + #381, #3967
  static inicial_start + #382, #3967
  static inicial_start + #383, #2816
  static inicial_start + #384, #3967
  static inicial_start + #385, #3967
  static inicial_start + #386, #2816
  static inicial_start + #387, #3967
  static inicial_start + #388, #3967
  static inicial_start + #389, #3967
  static inicial_start + #390, #2816
  static inicial_start + #391, #3967
  static inicial_start + #392, #3967
  static inicial_start + #393, #3967
  static inicial_start + #394, #2816
  static inicial_start + #395, #2816
  static inicial_start + #396, #2816
  static inicial_start + #397, #3967
  static inicial_start + #398, #3967
  static inicial_start + #399, #3967

  ;Linha 10
  static inicial_start + #400, #3967
  static inicial_start + #401, #3967
  static inicial_start + #402, #2816
  static inicial_start + #403, #3967
  static inicial_start + #404, #3967
  static inicial_start + #405, #2848
  static inicial_start + #406, #3967
  static inicial_start + #407, #2816
  static inicial_start + #408, #3967
  static inicial_start + #409, #2848
  static inicial_start + #410, #2816
  static inicial_start + #411, #2848
  static inicial_start + #412, #2848
  static inicial_start + #413, #2848
  static inicial_start + #414, #3967
  static inicial_start + #415, #3967
  static inicial_start + #416, #2816
  static inicial_start + #417, #2816
  static inicial_start + #418, #3967
  static inicial_start + #419, #3967
  static inicial_start + #420, #2816
  static inicial_start + #421, #3967
  static inicial_start + #422, #3967
  static inicial_start + #423, #2816
  static inicial_start + #424, #3967
  static inicial_start + #425, #3967
  static inicial_start + #426, #2816
  static inicial_start + #427, #3967
  static inicial_start + #428, #3967
  static inicial_start + #429, #3967
  static inicial_start + #430, #2816
  static inicial_start + #431, #3967
  static inicial_start + #432, #3967
  static inicial_start + #433, #2816
  static inicial_start + #434, #3967
  static inicial_start + #435, #3967
  static inicial_start + #436, #3967
  static inicial_start + #437, #2816
  static inicial_start + #438, #3967
  static inicial_start + #439, #3967

  ;Linha 11
  static inicial_start + #440, #3967
  static inicial_start + #441, #3967
  static inicial_start + #442, #2816
  static inicial_start + #443, #3967
  static inicial_start + #444, #3967
  static inicial_start + #445, #2848
  static inicial_start + #446, #3967
  static inicial_start + #447, #3967
  static inicial_start + #448, #3967
  static inicial_start + #449, #3967
  static inicial_start + #450, #2816
  static inicial_start + #451, #3967
  static inicial_start + #452, #2848
  static inicial_start + #453, #2848
  static inicial_start + #454, #3967
  static inicial_start + #455, #3967
  static inicial_start + #456, #2816
  static inicial_start + #457, #2848
  static inicial_start + #458, #2816
  static inicial_start + #459, #3967
  static inicial_start + #460, #2816
  static inicial_start + #461, #3967
  static inicial_start + #462, #3967
  static inicial_start + #463, #2816
  static inicial_start + #464, #3967
  static inicial_start + #465, #3967
  static inicial_start + #466, #2816
  static inicial_start + #467, #3967
  static inicial_start + #468, #3967
  static inicial_start + #469, #2848
  static inicial_start + #470, #2816
  static inicial_start + #471, #3967
  static inicial_start + #472, #3967
  static inicial_start + #473, #2816
  static inicial_start + #474, #3967
  static inicial_start + #475, #3967
  static inicial_start + #476, #3967
  static inicial_start + #477, #3967
  static inicial_start + #478, #3967
  static inicial_start + #479, #3967

  ;Linha 12
  static inicial_start + #480, #3967
  static inicial_start + #481, #3967
  static inicial_start + #482, #2816
  static inicial_start + #483, #3967
  static inicial_start + #484, #3967
  static inicial_start + #485, #2848
  static inicial_start + #486, #3967
  static inicial_start + #487, #3967
  static inicial_start + #488, #3967
  static inicial_start + #489, #3967
  static inicial_start + #490, #2816
  static inicial_start + #491, #2848
  static inicial_start + #492, #2848
  static inicial_start + #493, #2848
  static inicial_start + #494, #2848
  static inicial_start + #495, #2848
  static inicial_start + #496, #2816
  static inicial_start + #497, #3967
  static inicial_start + #498, #2848
  static inicial_start + #499, #2816
  static inicial_start + #500, #2816
  static inicial_start + #501, #3967
  static inicial_start + #502, #3967
  static inicial_start + #503, #2816
  static inicial_start + #504, #3967
  static inicial_start + #505, #3967
  static inicial_start + #506, #2816
  static inicial_start + #507, #3967
  static inicial_start + #508, #3967
  static inicial_start + #509, #2848
  static inicial_start + #510, #2816
  static inicial_start + #511, #3967
  static inicial_start + #512, #3967
  static inicial_start + #513, #2816
  static inicial_start + #514, #3967
  static inicial_start + #515, #3967
  static inicial_start + #516, #3967
  static inicial_start + #517, #3967
  static inicial_start + #518, #3967
  static inicial_start + #519, #3967

  ;Linha 13
  static inicial_start + #520, #3967
  static inicial_start + #521, #3967
  static inicial_start + #522, #2816
  static inicial_start + #523, #3967
  static inicial_start + #524, #3967
  static inicial_start + #525, #2848
  static inicial_start + #526, #3967
  static inicial_start + #527, #2848
  static inicial_start + #528, #2848
  static inicial_start + #529, #2848
  static inicial_start + #530, #2816
  static inicial_start + #531, #2816
  static inicial_start + #532, #2816
  static inicial_start + #533, #2848
  static inicial_start + #534, #2848
  static inicial_start + #535, #2848
  static inicial_start + #536, #2816
  static inicial_start + #537, #3967
  static inicial_start + #538, #2848
  static inicial_start + #539, #2848
  static inicial_start + #540, #2816
  static inicial_start + #541, #3967
  static inicial_start + #542, #3967
  static inicial_start + #543, #2816
  static inicial_start + #544, #3967
  static inicial_start + #545, #3967
  static inicial_start + #546, #2816
  static inicial_start + #547, #3967
  static inicial_start + #548, #3967
  static inicial_start + #549, #3967
  static inicial_start + #550, #2816
  static inicial_start + #551, #3967
  static inicial_start + #552, #3967
  static inicial_start + #553, #3967
  static inicial_start + #554, #2816
  static inicial_start + #555, #2816
  static inicial_start + #556, #2816
  static inicial_start + #557, #3967
  static inicial_start + #558, #3967
  static inicial_start + #559, #3967

  ;Linha 14
  static inicial_start + #560, #3967
  static inicial_start + #561, #3967
  static inicial_start + #562, #2816
  static inicial_start + #563, #3967
  static inicial_start + #564, #3967
  static inicial_start + #565, #2816
  static inicial_start + #566, #2816
  static inicial_start + #567, #2816
  static inicial_start + #568, #3967
  static inicial_start + #569, #2848
  static inicial_start + #570, #2816
  static inicial_start + #571, #3967
  static inicial_start + #572, #3967
  static inicial_start + #573, #2848
  static inicial_start + #574, #3967
  static inicial_start + #575, #3967
  static inicial_start + #576, #2816
  static inicial_start + #577, #3967
  static inicial_start + #578, #3967
  static inicial_start + #579, #3967
  static inicial_start + #580, #2816
  static inicial_start + #581, #3967
  static inicial_start + #582, #3967
  static inicial_start + #583, #2816
  static inicial_start + #584, #3967
  static inicial_start + #585, #3967
  static inicial_start + #586, #2816
  static inicial_start + #587, #3967
  static inicial_start + #588, #3967
  static inicial_start + #589, #3967
  static inicial_start + #590, #2816
  static inicial_start + #591, #3967
  static inicial_start + #592, #3967
  static inicial_start + #593, #3967
  static inicial_start + #594, #3967
  static inicial_start + #595, #3967
  static inicial_start + #596, #3967
  static inicial_start + #597, #2816
  static inicial_start + #598, #3967
  static inicial_start + #599, #3967

  ;Linha 15
  static inicial_start + #600, #3967
  static inicial_start + #601, #3967
  static inicial_start + #602, #2816
  static inicial_start + #603, #3967
  static inicial_start + #604, #3967
  static inicial_start + #605, #2848
  static inicial_start + #606, #3967
  static inicial_start + #607, #2816
  static inicial_start + #608, #2848
  static inicial_start + #609, #2848
  static inicial_start + #610, #2816
  static inicial_start + #611, #2848
  static inicial_start + #612, #2848
  static inicial_start + #613, #2848
  static inicial_start + #614, #2848
  static inicial_start + #615, #2848
  static inicial_start + #616, #2816
  static inicial_start + #617, #3967
  static inicial_start + #618, #3967
  static inicial_start + #619, #2848
  static inicial_start + #620, #2816
  static inicial_start + #621, #3967
  static inicial_start + #622, #3967
  static inicial_start + #623, #2816
  static inicial_start + #624, #3967
  static inicial_start + #625, #3967
  static inicial_start + #626, #2816
  static inicial_start + #627, #3967
  static inicial_start + #628, #3967
  static inicial_start + #629, #3967
  static inicial_start + #630, #2816
  static inicial_start + #631, #3967
  static inicial_start + #632, #3967
  static inicial_start + #633, #3967
  static inicial_start + #634, #3967
  static inicial_start + #635, #3967
  static inicial_start + #636, #3967
  static inicial_start + #637, #2816
  static inicial_start + #638, #3967
  static inicial_start + #639, #3967

  ;Linha 16
  static inicial_start + #640, #3967
  static inicial_start + #641, #3967
  static inicial_start + #642, #2816
  static inicial_start + #643, #3967
  static inicial_start + #644, #3967
  static inicial_start + #645, #2848
  static inicial_start + #646, #2848
  static inicial_start + #647, #2816
  static inicial_start + #648, #2848
  static inicial_start + #649, #2848
  static inicial_start + #650, #2816
  static inicial_start + #651, #2848
  static inicial_start + #652, #2848
  static inicial_start + #653, #2848
  static inicial_start + #654, #2848
  static inicial_start + #655, #2848
  static inicial_start + #656, #2816
  static inicial_start + #657, #2848
  static inicial_start + #658, #3967
  static inicial_start + #659, #3967
  static inicial_start + #660, #2816
  static inicial_start + #661, #3967
  static inicial_start + #662, #3967
  static inicial_start + #663, #2816
  static inicial_start + #664, #3967
  static inicial_start + #665, #3967
  static inicial_start + #666, #2816
  static inicial_start + #667, #3967
  static inicial_start + #668, #3967
  static inicial_start + #669, #3967
  static inicial_start + #670, #2816
  static inicial_start + #671, #3967
  static inicial_start + #672, #2848
  static inicial_start + #673, #2816
  static inicial_start + #674, #3967
  static inicial_start + #675, #3967
  static inicial_start + #676, #3967
  static inicial_start + #677, #2816
  static inicial_start + #678, #3967
  static inicial_start + #679, #3967

  ;Linha 17
  static inicial_start + #680, #3967
  static inicial_start + #681, #3967
  static inicial_start + #682, #3967
  static inicial_start + #683, #2816
  static inicial_start + #684, #2816
  static inicial_start + #685, #2816
  static inicial_start + #686, #2816
  static inicial_start + #687, #2848
  static inicial_start + #688, #3967
  static inicial_start + #689, #3967
  static inicial_start + #690, #2816
  static inicial_start + #691, #2816
  static inicial_start + #692, #2816
  static inicial_start + #693, #2816
  static inicial_start + #694, #2848
  static inicial_start + #695, #2848
  static inicial_start + #696, #2816
  static inicial_start + #697, #3967
  static inicial_start + #698, #3967
  static inicial_start + #699, #3967
  static inicial_start + #700, #2816
  static inicial_start + #701, #3967
  static inicial_start + #702, #3967
  static inicial_start + #703, #2816
  static inicial_start + #704, #3967
  static inicial_start + #705, #3967
  static inicial_start + #706, #3967
  static inicial_start + #707, #2816
  static inicial_start + #708, #2816
  static inicial_start + #709, #2816
  static inicial_start + #710, #3967
  static inicial_start + #711, #3967
  static inicial_start + #712, #3967
  static inicial_start + #713, #2848
  static inicial_start + #714, #2816
  static inicial_start + #715, #2816
  static inicial_start + #716, #2816
  static inicial_start + #717, #3967
  static inicial_start + #718, #3967
  static inicial_start + #719, #3967

  ;Linha 18
  static inicial_start + #720, #3967
  static inicial_start + #721, #3967
  static inicial_start + #722, #3967
  static inicial_start + #723, #3967
  static inicial_start + #724, #3967
  static inicial_start + #725, #3967
  static inicial_start + #726, #3967
  static inicial_start + #727, #3967
  static inicial_start + #728, #3967
  static inicial_start + #729, #3967
  static inicial_start + #730, #2848
  static inicial_start + #731, #3967
  static inicial_start + #732, #3967
  static inicial_start + #733, #3967
  static inicial_start + #734, #3967
  static inicial_start + #735, #3967
  static inicial_start + #736, #3967
  static inicial_start + #737, #3967
  static inicial_start + #738, #3967
  static inicial_start + #739, #3967
  static inicial_start + #740, #3967
  static inicial_start + #741, #3967
  static inicial_start + #742, #3967
  static inicial_start + #743, #3967
  static inicial_start + #744, #3967
  static inicial_start + #745, #3967
  static inicial_start + #746, #3967
  static inicial_start + #747, #3967
  static inicial_start + #748, #3967
  static inicial_start + #749, #3967
  static inicial_start + #750, #3967
  static inicial_start + #751, #3967
  static inicial_start + #752, #3967
  static inicial_start + #753, #3967
  static inicial_start + #754, #3967
  static inicial_start + #755, #3967
  static inicial_start + #756, #3967
  static inicial_start + #757, #3967
  static inicial_start + #758, #3967
  static inicial_start + #759, #3967

  ;Linha 19
  static inicial_start + #760, #3967
  static inicial_start + #761, #3967
  static inicial_start + #762, #3967
  static inicial_start + #763, #3967
  static inicial_start + #764, #3967
  static inicial_start + #765, #3967
  static inicial_start + #766, #3967
  static inicial_start + #767, #3967
  static inicial_start + #768, #3967
  static inicial_start + #769, #3967
  static inicial_start + #770, #3967
  static inicial_start + #771, #3967
  static inicial_start + #772, #3967
  static inicial_start + #773, #3967
  static inicial_start + #774, #3967
  static inicial_start + #775, #3967
  static inicial_start + #776, #3967
  static inicial_start + #777, #3967
  static inicial_start + #778, #3967
  static inicial_start + #779, #3967
  static inicial_start + #780, #3967
  static inicial_start + #781, #3967
  static inicial_start + #782, #3967
  static inicial_start + #783, #3967
  static inicial_start + #784, #3967
  static inicial_start + #785, #3967
  static inicial_start + #786, #3967
  static inicial_start + #787, #3967
  static inicial_start + #788, #3967
  static inicial_start + #789, #3967
  static inicial_start + #790, #3967
  static inicial_start + #791, #3967
  static inicial_start + #792, #3967
  static inicial_start + #793, #3967
  static inicial_start + #794, #3967
  static inicial_start + #795, #3967
  static inicial_start + #796, #3967
  static inicial_start + #797, #3967
  static inicial_start + #798, #3967
  static inicial_start + #799, #3967

  ;Linha 20
  static inicial_start + #800, #3967
  static inicial_start + #801, #2346
  static inicial_start + #802, #3967
  static inicial_start + #803, #3967
  static inicial_start + #804, #3967
  static inicial_start + #805, #3967
  static inicial_start + #806, #3967
  static inicial_start + #807, #3967
  static inicial_start + #808, #3967
  static inicial_start + #809, #3967
  static inicial_start + #810, #3967
  static inicial_start + #811, #3967
  static inicial_start + #812, #3967
  static inicial_start + #813, #3967
  static inicial_start + #814, #3967
  static inicial_start + #815, #3967
  static inicial_start + #816, #3967
  static inicial_start + #817, #3967
  static inicial_start + #818, #3967
  static inicial_start + #819, #3967
  static inicial_start + #820, #3967
  static inicial_start + #821, #3967
  static inicial_start + #822, #3967
  static inicial_start + #823, #3967
  static inicial_start + #824, #3967
  static inicial_start + #825, #3967
  static inicial_start + #826, #3967
  static inicial_start + #827, #3967
  static inicial_start + #828, #3967
  static inicial_start + #829, #3967
  static inicial_start + #830, #3967
  static inicial_start + #831, #3967
  static inicial_start + #832, #3967
  static inicial_start + #833, #3967
  static inicial_start + #834, #3967
  static inicial_start + #835, #3967
  static inicial_start + #836, #3967
  static inicial_start + #837, #3967
  static inicial_start + #838, #3114
  static inicial_start + #839, #3967

  ;Linha 21
  static inicial_start + #840, #3967
  static inicial_start + #841, #3967
  static inicial_start + #842, #3967
  static inicial_start + #843, #3967
  static inicial_start + #844, #3967
  static inicial_start + #845, #3967
  static inicial_start + #846, #3967
  static inicial_start + #847, #3967
  static inicial_start + #848, #3967
  static inicial_start + #849, #3967
  static inicial_start + #850, #3967
  static inicial_start + #851, #3967
  static inicial_start + #852, #3967
  static inicial_start + #853, #3967
  static inicial_start + #854, #3967
  static inicial_start + #855, #3967
  static inicial_start + #856, #3967
  static inicial_start + #857, #3967
  static inicial_start + #858, #3967
  static inicial_start + #859, #3967
  static inicial_start + #860, #3967
  static inicial_start + #861, #3967
  static inicial_start + #862, #3967
  static inicial_start + #863, #3967
  static inicial_start + #864, #3967
  static inicial_start + #865, #3967
  static inicial_start + #866, #3967
  static inicial_start + #867, #3967
  static inicial_start + #868, #3967
  static inicial_start + #869, #3967
  static inicial_start + #870, #3967
  static inicial_start + #871, #3967
  static inicial_start + #872, #3967
  static inicial_start + #873, #3967
  static inicial_start + #874, #3967
  static inicial_start + #875, #3967
  static inicial_start + #876, #3967
  static inicial_start + #877, #3967
  static inicial_start + #878, #3967
  static inicial_start + #879, #3967

  ;Linha 22
  static inicial_start + #880, #3967
  static inicial_start + #881, #3967
  static inicial_start + #882, #3967
  static inicial_start + #883, #3967
  static inicial_start + #884, #3967
  static inicial_start + #885, #3967
  static inicial_start + #886, #3967
  static inicial_start + #887, #3967
  static inicial_start + #888, #3967
  static inicial_start + #889, #3967
  static inicial_start + #890, #3967
  static inicial_start + #891, #3967
  static inicial_start + #892, #3967
  static inicial_start + #893, #3967
  static inicial_start + #894, #3967
  static inicial_start + #895, #3967
  static inicial_start + #896, #3967
  static inicial_start + #897, #3967
  static inicial_start + #898, #3967
  static inicial_start + #899, #3967
  static inicial_start + #900, #3967
  static inicial_start + #901, #3967
  static inicial_start + #902, #3967
  static inicial_start + #903, #3967
  static inicial_start + #904, #3967
  static inicial_start + #905, #3967
  static inicial_start + #906, #3967
  static inicial_start + #907, #3967
  static inicial_start + #908, #3967
  static inicial_start + #909, #3967
  static inicial_start + #910, #3967
  static inicial_start + #911, #3967
  static inicial_start + #912, #3967
  static inicial_start + #913, #3967
  static inicial_start + #914, #3967
  static inicial_start + #915, #3967
  static inicial_start + #916, #3967
  static inicial_start + #917, #3967
  static inicial_start + #918, #3967
  static inicial_start + #919, #3967

  ;Linha 23
  static inicial_start + #920, #3967
  static inicial_start + #921, #3967
  static inicial_start + #922, #3967
  static inicial_start + #923, #3967
  static inicial_start + #924, #3967
  static inicial_start + #925, #3967
  static inicial_start + #926, #3967
  static inicial_start + #927, #3967
  static inicial_start + #928, #3967
  static inicial_start + #929, #3967
  static inicial_start + #930, #3967
  static inicial_start + #931, #3967
  static inicial_start + #932, #3967
  static inicial_start + #933, #3967
  static inicial_start + #934, #3967
  static inicial_start + #935, #3967
  static inicial_start + #936, #3967
  static inicial_start + #937, #3967
  static inicial_start + #938, #3967
  static inicial_start + #939, #3967
  static inicial_start + #940, #3967
  static inicial_start + #941, #3967
  static inicial_start + #942, #3967
  static inicial_start + #943, #3967
  static inicial_start + #944, #3967
  static inicial_start + #945, #3967
  static inicial_start + #946, #3967
  static inicial_start + #947, #3967
  static inicial_start + #948, #3967
  static inicial_start + #949, #3967
  static inicial_start + #950, #3967
  static inicial_start + #951, #3967
  static inicial_start + #952, #3967
  static inicial_start + #953, #3967
  static inicial_start + #954, #3967
  static inicial_start + #955, #3967
  static inicial_start + #956, #3967
  static inicial_start + #957, #3967
  static inicial_start + #958, #3967
  static inicial_start + #959, #3967

  ;Linha 24
  static inicial_start + #960, #3967
  static inicial_start + #961, #3967
  static inicial_start + #962, #3967
  static inicial_start + #963, #3967
  static inicial_start + #964, #3967
  static inicial_start + #965, #3967
  static inicial_start + #966, #3967
  static inicial_start + #967, #3967
  static inicial_start + #968, #3967
  static inicial_start + #969, #3967
  static inicial_start + #970, #3967
  static inicial_start + #971, #3967
  static inicial_start + #972, #3967
  static inicial_start + #973, #3967
  static inicial_start + #974, #3967
  static inicial_start + #975, #3967
  static inicial_start + #976, #3967
  static inicial_start + #977, #3967
  static inicial_start + #978, #2848
  static inicial_start + #979, #3967
  static inicial_start + #980, #2848
  static inicial_start + #981, #2848
  static inicial_start + #982, #3967
  static inicial_start + #983, #2848
  static inicial_start + #984, #2848
  static inicial_start + #985, #2848
  static inicial_start + #986, #2848
  static inicial_start + #987, #2848
  static inicial_start + #988, #2848
  static inicial_start + #989, #2848
  static inicial_start + #990, #2848
  static inicial_start + #991, #2848
  static inicial_start + #992, #3967
  static inicial_start + #993, #3967
  static inicial_start + #994, #3967
  static inicial_start + #995, #3967
  static inicial_start + #996, #3967
  static inicial_start + #997, #3967
  static inicial_start + #998, #3967
  static inicial_start + #999, #3967

  ;Linha 25
  static inicial_start + #1000, #3967
  static inicial_start + #1001, #3967
  static inicial_start + #1002, #3967
  static inicial_start + #1003, #3967
  static inicial_start + #1004, #3967
  static inicial_start + #1005, #2896
  static inicial_start + #1006, #2930
  static inicial_start + #1007, #2917
  static inicial_start + #1008, #2931
  static inicial_start + #1009, #2931
  static inicial_start + #1010, #2921
  static inicial_start + #1011, #2927
  static inicial_start + #1012, #2926
  static inicial_start + #1013, #2917
  static inicial_start + #1014, #2848
  static inicial_start + #1015, #2912
  static inicial_start + #1016, #2899
  static inicial_start + #1017, #2896
  static inicial_start + #1018, #2881
  static inicial_start + #1019, #2883
  static inicial_start + #1020, #2885
  static inicial_start + #1021, #2855
  static inicial_start + #1022, #2848
  static inicial_start + #1023, #2928
  static inicial_start + #1024, #2913
  static inicial_start + #1025, #2930
  static inicial_start + #1026, #2913
  static inicial_start + #1027, #2848
  static inicial_start + #1028, #2921
  static inicial_start + #1029, #2926
  static inicial_start + #1030, #2921
  static inicial_start + #1031, #2915
  static inicial_start + #1032, #2921
  static inicial_start + #1033, #2913
  static inicial_start + #1034, #2930
  static inicial_start + #1035, #2848
  static inicial_start + #1036, #2848
  static inicial_start + #1037, #3967
  static inicial_start + #1038, #3967
  static inicial_start + #1039, #3967

  ;Linha 26
  static inicial_start + #1040, #3967
  static inicial_start + #1041, #3967
  static inicial_start + #1042, #3967
  static inicial_start + #1043, #3967
  static inicial_start + #1044, #3967
  static inicial_start + #1045, #3967
  static inicial_start + #1046, #3967
  static inicial_start + #1047, #3967
  static inicial_start + #1048, #3967
  static inicial_start + #1049, #3967
  static inicial_start + #1050, #3967
  static inicial_start + #1051, #3967
  static inicial_start + #1052, #3967
  static inicial_start + #1053, #3967
  static inicial_start + #1054, #3967
  static inicial_start + #1055, #3967
  static inicial_start + #1056, #3967
  static inicial_start + #1057, #3967
  static inicial_start + #1058, #3967
  static inicial_start + #1059, #3967
  static inicial_start + #1060, #3967
  static inicial_start + #1061, #3967
  static inicial_start + #1062, #2848
  static inicial_start + #1063, #2848
  static inicial_start + #1064, #2848
  static inicial_start + #1065, #2848
  static inicial_start + #1066, #3967
  static inicial_start + #1067, #3967
  static inicial_start + #1068, #3967
  static inicial_start + #1069, #3967
  static inicial_start + #1070, #3967
  static inicial_start + #1071, #3967
  static inicial_start + #1072, #3967
  static inicial_start + #1073, #3967
  static inicial_start + #1074, #3967
  static inicial_start + #1075, #3967
  static inicial_start + #1076, #3967
  static inicial_start + #1077, #3967
  static inicial_start + #1078, #3967
  static inicial_start + #1079, #3967

  ;Linha 27
  static inicial_start + #1080, #3967
  static inicial_start + #1081, #3967
  static inicial_start + #1082, #3967
  static inicial_start + #1083, #3967
  static inicial_start + #1084, #3967
  static inicial_start + #1085, #3967
  static inicial_start + #1086, #3967
  static inicial_start + #1087, #3967
  static inicial_start + #1088, #3967
  static inicial_start + #1089, #3967
  static inicial_start + #1090, #3967
  static inicial_start + #1091, #3967
  static inicial_start + #1092, #3967
  static inicial_start + #1093, #3967
  static inicial_start + #1094, #3967
  static inicial_start + #1095, #3967
  static inicial_start + #1096, #3967
  static inicial_start + #1097, #3967
  static inicial_start + #1098, #3967
  static inicial_start + #1099, #3967
  static inicial_start + #1100, #3967
  static inicial_start + #1101, #3967
  static inicial_start + #1102, #3967
  static inicial_start + #1103, #3967
  static inicial_start + #1104, #3967
  static inicial_start + #1105, #3967
  static inicial_start + #1106, #3967
  static inicial_start + #1107, #3967
  static inicial_start + #1108, #3967
  static inicial_start + #1109, #3967
  static inicial_start + #1110, #3967
  static inicial_start + #1111, #3967
  static inicial_start + #1112, #3967
  static inicial_start + #1113, #3967
  static inicial_start + #1114, #3967
  static inicial_start + #1115, #3967
  static inicial_start + #1116, #3967
  static inicial_start + #1117, #3967
  static inicial_start + #1118, #3967
  static inicial_start + #1119, #3967

  ;Linha 28
  static inicial_start + #1120, #3967
  static inicial_start + #1121, #3967
  static inicial_start + #1122, #3967
  static inicial_start + #1123, #3967
  static inicial_start + #1124, #3967
  static inicial_start + #1125, #3967
  static inicial_start + #1126, #3967
  static inicial_start + #1127, #3967
  static inicial_start + #1128, #3967
  static inicial_start + #1129, #3967
  static inicial_start + #1130, #3967
  static inicial_start + #1131, #3967
  static inicial_start + #1132, #3967
  static inicial_start + #1133, #3967
  static inicial_start + #1134, #3967
  static inicial_start + #1135, #3967
  static inicial_start + #1136, #3967
  static inicial_start + #1137, #3967
  static inicial_start + #1138, #3967
  static inicial_start + #1139, #3967
  static inicial_start + #1140, #3967
  static inicial_start + #1141, #3967
  static inicial_start + #1142, #3967
  static inicial_start + #1143, #3967
  static inicial_start + #1144, #3967
  static inicial_start + #1145, #3967
  static inicial_start + #1146, #3967
  static inicial_start + #1147, #3967
  static inicial_start + #1148, #3967
  static inicial_start + #1149, #3967
  static inicial_start + #1150, #3967
  static inicial_start + #1151, #3967
  static inicial_start + #1152, #3967
  static inicial_start + #1153, #3967
  static inicial_start + #1154, #3967
  static inicial_start + #1155, #3967
  static inicial_start + #1156, #3967
  static inicial_start + #1157, #3967
  static inicial_start + #1158, #3967
  static inicial_start + #1159, #3967

  ;Linha 29
  static inicial_start + #1160, #3967
  static inicial_start + #1161, #3967
  static inicial_start + #1162, #3967
  static inicial_start + #1163, #3967
  static inicial_start + #1164, #3967
  static inicial_start + #1165, #3967
  static inicial_start + #1166, #3967
  static inicial_start + #1167, #3967
  static inicial_start + #1168, #3967
  static inicial_start + #1169, #3967
  static inicial_start + #1170, #3967
  static inicial_start + #1171, #3967
  static inicial_start + #1172, #3967
  static inicial_start + #1173, #3967
  static inicial_start + #1174, #3967
  static inicial_start + #1175, #3967
  static inicial_start + #1176, #3967
  static inicial_start + #1177, #3967
  static inicial_start + #1178, #3967
  static inicial_start + #1179, #3967
  static inicial_start + #1180, #3967
  static inicial_start + #1181, #3967
  static inicial_start + #1182, #3967
  static inicial_start + #1183, #3967
  static inicial_start + #1184, #3967
  static inicial_start + #1185, #3967
  static inicial_start + #1186, #3967
  static inicial_start + #1187, #3967
  static inicial_start + #1188, #3967
  static inicial_start + #1189, #3967
  static inicial_start + #1190, #3967
  static inicial_start + #1191, #3967
  static inicial_start + #1192, #3967
  static inicial_start + #1193, #3967
  static inicial_start + #1194, #3967
  static inicial_start + #1195, #3967
  static inicial_start + #1196, #3967
  static inicial_start + #1197, #3967
  static inicial_start + #1198, #3967
  static inicial_start + #1199, #3967


g_amarelo : var #1200
  ;Linha 0
  static g_amarelo + #0, #3967
  static g_amarelo + #1, #3967
  static g_amarelo + #2, #3967
  static g_amarelo + #3, #3967
  static g_amarelo + #4, #3967
  static g_amarelo + #5, #3967
  static g_amarelo + #6, #3967
  static g_amarelo + #7, #3967
  static g_amarelo + #8, #3967
  static g_amarelo + #9, #3967
  static g_amarelo + #10, #3967
  static g_amarelo + #11, #3967
  static g_amarelo + #12, #3967
  static g_amarelo + #13, #3967
  static g_amarelo + #14, #3967
  static g_amarelo + #15, #3967
  static g_amarelo + #16, #3967
  static g_amarelo + #17, #3967
  static g_amarelo + #18, #3967
  static g_amarelo + #19, #3967
  static g_amarelo + #20, #3967
  static g_amarelo + #21, #3967
  static g_amarelo + #22, #3967
  static g_amarelo + #23, #3967
  static g_amarelo + #24, #3967
  static g_amarelo + #25, #3967
  static g_amarelo + #26, #3967
  static g_amarelo + #27, #3967
  static g_amarelo + #28, #3967
  static g_amarelo + #29, #3967
  static g_amarelo + #30, #3967
  static g_amarelo + #31, #3967
  static g_amarelo + #32, #3967
  static g_amarelo + #33, #3967
  static g_amarelo + #34, #3967
  static g_amarelo + #35, #3967
  static g_amarelo + #36, #3967
  static g_amarelo + #37, #3967
  static g_amarelo + #38, #3967
  static g_amarelo + #39, #3967

  ;Linha 1
  static g_amarelo + #40, #3967
  static g_amarelo + #41, #3967
  static g_amarelo + #42, #3967
  static g_amarelo + #43, #3967
  static g_amarelo + #44, #3967
  static g_amarelo + #45, #3967
  static g_amarelo + #46, #3967
  static g_amarelo + #47, #3967
  static g_amarelo + #48, #3967
  static g_amarelo + #49, #3967
  static g_amarelo + #50, #3967
  static g_amarelo + #51, #3967
  static g_amarelo + #52, #3967
  static g_amarelo + #53, #3967
  static g_amarelo + #54, #3967
  static g_amarelo + #55, #3967
  static g_amarelo + #56, #3967
  static g_amarelo + #57, #3967
  static g_amarelo + #58, #3967
  static g_amarelo + #59, #3967
  static g_amarelo + #60, #3967
  static g_amarelo + #61, #3967
  static g_amarelo + #62, #3967
  static g_amarelo + #63, #3967
  static g_amarelo + #64, #3967
  static g_amarelo + #65, #3967
  static g_amarelo + #66, #3967
  static g_amarelo + #67, #3967
  static g_amarelo + #68, #3967
  static g_amarelo + #69, #3967
  static g_amarelo + #70, #3967
  static g_amarelo + #71, #3967
  static g_amarelo + #72, #3967
  static g_amarelo + #73, #3967
  static g_amarelo + #74, #3967
  static g_amarelo + #75, #3967
  static g_amarelo + #76, #3967
  static g_amarelo + #77, #3967
  static g_amarelo + #78, #3967
  static g_amarelo + #79, #3967

  ;Linha 2
  static g_amarelo + #80, #3967
  static g_amarelo + #81, #3967
  static g_amarelo + #82, #3967
  static g_amarelo + #83, #3967
  static g_amarelo + #84, #3967
  static g_amarelo + #85, #3967
  static g_amarelo + #86, #3967
  static g_amarelo + #87, #3967
  static g_amarelo + #88, #3967
  static g_amarelo + #89, #3967
  static g_amarelo + #90, #3967
  static g_amarelo + #91, #3967
  static g_amarelo + #92, #3967
  static g_amarelo + #93, #3967
  static g_amarelo + #94, #3967
  static g_amarelo + #95, #3967
  static g_amarelo + #96, #3967
  static g_amarelo + #97, #3967
  static g_amarelo + #98, #3967
  static g_amarelo + #99, #3967
  static g_amarelo + #100, #3967
  static g_amarelo + #101, #3967
  static g_amarelo + #102, #3967
  static g_amarelo + #103, #3967
  static g_amarelo + #104, #3967
  static g_amarelo + #105, #3967
  static g_amarelo + #106, #3967
  static g_amarelo + #107, #3967
  static g_amarelo + #108, #3967
  static g_amarelo + #109, #3967
  static g_amarelo + #110, #3967
  static g_amarelo + #111, #3967
  static g_amarelo + #112, #3967
  static g_amarelo + #113, #3967
  static g_amarelo + #114, #3967
  static g_amarelo + #115, #3967
  static g_amarelo + #116, #3967
  static g_amarelo + #117, #3967
  static g_amarelo + #118, #3967
  static g_amarelo + #119, #3967

  ;Linha 3
  static g_amarelo + #120, #3967
  static g_amarelo + #121, #3967
  static g_amarelo + #122, #3967
  static g_amarelo + #123, #3967
  static g_amarelo + #124, #3967
  static g_amarelo + #125, #3967
  static g_amarelo + #126, #3967
  static g_amarelo + #127, #3967
  static g_amarelo + #128, #3967
  static g_amarelo + #129, #3967
  static g_amarelo + #130, #3967
  static g_amarelo + #131, #3967
  static g_amarelo + #132, #3967
  static g_amarelo + #133, #3967
  static g_amarelo + #134, #3967
  static g_amarelo + #135, #3967
  static g_amarelo + #136, #3967
  static g_amarelo + #137, #3967
  static g_amarelo + #138, #3967
  static g_amarelo + #139, #3967
  static g_amarelo + #140, #3967
  static g_amarelo + #141, #3967
  static g_amarelo + #142, #3967
  static g_amarelo + #143, #3967
  static g_amarelo + #144, #3967
  static g_amarelo + #145, #3967
  static g_amarelo + #146, #3967
  static g_amarelo + #147, #3967
  static g_amarelo + #148, #3967
  static g_amarelo + #149, #3967
  static g_amarelo + #150, #3967
  static g_amarelo + #151, #3967
  static g_amarelo + #152, #3967
  static g_amarelo + #153, #3967
  static g_amarelo + #154, #3967
  static g_amarelo + #155, #3967
  static g_amarelo + #156, #3967
  static g_amarelo + #157, #3967
  static g_amarelo + #158, #3967
  static g_amarelo + #159, #3967

  ;Linha 4
  static g_amarelo + #160, #3967
  static g_amarelo + #161, #3967
  static g_amarelo + #162, #3967
  static g_amarelo + #163, #3967
  static g_amarelo + #164, #3967
  static g_amarelo + #165, #3967
  static g_amarelo + #166, #3967
  static g_amarelo + #167, #3967
  static g_amarelo + #168, #3967
  static g_amarelo + #169, #3967
  static g_amarelo + #170, #3967
  static g_amarelo + #171, #3967
  static g_amarelo + #172, #3967
  static g_amarelo + #173, #3967
  static g_amarelo + #174, #3967
  static g_amarelo + #175, #3967
  static g_amarelo + #176, #3967
  static g_amarelo + #177, #3967
  static g_amarelo + #178, #3967
  static g_amarelo + #179, #3967
  static g_amarelo + #180, #3967
  static g_amarelo + #181, #3967
  static g_amarelo + #182, #3967
  static g_amarelo + #183, #3967
  static g_amarelo + #184, #3967
  static g_amarelo + #185, #3967
  static g_amarelo + #186, #3967
  static g_amarelo + #187, #3967
  static g_amarelo + #188, #3967
  static g_amarelo + #189, #3967
  static g_amarelo + #190, #3967
  static g_amarelo + #191, #3967
  static g_amarelo + #192, #3967
  static g_amarelo + #193, #3967
  static g_amarelo + #194, #3967
  static g_amarelo + #195, #544
  static g_amarelo + #196, #3967
  static g_amarelo + #197, #3967
  static g_amarelo + #198, #3967
  static g_amarelo + #199, #3967

  ;Linha 5
  static g_amarelo + #200, #3967
  static g_amarelo + #201, #3967
  static g_amarelo + #202, #3967
  static g_amarelo + #203, #3967
  static g_amarelo + #204, #2336
  static g_amarelo + #205, #2336
  static g_amarelo + #206, #2336
  static g_amarelo + #207, #2336
  static g_amarelo + #208, #3967
  static g_amarelo + #209, #3967
  static g_amarelo + #210, #3967
  static g_amarelo + #211, #3967
  static g_amarelo + #212, #3967
  static g_amarelo + #213, #3967
  static g_amarelo + #214, #3967
  static g_amarelo + #215, #3967
  static g_amarelo + #216, #3967
  static g_amarelo + #217, #3967
  static g_amarelo + #218, #3967
  static g_amarelo + #219, #32
  static g_amarelo + #220, #32
  static g_amarelo + #221, #3967
  static g_amarelo + #222, #3967
  static g_amarelo + #223, #3967
  static g_amarelo + #224, #3967
  static g_amarelo + #225, #3967
  static g_amarelo + #226, #3967
  static g_amarelo + #227, #3967
  static g_amarelo + #228, #3967
  static g_amarelo + #229, #3967
  static g_amarelo + #230, #3967
  static g_amarelo + #231, #3967
  static g_amarelo + #232, #3967
  static g_amarelo + #233, #2907
  static g_amarelo + #234, #2868
  static g_amarelo + #235, #2909
  static g_amarelo + #236, #3967
  static g_amarelo + #237, #3967
  static g_amarelo + #238, #3967
  static g_amarelo + #239, #3967

  ;Linha 6
  static g_amarelo + #240, #3967
  static g_amarelo + #241, #3967
  static g_amarelo + #242, #3967
  static g_amarelo + #243, #3967
  static g_amarelo + #244, #3967
  static g_amarelo + #245, #3967
  static g_amarelo + #246, #3967
  static g_amarelo + #247, #3967
  static g_amarelo + #248, #3967
  static g_amarelo + #249, #3967
  static g_amarelo + #250, #3967
  static g_amarelo + #251, #3967
  static g_amarelo + #252, #3967
  static g_amarelo + #253, #3967
  static g_amarelo + #254, #3967
  static g_amarelo + #255, #3967
  static g_amarelo + #256, #3967
  static g_amarelo + #257, #0
  static g_amarelo + #258, #0
  static g_amarelo + #259, #0
  static g_amarelo + #260, #0
  static g_amarelo + #261, #0
  static g_amarelo + #262, #0
  static g_amarelo + #263, #0
  static g_amarelo + #264, #32
  static g_amarelo + #265, #3967
  static g_amarelo + #266, #3967
  static g_amarelo + #267, #3967
  static g_amarelo + #268, #3967
  static g_amarelo + #269, #3967
  static g_amarelo + #270, #3967
  static g_amarelo + #271, #3967
  static g_amarelo + #272, #3967
  static g_amarelo + #273, #3967
  static g_amarelo + #274, #544
  static g_amarelo + #275, #544
  static g_amarelo + #276, #3967
  static g_amarelo + #277, #3967
  static g_amarelo + #278, #3967
  static g_amarelo + #279, #3967

  ;Linha 7
  static g_amarelo + #280, #3967
  static g_amarelo + #281, #3967
  static g_amarelo + #282, #3967
  static g_amarelo + #283, #3967
  static g_amarelo + #284, #3967
  static g_amarelo + #285, #3967
  static g_amarelo + #286, #3967
  static g_amarelo + #287, #3967
  static g_amarelo + #288, #3967
  static g_amarelo + #289, #3967
  static g_amarelo + #290, #3967
  static g_amarelo + #291, #3967
  static g_amarelo + #292, #3967
  static g_amarelo + #293, #3967
  static g_amarelo + #294, #3967
  static g_amarelo + #295, #0
  static g_amarelo + #296, #0
  static g_amarelo + #297, #2048
  static g_amarelo + #298, #2048
  static g_amarelo + #299, #2048
  static g_amarelo + #300, #0
  static g_amarelo + #301, #2816
  static g_amarelo + #302, #2816
  static g_amarelo + #303, #2816
  static g_amarelo + #304, #0
  static g_amarelo + #305, #0
  static g_amarelo + #306, #3967
  static g_amarelo + #307, #3967
  static g_amarelo + #308, #3967
  static g_amarelo + #309, #3967
  static g_amarelo + #310, #3967
  static g_amarelo + #311, #3967
  static g_amarelo + #312, #3967
  static g_amarelo + #313, #3967
  static g_amarelo + #314, #3967
  static g_amarelo + #315, #544
  static g_amarelo + #316, #3967
  static g_amarelo + #317, #3967
  static g_amarelo + #318, #3967
  static g_amarelo + #319, #3967

  ;Linha 8
  static g_amarelo + #320, #3967
  static g_amarelo + #321, #3967
  static g_amarelo + #322, #3967
  static g_amarelo + #323, #3967
  static g_amarelo + #324, #3967
  static g_amarelo + #325, #3967
  static g_amarelo + #326, #544
  static g_amarelo + #327, #3967
  static g_amarelo + #328, #3967
  static g_amarelo + #329, #3967
  static g_amarelo + #330, #3967
  static g_amarelo + #331, #3967
  static g_amarelo + #332, #3967
  static g_amarelo + #333, #0
  static g_amarelo + #334, #0
  static g_amarelo + #335, #2048
  static g_amarelo + #336, #2048
  static g_amarelo + #337, #2048
  static g_amarelo + #338, #2048
  static g_amarelo + #339, #2048
  static g_amarelo + #340, #0
  static g_amarelo + #341, #2816
  static g_amarelo + #342, #2816
  static g_amarelo + #343, #2816
  static g_amarelo + #344, #2816
  static g_amarelo + #345, #2816
  static g_amarelo + #346, #0
  static g_amarelo + #347, #0
  static g_amarelo + #348, #3967
  static g_amarelo + #349, #3967
  static g_amarelo + #350, #3967
  static g_amarelo + #351, #3967
  static g_amarelo + #352, #3967
  static g_amarelo + #353, #3967
  static g_amarelo + #354, #3967
  static g_amarelo + #355, #544
  static g_amarelo + #356, #3967
  static g_amarelo + #357, #3967
  static g_amarelo + #358, #3967
  static g_amarelo + #359, #3967

  ;Linha 9
  static g_amarelo + #360, #3967
  static g_amarelo + #361, #3967
  static g_amarelo + #362, #3967
  static g_amarelo + #363, #3967
  static g_amarelo + #364, #3967
  static g_amarelo + #365, #3967
  static g_amarelo + #366, #544
  static g_amarelo + #367, #3967
  static g_amarelo + #368, #3967
  static g_amarelo + #369, #3967
  static g_amarelo + #370, #3967
  static g_amarelo + #371, #3967
  static g_amarelo + #372, #0
  static g_amarelo + #373, #2048
  static g_amarelo + #374, #2048
  static g_amarelo + #375, #2048
  static g_amarelo + #376, #2048
  static g_amarelo + #377, #2048
  static g_amarelo + #378, #2048
  static g_amarelo + #379, #2048
  static g_amarelo + #380, #0
  static g_amarelo + #381, #2816
  static g_amarelo + #382, #2816
  static g_amarelo + #383, #2816
  static g_amarelo + #384, #2816
  static g_amarelo + #385, #2816
  static g_amarelo + #386, #2816
  static g_amarelo + #387, #2816
  static g_amarelo + #388, #0
  static g_amarelo + #389, #3967
  static g_amarelo + #390, #3967
  static g_amarelo + #391, #3967
  static g_amarelo + #392, #3967
  static g_amarelo + #393, #3967
  static g_amarelo + #394, #3967
  static g_amarelo + #395, #3967
  static g_amarelo + #396, #3967
  static g_amarelo + #397, #3967
  static g_amarelo + #398, #3967
  static g_amarelo + #399, #3967

  ;Linha 10
  static g_amarelo + #400, #3967
  static g_amarelo + #401, #3967
  static g_amarelo + #402, #3967
  static g_amarelo + #403, #3967
  static g_amarelo + #404, #3967
  static g_amarelo + #405, #3967
  static g_amarelo + #406, #544
  static g_amarelo + #407, #3967
  static g_amarelo + #408, #3967
  static g_amarelo + #409, #3967
  static g_amarelo + #410, #3967
  static g_amarelo + #411, #3967
  static g_amarelo + #412, #0
  static g_amarelo + #413, #2048
  static g_amarelo + #414, #2048
  static g_amarelo + #415, #2048
  static g_amarelo + #416, #2048
  static g_amarelo + #417, #2048
  static g_amarelo + #418, #2048
  static g_amarelo + #419, #2048
  static g_amarelo + #420, #0
  static g_amarelo + #421, #2816
  static g_amarelo + #422, #2816
  static g_amarelo + #423, #2816
  static g_amarelo + #424, #2816
  static g_amarelo + #425, #2816
  static g_amarelo + #426, #2816
  static g_amarelo + #427, #2816
  static g_amarelo + #428, #0
  static g_amarelo + #429, #3967
  static g_amarelo + #430, #3967
  static g_amarelo + #431, #3967
  static g_amarelo + #432, #3967
  static g_amarelo + #433, #3967
  static g_amarelo + #434, #3967
  static g_amarelo + #435, #3967
  static g_amarelo + #436, #544
  static g_amarelo + #437, #3967
  static g_amarelo + #438, #3967
  static g_amarelo + #439, #3967

  ;Linha 11
  static g_amarelo + #440, #3967
  static g_amarelo + #441, #3967
  static g_amarelo + #442, #3967
  static g_amarelo + #443, #3967
  static g_amarelo + #444, #3967
  static g_amarelo + #445, #3967
  static g_amarelo + #446, #3967
  static g_amarelo + #447, #3967
  static g_amarelo + #448, #3967
  static g_amarelo + #449, #3967
  static g_amarelo + #450, #3967
  static g_amarelo + #451, #3967
  static g_amarelo + #452, #0
  static g_amarelo + #453, #2048
  static g_amarelo + #454, #2048
  static g_amarelo + #455, #2048
  static g_amarelo + #456, #2048
  static g_amarelo + #457, #2048
  static g_amarelo + #458, #0
  static g_amarelo + #459, #0
  static g_amarelo + #460, #0
  static g_amarelo + #461, #0
  static g_amarelo + #462, #0
  static g_amarelo + #463, #2816
  static g_amarelo + #464, #2816
  static g_amarelo + #465, #2816
  static g_amarelo + #466, #2816
  static g_amarelo + #467, #2816
  static g_amarelo + #468, #0
  static g_amarelo + #469, #3967
  static g_amarelo + #470, #3967
  static g_amarelo + #471, #3967
  static g_amarelo + #472, #3967
  static g_amarelo + #473, #3967
  static g_amarelo + #474, #3967
  static g_amarelo + #475, #3967
  static g_amarelo + #476, #544
  static g_amarelo + #477, #3967
  static g_amarelo + #478, #3967
  static g_amarelo + #479, #3967

  ;Linha 12
  static g_amarelo + #480, #3967
  static g_amarelo + #481, #3967
  static g_amarelo + #482, #3967
  static g_amarelo + #483, #3967
  static g_amarelo + #484, #3967
  static g_amarelo + #485, #3967
  static g_amarelo + #486, #3967
  static g_amarelo + #487, #3967
  static g_amarelo + #488, #3967
  static g_amarelo + #489, #3967
  static g_amarelo + #490, #3967
  static g_amarelo + #491, #0
  static g_amarelo + #492, #2048
  static g_amarelo + #493, #2048
  static g_amarelo + #494, #2048
  static g_amarelo + #495, #2048
  static g_amarelo + #496, #2048
  static g_amarelo + #497, #0
  static g_amarelo + #498, #32
  static g_amarelo + #499, #32
  static g_amarelo + #500, #3967
  static g_amarelo + #501, #3967
  static g_amarelo + #502, #32
  static g_amarelo + #503, #0
  static g_amarelo + #504, #2816
  static g_amarelo + #505, #2816
  static g_amarelo + #506, #2816
  static g_amarelo + #507, #2816
  static g_amarelo + #508, #2816
  static g_amarelo + #509, #0
  static g_amarelo + #510, #3967
  static g_amarelo + #511, #3967
  static g_amarelo + #512, #3967
  static g_amarelo + #513, #3967
  static g_amarelo + #514, #3967
  static g_amarelo + #515, #3967
  static g_amarelo + #516, #3967
  static g_amarelo + #517, #3967
  static g_amarelo + #518, #3967
  static g_amarelo + #519, #3967

  ;Linha 13
  static g_amarelo + #520, #3967
  static g_amarelo + #521, #3967
  static g_amarelo + #522, #3967
  static g_amarelo + #523, #3967
  static g_amarelo + #524, #3967
  static g_amarelo + #525, #3967
  static g_amarelo + #526, #3967
  static g_amarelo + #527, #3967
  static g_amarelo + #528, #3967
  static g_amarelo + #529, #3967
  static g_amarelo + #530, #3967
  static g_amarelo + #531, #0
  static g_amarelo + #532, #2048
  static g_amarelo + #533, #2048
  static g_amarelo + #534, #2048
  static g_amarelo + #535, #2048
  static g_amarelo + #536, #0
  static g_amarelo + #537, #3967
  static g_amarelo + #538, #3104
  static g_amarelo + #539, #3967
  static g_amarelo + #540, #3967
  static g_amarelo + #541, #3967
  static g_amarelo + #542, #32
  static g_amarelo + #543, #32
  static g_amarelo + #544, #0
  static g_amarelo + #545, #2816
  static g_amarelo + #546, #2816
  static g_amarelo + #547, #2816
  static g_amarelo + #548, #2816
  static g_amarelo + #549, #0
  static g_amarelo + #550, #3967
  static g_amarelo + #551, #3967
  static g_amarelo + #552, #3967
  static g_amarelo + #553, #3967
  static g_amarelo + #554, #3967
  static g_amarelo + #555, #3967
  static g_amarelo + #556, #544
  static g_amarelo + #557, #3967
  static g_amarelo + #558, #3967
  static g_amarelo + #559, #3967

  ;Linha 14
  static g_amarelo + #560, #3967
  static g_amarelo + #561, #3967
  static g_amarelo + #562, #3967
  static g_amarelo + #563, #3967
  static g_amarelo + #564, #3967
  static g_amarelo + #565, #3967
  static g_amarelo + #566, #3967
  static g_amarelo + #567, #3967
  static g_amarelo + #568, #3967
  static g_amarelo + #569, #3967
  static g_amarelo + #570, #32
  static g_amarelo + #571, #0
  static g_amarelo + #572, #2048
  static g_amarelo + #573, #2048
  static g_amarelo + #574, #2048
  static g_amarelo + #575, #2048
  static g_amarelo + #576, #0
  static g_amarelo + #577, #3967
  static g_amarelo + #578, #2907
  static g_amarelo + #579, #2909
  static g_amarelo + #580, #3104
  static g_amarelo + #581, #2907
  static g_amarelo + #582, #2909
  static g_amarelo + #583, #3104
  static g_amarelo + #584, #0
  static g_amarelo + #585, #2816
  static g_amarelo + #586, #2816
  static g_amarelo + #587, #2816
  static g_amarelo + #588, #2816
  static g_amarelo + #589, #0
  static g_amarelo + #590, #3967
  static g_amarelo + #591, #3967
  static g_amarelo + #592, #3967
  static g_amarelo + #593, #3967
  static g_amarelo + #594, #3967
  static g_amarelo + #595, #3967
  static g_amarelo + #596, #544
  static g_amarelo + #597, #3967
  static g_amarelo + #598, #3967
  static g_amarelo + #599, #3967

  ;Linha 15
  static g_amarelo + #600, #3967
  static g_amarelo + #601, #3967
  static g_amarelo + #602, #3967
  static g_amarelo + #603, #3967
  static g_amarelo + #604, #3967
  static g_amarelo + #605, #3967
  static g_amarelo + #606, #3967
  static g_amarelo + #607, #3967
  static g_amarelo + #608, #3967
  static g_amarelo + #609, #3967
  static g_amarelo + #610, #32
  static g_amarelo + #611, #0
  static g_amarelo + #612, #0
  static g_amarelo + #613, #0
  static g_amarelo + #614, #0
  static g_amarelo + #615, #0
  static g_amarelo + #616, #0
  static g_amarelo + #617, #32
  static g_amarelo + #618, #32
  static g_amarelo + #619, #32
  static g_amarelo + #620, #32
  static g_amarelo + #621, #32
  static g_amarelo + #622, #32
  static g_amarelo + #623, #32
  static g_amarelo + #624, #0
  static g_amarelo + #625, #0
  static g_amarelo + #626, #0
  static g_amarelo + #627, #0
  static g_amarelo + #628, #0
  static g_amarelo + #629, #0
  static g_amarelo + #630, #32
  static g_amarelo + #631, #3967
  static g_amarelo + #632, #3967
  static g_amarelo + #633, #3967
  static g_amarelo + #634, #3967
  static g_amarelo + #635, #3967
  static g_amarelo + #636, #3967
  static g_amarelo + #637, #3967
  static g_amarelo + #638, #3967
  static g_amarelo + #639, #3967

  ;Linha 16
  static g_amarelo + #640, #3967
  static g_amarelo + #641, #3967
  static g_amarelo + #642, #3967
  static g_amarelo + #643, #3967
  static g_amarelo + #644, #3967
  static g_amarelo + #645, #3967
  static g_amarelo + #646, #3967
  static g_amarelo + #647, #3967
  static g_amarelo + #648, #3967
  static g_amarelo + #649, #3967
  static g_amarelo + #650, #32
  static g_amarelo + #651, #0
  static g_amarelo + #652, #2048
  static g_amarelo + #653, #2048
  static g_amarelo + #654, #2048
  static g_amarelo + #655, #2048
  static g_amarelo + #656, #0
  static g_amarelo + #657, #3967
  static g_amarelo + #658, #2080
  static g_amarelo + #659, #544
  static g_amarelo + #660, #2933
  static g_amarelo + #661, #544
  static g_amarelo + #662, #32
  static g_amarelo + #663, #32
  static g_amarelo + #664, #0
  static g_amarelo + #665, #2048
  static g_amarelo + #666, #2048
  static g_amarelo + #667, #2048
  static g_amarelo + #668, #2048
  static g_amarelo + #669, #0
  static g_amarelo + #670, #32
  static g_amarelo + #671, #32
  static g_amarelo + #672, #3967
  static g_amarelo + #673, #3967
  static g_amarelo + #674, #3967
  static g_amarelo + #675, #544
  static g_amarelo + #676, #3967
  static g_amarelo + #677, #3967
  static g_amarelo + #678, #3967
  static g_amarelo + #679, #3967

  ;Linha 17
  static g_amarelo + #680, #3967
  static g_amarelo + #681, #3967
  static g_amarelo + #682, #3967
  static g_amarelo + #683, #3967
  static g_amarelo + #684, #3967
  static g_amarelo + #685, #3967
  static g_amarelo + #686, #3967
  static g_amarelo + #687, #3967
  static g_amarelo + #688, #3967
  static g_amarelo + #689, #3967
  static g_amarelo + #690, #3967
  static g_amarelo + #691, #0
  static g_amarelo + #692, #2048
  static g_amarelo + #693, #2048
  static g_amarelo + #694, #2048
  static g_amarelo + #695, #2048
  static g_amarelo + #696, #0
  static g_amarelo + #697, #3967
  static g_amarelo + #698, #3967
  static g_amarelo + #699, #3967
  static g_amarelo + #700, #3967
  static g_amarelo + #701, #3967
  static g_amarelo + #702, #32
  static g_amarelo + #703, #32
  static g_amarelo + #704, #0
  static g_amarelo + #705, #2048
  static g_amarelo + #706, #2048
  static g_amarelo + #707, #2048
  static g_amarelo + #708, #2048
  static g_amarelo + #709, #0
  static g_amarelo + #710, #3967
  static g_amarelo + #711, #3967
  static g_amarelo + #712, #3967
  static g_amarelo + #713, #3967
  static g_amarelo + #714, #3967
  static g_amarelo + #715, #3967
  static g_amarelo + #716, #3967
  static g_amarelo + #717, #3967
  static g_amarelo + #718, #3967
  static g_amarelo + #719, #3967

  ;Linha 18
  static g_amarelo + #720, #3967
  static g_amarelo + #721, #3967
  static g_amarelo + #722, #3967
  static g_amarelo + #723, #3967
  static g_amarelo + #724, #3967
  static g_amarelo + #725, #3967
  static g_amarelo + #726, #3967
  static g_amarelo + #727, #3967
  static g_amarelo + #728, #3967
  static g_amarelo + #729, #3967
  static g_amarelo + #730, #3967
  static g_amarelo + #731, #0
  static g_amarelo + #732, #2048
  static g_amarelo + #733, #2048
  static g_amarelo + #734, #2048
  static g_amarelo + #735, #2048
  static g_amarelo + #736, #2048
  static g_amarelo + #737, #0
  static g_amarelo + #738, #3967
  static g_amarelo + #739, #3967
  static g_amarelo + #740, #3967
  static g_amarelo + #741, #3967
  static g_amarelo + #742, #32
  static g_amarelo + #743, #0
  static g_amarelo + #744, #2048
  static g_amarelo + #745, #2048
  static g_amarelo + #746, #2048
  static g_amarelo + #747, #2048
  static g_amarelo + #748, #2048
  static g_amarelo + #749, #0
  static g_amarelo + #750, #3967
  static g_amarelo + #751, #3967
  static g_amarelo + #752, #3967
  static g_amarelo + #753, #3967
  static g_amarelo + #754, #3967
  static g_amarelo + #755, #544
  static g_amarelo + #756, #3967
  static g_amarelo + #757, #3967
  static g_amarelo + #758, #3967
  static g_amarelo + #759, #3967

  ;Linha 19
  static g_amarelo + #760, #3967
  static g_amarelo + #761, #3967
  static g_amarelo + #762, #3967
  static g_amarelo + #763, #3967
  static g_amarelo + #764, #3967
  static g_amarelo + #765, #3967
  static g_amarelo + #766, #3967
  static g_amarelo + #767, #3967
  static g_amarelo + #768, #3967
  static g_amarelo + #769, #3967
  static g_amarelo + #770, #3967
  static g_amarelo + #771, #3967
  static g_amarelo + #772, #0
  static g_amarelo + #773, #2048
  static g_amarelo + #774, #2048
  static g_amarelo + #775, #2048
  static g_amarelo + #776, #2048
  static g_amarelo + #777, #2048
  static g_amarelo + #778, #0
  static g_amarelo + #779, #0
  static g_amarelo + #780, #0
  static g_amarelo + #781, #0
  static g_amarelo + #782, #0
  static g_amarelo + #783, #2048
  static g_amarelo + #784, #2048
  static g_amarelo + #785, #2048
  static g_amarelo + #786, #2048
  static g_amarelo + #787, #2048
  static g_amarelo + #788, #0
  static g_amarelo + #789, #3967
  static g_amarelo + #790, #3967
  static g_amarelo + #791, #3967
  static g_amarelo + #792, #3967
  static g_amarelo + #793, #3967
  static g_amarelo + #794, #3967
  static g_amarelo + #795, #3967
  static g_amarelo + #796, #3967
  static g_amarelo + #797, #3967
  static g_amarelo + #798, #3967
  static g_amarelo + #799, #3967

  ;Linha 20
  static g_amarelo + #800, #3967
  static g_amarelo + #801, #3967
  static g_amarelo + #802, #3967
  static g_amarelo + #803, #3967
  static g_amarelo + #804, #3967
  static g_amarelo + #805, #3967
  static g_amarelo + #806, #3967
  static g_amarelo + #807, #3967
  static g_amarelo + #808, #3967
  static g_amarelo + #809, #3967
  static g_amarelo + #810, #3967
  static g_amarelo + #811, #3967
  static g_amarelo + #812, #0
  static g_amarelo + #813, #2048
  static g_amarelo + #814, #2048
  static g_amarelo + #815, #2048
  static g_amarelo + #816, #2048
  static g_amarelo + #817, #2048
  static g_amarelo + #818, #2048
  static g_amarelo + #819, #2048
  static g_amarelo + #820, #0
  static g_amarelo + #821, #2048
  static g_amarelo + #822, #2048
  static g_amarelo + #823, #2048
  static g_amarelo + #824, #2048
  static g_amarelo + #825, #2048
  static g_amarelo + #826, #2048
  static g_amarelo + #827, #2048
  static g_amarelo + #828, #0
  static g_amarelo + #829, #3967
  static g_amarelo + #830, #3967
  static g_amarelo + #831, #3967
  static g_amarelo + #832, #3967
  static g_amarelo + #833, #3967
  static g_amarelo + #834, #3967
  static g_amarelo + #835, #544
  static g_amarelo + #836, #3967
  static g_amarelo + #837, #3967
  static g_amarelo + #838, #3967
  static g_amarelo + #839, #3967

  ;Linha 21
  static g_amarelo + #840, #3967
  static g_amarelo + #841, #3967
  static g_amarelo + #842, #3967
  static g_amarelo + #843, #3967
  static g_amarelo + #844, #3967
  static g_amarelo + #845, #3967
  static g_amarelo + #846, #3967
  static g_amarelo + #847, #3967
  static g_amarelo + #848, #3967
  static g_amarelo + #849, #3967
  static g_amarelo + #850, #3967
  static g_amarelo + #851, #3967
  static g_amarelo + #852, #0
  static g_amarelo + #853, #2048
  static g_amarelo + #854, #2048
  static g_amarelo + #855, #2048
  static g_amarelo + #856, #2048
  static g_amarelo + #857, #2048
  static g_amarelo + #858, #2048
  static g_amarelo + #859, #2048
  static g_amarelo + #860, #0
  static g_amarelo + #861, #2048
  static g_amarelo + #862, #2048
  static g_amarelo + #863, #2048
  static g_amarelo + #864, #2048
  static g_amarelo + #865, #2048
  static g_amarelo + #866, #2048
  static g_amarelo + #867, #2048
  static g_amarelo + #868, #0
  static g_amarelo + #869, #3967
  static g_amarelo + #870, #3967
  static g_amarelo + #871, #3967
  static g_amarelo + #872, #3967
  static g_amarelo + #873, #3967
  static g_amarelo + #874, #544
  static g_amarelo + #875, #3967
  static g_amarelo + #876, #3967
  static g_amarelo + #877, #3967
  static g_amarelo + #878, #3967
  static g_amarelo + #879, #3967

  ;Linha 22
  static g_amarelo + #880, #3967
  static g_amarelo + #881, #3967
  static g_amarelo + #882, #3967
  static g_amarelo + #883, #3967
  static g_amarelo + #884, #3967
  static g_amarelo + #885, #3967
  static g_amarelo + #886, #3967
  static g_amarelo + #887, #3967
  static g_amarelo + #888, #3967
  static g_amarelo + #889, #3967
  static g_amarelo + #890, #3967
  static g_amarelo + #891, #3967
  static g_amarelo + #892, #3967
  static g_amarelo + #893, #0
  static g_amarelo + #894, #0
  static g_amarelo + #895, #2048
  static g_amarelo + #896, #2048
  static g_amarelo + #897, #2048
  static g_amarelo + #898, #2048
  static g_amarelo + #899, #2048
  static g_amarelo + #900, #0
  static g_amarelo + #901, #2048
  static g_amarelo + #902, #2048
  static g_amarelo + #903, #2048
  static g_amarelo + #904, #2048
  static g_amarelo + #905, #2048
  static g_amarelo + #906, #0
  static g_amarelo + #907, #0
  static g_amarelo + #908, #3967
  static g_amarelo + #909, #3967
  static g_amarelo + #910, #3967
  static g_amarelo + #911, #3967
  static g_amarelo + #912, #3967
  static g_amarelo + #913, #3967
  static g_amarelo + #914, #544
  static g_amarelo + #915, #3967
  static g_amarelo + #916, #3967
  static g_amarelo + #917, #3967
  static g_amarelo + #918, #3967
  static g_amarelo + #919, #3967

  ;Linha 23
  static g_amarelo + #920, #3967
  static g_amarelo + #921, #3967
  static g_amarelo + #922, #3967
  static g_amarelo + #923, #3967
  static g_amarelo + #924, #3967
  static g_amarelo + #925, #3967
  static g_amarelo + #926, #3967
  static g_amarelo + #927, #3967
  static g_amarelo + #928, #3967
  static g_amarelo + #929, #3967
  static g_amarelo + #930, #3967
  static g_amarelo + #931, #3967
  static g_amarelo + #932, #3967
  static g_amarelo + #933, #3967
  static g_amarelo + #934, #3967
  static g_amarelo + #935, #0
  static g_amarelo + #936, #0
  static g_amarelo + #937, #2048
  static g_amarelo + #938, #2048
  static g_amarelo + #939, #2048
  static g_amarelo + #940, #0
  static g_amarelo + #941, #2048
  static g_amarelo + #942, #2048
  static g_amarelo + #943, #2048
  static g_amarelo + #944, #0
  static g_amarelo + #945, #0
  static g_amarelo + #946, #3967
  static g_amarelo + #947, #3967
  static g_amarelo + #948, #3967
  static g_amarelo + #949, #3967
  static g_amarelo + #950, #3967
  static g_amarelo + #951, #3967
  static g_amarelo + #952, #3967
  static g_amarelo + #953, #544
  static g_amarelo + #954, #544
  static g_amarelo + #955, #3967
  static g_amarelo + #956, #3967
  static g_amarelo + #957, #3967
  static g_amarelo + #958, #3967
  static g_amarelo + #959, #3967

  ;Linha 24
  static g_amarelo + #960, #3967
  static g_amarelo + #961, #3967
  static g_amarelo + #962, #3967
  static g_amarelo + #963, #3967
  static g_amarelo + #964, #3104
  static g_amarelo + #965, #3104
  static g_amarelo + #966, #3104
  static g_amarelo + #967, #3104
  static g_amarelo + #968, #3967
  static g_amarelo + #969, #3967
  static g_amarelo + #970, #3967
  static g_amarelo + #971, #3967
  static g_amarelo + #972, #3967
  static g_amarelo + #973, #3967
  static g_amarelo + #974, #3967
  static g_amarelo + #975, #3967
  static g_amarelo + #976, #3967
  static g_amarelo + #977, #0
  static g_amarelo + #978, #0
  static g_amarelo + #979, #0
  static g_amarelo + #980, #0
  static g_amarelo + #981, #0
  static g_amarelo + #982, #0
  static g_amarelo + #983, #0
  static g_amarelo + #984, #3967
  static g_amarelo + #985, #3967
  static g_amarelo + #986, #3967
  static g_amarelo + #987, #3967
  static g_amarelo + #988, #3967
  static g_amarelo + #989, #3967
  static g_amarelo + #990, #3967
  static g_amarelo + #991, #544
  static g_amarelo + #992, #544
  static g_amarelo + #993, #2080
  static g_amarelo + #994, #2080
  static g_amarelo + #995, #2080
  static g_amarelo + #996, #3967
  static g_amarelo + #997, #3967
  static g_amarelo + #998, #3967
  static g_amarelo + #999, #3967

  ;Linha 25
  static g_amarelo + #1000, #3967
  static g_amarelo + #1001, #3967
  static g_amarelo + #1002, #3967
  static g_amarelo + #1003, #3967
  static g_amarelo + #1004, #3967
  static g_amarelo + #1005, #544
  static g_amarelo + #1006, #544
  static g_amarelo + #1007, #544
  static g_amarelo + #1008, #544
  static g_amarelo + #1009, #3967
  static g_amarelo + #1010, #3967
  static g_amarelo + #1011, #3967
  static g_amarelo + #1012, #3967
  static g_amarelo + #1013, #3967
  static g_amarelo + #1014, #3967
  static g_amarelo + #1015, #3967
  static g_amarelo + #1016, #3967
  static g_amarelo + #1017, #3967
  static g_amarelo + #1018, #3967
  static g_amarelo + #1019, #32
  static g_amarelo + #1020, #3967
  static g_amarelo + #1021, #3967
  static g_amarelo + #1022, #3967
  static g_amarelo + #1023, #3967
  static g_amarelo + #1024, #3967
  static g_amarelo + #1025, #3967
  static g_amarelo + #1026, #3967
  static g_amarelo + #1027, #3967
  static g_amarelo + #1028, #3967
  static g_amarelo + #1029, #3967
  static g_amarelo + #1030, #3967
  static g_amarelo + #1031, #544
  static g_amarelo + #1032, #544
  static g_amarelo + #1033, #544
  static g_amarelo + #1034, #544
  static g_amarelo + #1035, #3967
  static g_amarelo + #1036, #3967
  static g_amarelo + #1037, #3967
  static g_amarelo + #1038, #3967
  static g_amarelo + #1039, #3967

  ;Linha 26
  static g_amarelo + #1040, #3967
  static g_amarelo + #1041, #3967
  static g_amarelo + #1042, #3967
  static g_amarelo + #1043, #3967
  static g_amarelo + #1044, #3967
  static g_amarelo + #1045, #3967
  static g_amarelo + #1046, #3967
  static g_amarelo + #1047, #3967
  static g_amarelo + #1048, #3967
  static g_amarelo + #1049, #544
  static g_amarelo + #1050, #544
  static g_amarelo + #1051, #544
  static g_amarelo + #1052, #544
  static g_amarelo + #1053, #3967
  static g_amarelo + #1054, #3967
  static g_amarelo + #1055, #3967
  static g_amarelo + #1056, #3967
  static g_amarelo + #1057, #3967
  static g_amarelo + #1058, #3967
  static g_amarelo + #1059, #544
  static g_amarelo + #1060, #544
  static g_amarelo + #1061, #3967
  static g_amarelo + #1062, #544
  static g_amarelo + #1063, #3967
  static g_amarelo + #1064, #544
  static g_amarelo + #1065, #3967
  static g_amarelo + #1066, #544
  static g_amarelo + #1067, #3967
  static g_amarelo + #1068, #544
  static g_amarelo + #1069, #3967
  static g_amarelo + #1070, #544
  static g_amarelo + #1071, #3967
  static g_amarelo + #1072, #3967
  static g_amarelo + #1073, #3967
  static g_amarelo + #1074, #3967
  static g_amarelo + #1075, #3967
  static g_amarelo + #1076, #3967
  static g_amarelo + #1077, #3967
  static g_amarelo + #1078, #3967
  static g_amarelo + #1079, #3967

  ;Linha 27
  static g_amarelo + #1080, #3967
  static g_amarelo + #1081, #3967
  static g_amarelo + #1082, #3967
  static g_amarelo + #1083, #3967
  static g_amarelo + #1084, #3967
  static g_amarelo + #1085, #3967
  static g_amarelo + #1086, #3967
  static g_amarelo + #1087, #3967
  static g_amarelo + #1088, #3967
  static g_amarelo + #1089, #3967
  static g_amarelo + #1090, #3967
  static g_amarelo + #1091, #3967
  static g_amarelo + #1092, #3967
  static g_amarelo + #1093, #544
  static g_amarelo + #1094, #544
  static g_amarelo + #1095, #544
  static g_amarelo + #1096, #544
  static g_amarelo + #1097, #544
  static g_amarelo + #1098, #3967
  static g_amarelo + #1099, #3967
  static g_amarelo + #1100, #3967
  static g_amarelo + #1101, #3967
  static g_amarelo + #1102, #3967
  static g_amarelo + #1103, #3967
  static g_amarelo + #1104, #3967
  static g_amarelo + #1105, #3967
  static g_amarelo + #1106, #3967
  static g_amarelo + #1107, #3967
  static g_amarelo + #1108, #3967
  static g_amarelo + #1109, #3967
  static g_amarelo + #1110, #3967
  static g_amarelo + #1111, #3967
  static g_amarelo + #1112, #3967
  static g_amarelo + #1113, #3967
  static g_amarelo + #1114, #3967
  static g_amarelo + #1115, #3967
  static g_amarelo + #1116, #3967
  static g_amarelo + #1117, #3967
  static g_amarelo + #1118, #3967
  static g_amarelo + #1119, #3967

  ;Linha 28
  static g_amarelo + #1120, #3967
  static g_amarelo + #1121, #3967
  static g_amarelo + #1122, #3967
  static g_amarelo + #1123, #3967
  static g_amarelo + #1124, #3967
  static g_amarelo + #1125, #3967
  static g_amarelo + #1126, #3967
  static g_amarelo + #1127, #3967
  static g_amarelo + #1128, #3967
  static g_amarelo + #1129, #3967
  static g_amarelo + #1130, #3967
  static g_amarelo + #1131, #3967
  static g_amarelo + #1132, #3967
  static g_amarelo + #1133, #3967
  static g_amarelo + #1134, #3967
  static g_amarelo + #1135, #3967
  static g_amarelo + #1136, #3967
  static g_amarelo + #1137, #3967
  static g_amarelo + #1138, #3967
  static g_amarelo + #1139, #3967
  static g_amarelo + #1140, #3967
  static g_amarelo + #1141, #3967
  static g_amarelo + #1142, #3967
  static g_amarelo + #1143, #3967
  static g_amarelo + #1144, #3967
  static g_amarelo + #1145, #3967
  static g_amarelo + #1146, #3967
  static g_amarelo + #1147, #3967
  static g_amarelo + #1148, #3967
  static g_amarelo + #1149, #3967
  static g_amarelo + #1150, #3967
  static g_amarelo + #1151, #3967
  static g_amarelo + #1152, #3967
  static g_amarelo + #1153, #3967
  static g_amarelo + #1154, #3967
  static g_amarelo + #1155, #3967
  static g_amarelo + #1156, #3967
  static g_amarelo + #1157, #3967
  static g_amarelo + #1158, #3967
  static g_amarelo + #1159, #3967

  ;Linha 29
  static g_amarelo + #1160, #3967
  static g_amarelo + #1161, #3967
  static g_amarelo + #1162, #3967
  static g_amarelo + #1163, #3967
  static g_amarelo + #1164, #3967
  static g_amarelo + #1165, #3967
  static g_amarelo + #1166, #3967
  static g_amarelo + #1167, #3967
  static g_amarelo + #1168, #3967
  static g_amarelo + #1169, #3967
  static g_amarelo + #1170, #3967
  static g_amarelo + #1171, #3967
  static g_amarelo + #1172, #3967
  static g_amarelo + #1173, #3967
  static g_amarelo + #1174, #3967
  static g_amarelo + #1175, #3967
  static g_amarelo + #1176, #3967
  static g_amarelo + #1177, #3967
  static g_amarelo + #1178, #3967
  static g_amarelo + #1179, #3967
  static g_amarelo + #1180, #3967
  static g_amarelo + #1181, #3967
  static g_amarelo + #1182, #3967
  static g_amarelo + #1183, #3967
  static g_amarelo + #1184, #3967
  static g_amarelo + #1185, #3967
  static g_amarelo + #1186, #3967
  static g_amarelo + #1187, #3967
  static g_amarelo + #1188, #3967
  static g_amarelo + #1189, #3967
  static g_amarelo + #1190, #3967
  static g_amarelo + #1191, #3967
  static g_amarelo + #1192, #3967
  static g_amarelo + #1193, #3967
  static g_amarelo + #1194, #3967
  static g_amarelo + #1195, #3967
  static g_amarelo + #1196, #3967
  static g_amarelo + #1197, #3967
  static g_amarelo + #1198, #3967
  static g_amarelo + #1199, #3967
;===========Tela Verde==============

g_verde : var #1200
  ;Linha 0
  static g_verde + #0, #3967
  static g_verde + #1, #3967
  static g_verde + #2, #3967
  static g_verde + #3, #3967
  static g_verde + #4, #3967
  static g_verde + #5, #3967
  static g_verde + #6, #3967
  static g_verde + #7, #3967
  static g_verde + #8, #3967
  static g_verde + #9, #3967
  static g_verde + #10, #3967
  static g_verde + #11, #3967
  static g_verde + #12, #3967
  static g_verde + #13, #3967
  static g_verde + #14, #3967
  static g_verde + #15, #3967
  static g_verde + #16, #3967
  static g_verde + #17, #3967
  static g_verde + #18, #3967
  static g_verde + #19, #3967
  static g_verde + #20, #3967
  static g_verde + #21, #3967
  static g_verde + #22, #3967
  static g_verde + #23, #3967
  static g_verde + #24, #3967
  static g_verde + #25, #3967
  static g_verde + #26, #3967
  static g_verde + #27, #3967
  static g_verde + #28, #3967
  static g_verde + #29, #3967
  static g_verde + #30, #3967
  static g_verde + #31, #3967
  static g_verde + #32, #3967
  static g_verde + #33, #3967
  static g_verde + #34, #3967
  static g_verde + #35, #3967
  static g_verde + #36, #3967
  static g_verde + #37, #3967
  static g_verde + #38, #3967
  static g_verde + #39, #3967

  ;Linha 1
  static g_verde + #40, #3967
  static g_verde + #41, #3967
  static g_verde + #42, #3967
  static g_verde + #43, #3967
  static g_verde + #44, #3967
  static g_verde + #45, #3967
  static g_verde + #46, #3967
  static g_verde + #47, #3967
  static g_verde + #48, #3967
  static g_verde + #49, #3967
  static g_verde + #50, #3967
  static g_verde + #51, #3967
  static g_verde + #52, #3967
  static g_verde + #53, #3967
  static g_verde + #54, #3967
  static g_verde + #55, #3967
  static g_verde + #56, #3967
  static g_verde + #57, #3967
  static g_verde + #58, #3967
  static g_verde + #59, #3967
  static g_verde + #60, #3967
  static g_verde + #61, #3967
  static g_verde + #62, #3967
  static g_verde + #63, #3967
  static g_verde + #64, #3967
  static g_verde + #65, #3967
  static g_verde + #66, #3967
  static g_verde + #67, #3967
  static g_verde + #68, #3967
  static g_verde + #69, #3967
  static g_verde + #70, #3967
  static g_verde + #71, #3967
  static g_verde + #72, #3967
  static g_verde + #73, #3967
  static g_verde + #74, #3967
  static g_verde + #75, #3967
  static g_verde + #76, #3967
  static g_verde + #77, #3967
  static g_verde + #78, #3967
  static g_verde + #79, #3967

  ;Linha 2
  static g_verde + #80, #3967
  static g_verde + #81, #3967
  static g_verde + #82, #3967
  static g_verde + #83, #3967
  static g_verde + #84, #3967
  static g_verde + #85, #3967
  static g_verde + #86, #3967
  static g_verde + #87, #3967
  static g_verde + #88, #3967
  static g_verde + #89, #3967
  static g_verde + #90, #3967
  static g_verde + #91, #3967
  static g_verde + #92, #3967
  static g_verde + #93, #3967
  static g_verde + #94, #3967
  static g_verde + #95, #3967
  static g_verde + #96, #3967
  static g_verde + #97, #3967
  static g_verde + #98, #3967
  static g_verde + #99, #3967
  static g_verde + #100, #3967
  static g_verde + #101, #3967
  static g_verde + #102, #3967
  static g_verde + #103, #3967
  static g_verde + #104, #3967
  static g_verde + #105, #3967
  static g_verde + #106, #3967
  static g_verde + #107, #3967
  static g_verde + #108, #3967
  static g_verde + #109, #3967
  static g_verde + #110, #3967
  static g_verde + #111, #3967
  static g_verde + #112, #3967
  static g_verde + #113, #3967
  static g_verde + #114, #3967
  static g_verde + #115, #3967
  static g_verde + #116, #3967
  static g_verde + #117, #3967
  static g_verde + #118, #3967
  static g_verde + #119, #3967

  ;Linha 3
  static g_verde + #120, #3967
  static g_verde + #121, #3967
  static g_verde + #122, #3967
  static g_verde + #123, #3967
  static g_verde + #124, #3967
  static g_verde + #125, #3967
  static g_verde + #126, #3967
  static g_verde + #127, #3967
  static g_verde + #128, #3967
  static g_verde + #129, #3967
  static g_verde + #130, #3967
  static g_verde + #131, #3967
  static g_verde + #132, #3967
  static g_verde + #133, #3967
  static g_verde + #134, #3967
  static g_verde + #135, #3967
  static g_verde + #136, #3967
  static g_verde + #137, #3967
  static g_verde + #138, #3967
  static g_verde + #139, #3967
  static g_verde + #140, #3967
  static g_verde + #141, #3967
  static g_verde + #142, #3967
  static g_verde + #143, #3967
  static g_verde + #144, #3967
  static g_verde + #145, #3967
  static g_verde + #146, #3967
  static g_verde + #147, #3967
  static g_verde + #148, #3967
  static g_verde + #149, #3967
  static g_verde + #150, #3967
  static g_verde + #151, #3967
  static g_verde + #152, #3967
  static g_verde + #153, #3967
  static g_verde + #154, #3967
  static g_verde + #155, #3967
  static g_verde + #156, #3967
  static g_verde + #157, #3967
  static g_verde + #158, #3967
  static g_verde + #159, #3967

  ;Linha 4
  static g_verde + #160, #3967
  static g_verde + #161, #3967
  static g_verde + #162, #3967
  static g_verde + #163, #3967
  static g_verde + #164, #3967
  static g_verde + #165, #3967
  static g_verde + #166, #3967
  static g_verde + #167, #3967
  static g_verde + #168, #3967
  static g_verde + #169, #3967
  static g_verde + #170, #3967
  static g_verde + #171, #3967
  static g_verde + #172, #3967
  static g_verde + #173, #3967
  static g_verde + #174, #3967
  static g_verde + #175, #3967
  static g_verde + #176, #3967
  static g_verde + #177, #3967
  static g_verde + #178, #3967
  static g_verde + #179, #3967
  static g_verde + #180, #3967
  static g_verde + #181, #3967
  static g_verde + #182, #3967
  static g_verde + #183, #3967
  static g_verde + #184, #3967
  static g_verde + #185, #3967
  static g_verde + #186, #3967
  static g_verde + #187, #3967
  static g_verde + #188, #3967
  static g_verde + #189, #3967
  static g_verde + #190, #3967
  static g_verde + #191, #3967
  static g_verde + #192, #3967
  static g_verde + #193, #3967
  static g_verde + #194, #3967
  static g_verde + #195, #544
  static g_verde + #196, #3967
  static g_verde + #197, #3967
  static g_verde + #198, #3967
  static g_verde + #199, #3967

  ;Linha 5
  static g_verde + #200, #3967
  static g_verde + #201, #3967
  static g_verde + #202, #3967
  static g_verde + #203, #3967
  static g_verde + #204, #3967
  static g_verde + #205, #603
  static g_verde + #206, #561
  static g_verde + #207, #605
  static g_verde + #208, #3967
  static g_verde + #209, #3967
  static g_verde + #210, #3967
  static g_verde + #211, #3967
  static g_verde + #212, #3967
  static g_verde + #213, #3967
  static g_verde + #214, #3967
  static g_verde + #215, #3967
  static g_verde + #216, #3967
  static g_verde + #217, #3967
  static g_verde + #218, #3967
  static g_verde + #219, #32
  static g_verde + #220, #32
  static g_verde + #221, #3967
  static g_verde + #222, #3967
  static g_verde + #223, #3967
  static g_verde + #224, #3967
  static g_verde + #225, #3967
  static g_verde + #226, #3967
  static g_verde + #227, #3967
  static g_verde + #228, #3967
  static g_verde + #229, #3967
  static g_verde + #230, #3967
  static g_verde + #231, #3967
  static g_verde + #232, #3967
  static g_verde + #233, #3967
  static g_verde + #234, #544
  static g_verde + #235, #544
  static g_verde + #236, #3967
  static g_verde + #237, #3967
  static g_verde + #238, #3967
  static g_verde + #239, #3967

  ;Linha 6
  static g_verde + #240, #3967
  static g_verde + #241, #3967
  static g_verde + #242, #3967
  static g_verde + #243, #3967
  static g_verde + #244, #3967
  static g_verde + #245, #3967
  static g_verde + #246, #3967
  static g_verde + #247, #3967
  static g_verde + #248, #3967
  static g_verde + #249, #3967
  static g_verde + #250, #3967
  static g_verde + #251, #3967
  static g_verde + #252, #3967
  static g_verde + #253, #3967
  static g_verde + #254, #3967
  static g_verde + #255, #3967
  static g_verde + #256, #3967
  static g_verde + #257, #0
  static g_verde + #258, #0
  static g_verde + #259, #0
  static g_verde + #260, #0
  static g_verde + #261, #0
  static g_verde + #262, #0
  static g_verde + #263, #0
  static g_verde + #264, #32
  static g_verde + #265, #3967
  static g_verde + #266, #3967
  static g_verde + #267, #3967
  static g_verde + #268, #3967
  static g_verde + #269, #3967
  static g_verde + #270, #3967
  static g_verde + #271, #3967
  static g_verde + #272, #3967
  static g_verde + #273, #3967
  static g_verde + #274, #544
  static g_verde + #275, #544
  static g_verde + #276, #3967
  static g_verde + #277, #3967
  static g_verde + #278, #3967
  static g_verde + #279, #3967

  ;Linha 7
  static g_verde + #280, #3967
  static g_verde + #281, #3967
  static g_verde + #282, #3967
  static g_verde + #283, #3967
  static g_verde + #284, #3967
  static g_verde + #285, #3967
  static g_verde + #286, #3967
  static g_verde + #287, #3967
  static g_verde + #288, #3967
  static g_verde + #289, #3967
  static g_verde + #290, #3967
  static g_verde + #291, #3967
  static g_verde + #292, #3967
  static g_verde + #293, #3967
  static g_verde + #294, #3967
  static g_verde + #295, #0
  static g_verde + #296, #0
  static g_verde + #297, #512
  static g_verde + #298, #512
  static g_verde + #299, #512
  static g_verde + #300, #0
  static g_verde + #301, #2048
  static g_verde + #302, #2048
  static g_verde + #303, #2048
  static g_verde + #304, #0
  static g_verde + #305, #0
  static g_verde + #306, #3967
  static g_verde + #307, #3967
  static g_verde + #308, #3967
  static g_verde + #309, #3967
  static g_verde + #310, #3967
  static g_verde + #311, #3967
  static g_verde + #312, #3967
  static g_verde + #313, #3967
  static g_verde + #314, #3967
  static g_verde + #315, #544
  static g_verde + #316, #3967
  static g_verde + #317, #3967
  static g_verde + #318, #3967
  static g_verde + #319, #3967

  ;Linha 8
  static g_verde + #320, #3967
  static g_verde + #321, #3967
  static g_verde + #322, #3967
  static g_verde + #323, #3967
  static g_verde + #324, #3967
  static g_verde + #325, #3967
  static g_verde + #326, #544
  static g_verde + #327, #3967
  static g_verde + #328, #3967
  static g_verde + #329, #3967
  static g_verde + #330, #3967
  static g_verde + #331, #3967
  static g_verde + #332, #3967
  static g_verde + #333, #0
  static g_verde + #334, #0
  static g_verde + #335, #512
  static g_verde + #336, #512
  static g_verde + #337, #512
  static g_verde + #338, #512
  static g_verde + #339, #512
  static g_verde + #340, #0
  static g_verde + #341, #2048
  static g_verde + #342, #2048
  static g_verde + #343, #2048
  static g_verde + #344, #2048
  static g_verde + #345, #2048
  static g_verde + #346, #0
  static g_verde + #347, #0
  static g_verde + #348, #3967
  static g_verde + #349, #3967
  static g_verde + #350, #3967
  static g_verde + #351, #3967
  static g_verde + #352, #3967
  static g_verde + #353, #3967
  static g_verde + #354, #3967
  static g_verde + #355, #544
  static g_verde + #356, #3967
  static g_verde + #357, #3967
  static g_verde + #358, #3967
  static g_verde + #359, #3967

  ;Linha 9
  static g_verde + #360, #3967
  static g_verde + #361, #3967
  static g_verde + #362, #3967
  static g_verde + #363, #3967
  static g_verde + #364, #3967
  static g_verde + #365, #3967
  static g_verde + #366, #544
  static g_verde + #367, #3967
  static g_verde + #368, #3967
  static g_verde + #369, #3967
  static g_verde + #370, #3967
  static g_verde + #371, #3967
  static g_verde + #372, #0
  static g_verde + #373, #512
  static g_verde + #374, #512
  static g_verde + #375, #512
  static g_verde + #376, #512
  static g_verde + #377, #512
  static g_verde + #378, #512
  static g_verde + #379, #512
  static g_verde + #380, #0
  static g_verde + #381, #2048
  static g_verde + #382, #2048
  static g_verde + #383, #2048
  static g_verde + #384, #2048
  static g_verde + #385, #2048
  static g_verde + #386, #2048
  static g_verde + #387, #2048
  static g_verde + #388, #0
  static g_verde + #389, #3967
  static g_verde + #390, #3967
  static g_verde + #391, #3967
  static g_verde + #392, #3967
  static g_verde + #393, #3967
  static g_verde + #394, #3967
  static g_verde + #395, #3967
  static g_verde + #396, #3967
  static g_verde + #397, #3967
  static g_verde + #398, #3967
  static g_verde + #399, #3967

  ;Linha 10
  static g_verde + #400, #3967
  static g_verde + #401, #3967
  static g_verde + #402, #3967
  static g_verde + #403, #3967
  static g_verde + #404, #3967
  static g_verde + #405, #3967
  static g_verde + #406, #544
  static g_verde + #407, #3967
  static g_verde + #408, #3967
  static g_verde + #409, #3967
  static g_verde + #410, #3967
  static g_verde + #411, #3967
  static g_verde + #412, #0
  static g_verde + #413, #512
  static g_verde + #414, #512
  static g_verde + #415, #512
  static g_verde + #416, #512
  static g_verde + #417, #512
  static g_verde + #418, #512
  static g_verde + #419, #512
  static g_verde + #420, #0
  static g_verde + #421, #2048
  static g_verde + #422, #2048
  static g_verde + #423, #2048
  static g_verde + #424, #2048
  static g_verde + #425, #2048
  static g_verde + #426, #2048
  static g_verde + #427, #2048
  static g_verde + #428, #0
  static g_verde + #429, #3967
  static g_verde + #430, #3967
  static g_verde + #431, #3967
  static g_verde + #432, #3967
  static g_verde + #433, #3967
  static g_verde + #434, #3967
  static g_verde + #435, #3967
  static g_verde + #436, #544
  static g_verde + #437, #3967
  static g_verde + #438, #3967
  static g_verde + #439, #3967

  ;Linha 11
  static g_verde + #440, #3967
  static g_verde + #441, #3967
  static g_verde + #442, #3967
  static g_verde + #443, #3967
  static g_verde + #444, #3967
  static g_verde + #445, #3967
  static g_verde + #446, #3967
  static g_verde + #447, #3967
  static g_verde + #448, #3967
  static g_verde + #449, #3967
  static g_verde + #450, #3967
  static g_verde + #451, #3967
  static g_verde + #452, #0
  static g_verde + #453, #512
  static g_verde + #454, #512
  static g_verde + #455, #512
  static g_verde + #456, #512
  static g_verde + #457, #512
  static g_verde + #458, #0
  static g_verde + #459, #0
  static g_verde + #460, #0
  static g_verde + #461, #0
  static g_verde + #462, #0
  static g_verde + #463, #2048
  static g_verde + #464, #2048
  static g_verde + #465, #2048
  static g_verde + #466, #2048
  static g_verde + #467, #2048
  static g_verde + #468, #0
  static g_verde + #469, #3967
  static g_verde + #470, #3967
  static g_verde + #471, #3967
  static g_verde + #472, #3967
  static g_verde + #473, #3967
  static g_verde + #474, #3967
  static g_verde + #475, #3967
  static g_verde + #476, #544
  static g_verde + #477, #3967
  static g_verde + #478, #3967
  static g_verde + #479, #3967

  ;Linha 12
  static g_verde + #480, #3967
  static g_verde + #481, #3967
  static g_verde + #482, #3967
  static g_verde + #483, #3967
  static g_verde + #484, #3967
  static g_verde + #485, #3967
  static g_verde + #486, #3967
  static g_verde + #487, #3967
  static g_verde + #488, #3967
  static g_verde + #489, #3967
  static g_verde + #490, #3967
  static g_verde + #491, #0
  static g_verde + #492, #512
  static g_verde + #493, #512
  static g_verde + #494, #512
  static g_verde + #495, #512
  static g_verde + #496, #512
  static g_verde + #497, #0
  static g_verde + #498, #32
  static g_verde + #499, #32
  static g_verde + #500, #3967
  static g_verde + #501, #3967
  static g_verde + #502, #32
  static g_verde + #503, #0
  static g_verde + #504, #2048
  static g_verde + #505, #2048
  static g_verde + #506, #2048
  static g_verde + #507, #2048
  static g_verde + #508, #2048
  static g_verde + #509, #0
  static g_verde + #510, #3967
  static g_verde + #511, #3967
  static g_verde + #512, #3967
  static g_verde + #513, #3967
  static g_verde + #514, #3967
  static g_verde + #515, #3967
  static g_verde + #516, #3967
  static g_verde + #517, #3967
  static g_verde + #518, #3967
  static g_verde + #519, #3967

  ;Linha 13
  static g_verde + #520, #3967
  static g_verde + #521, #3967
  static g_verde + #522, #3967
  static g_verde + #523, #3967
  static g_verde + #524, #3967
  static g_verde + #525, #3967
  static g_verde + #526, #3967
  static g_verde + #527, #3967
  static g_verde + #528, #3967
  static g_verde + #529, #3967
  static g_verde + #530, #3967
  static g_verde + #531, #0
  static g_verde + #532, #512
  static g_verde + #533, #512
  static g_verde + #534, #512
  static g_verde + #535, #512
  static g_verde + #536, #0
  static g_verde + #537, #3967
  static g_verde + #538, #32
  static g_verde + #539, #3967
  static g_verde + #540, #3967
  static g_verde + #541, #3967
  static g_verde + #542, #32
  static g_verde + #543, #32
  static g_verde + #544, #0
  static g_verde + #545, #2048
  static g_verde + #546, #2048
  static g_verde + #547, #2048
  static g_verde + #548, #2048
  static g_verde + #549, #0
  static g_verde + #550, #3967
  static g_verde + #551, #3967
  static g_verde + #552, #3967
  static g_verde + #553, #3967
  static g_verde + #554, #3967
  static g_verde + #555, #3967
  static g_verde + #556, #544
  static g_verde + #557, #3967
  static g_verde + #558, #3967
  static g_verde + #559, #3967

  ;Linha 14
  static g_verde + #560, #3967
  static g_verde + #561, #3967
  static g_verde + #562, #3967
  static g_verde + #563, #3967
  static g_verde + #564, #3967
  static g_verde + #565, #3967
  static g_verde + #566, #3967
  static g_verde + #567, #3967
  static g_verde + #568, #3967
  static g_verde + #569, #3967
  static g_verde + #570, #32
  static g_verde + #571, #0
  static g_verde + #572, #512
  static g_verde + #573, #512
  static g_verde + #574, #512
  static g_verde + #575, #512
  static g_verde + #576, #0
  static g_verde + #577, #3967
  static g_verde + #578, #559
  static g_verde + #579, #604
  static g_verde + #580, #3967
  static g_verde + #581, #559
  static g_verde + #582, #604
  static g_verde + #583, #32
  static g_verde + #584, #0
  static g_verde + #585, #2048
  static g_verde + #586, #2048
  static g_verde + #587, #2048
  static g_verde + #588, #2048
  static g_verde + #589, #0
  static g_verde + #590, #3967
  static g_verde + #591, #3967
  static g_verde + #592, #3967
  static g_verde + #593, #3967
  static g_verde + #594, #3967
  static g_verde + #595, #3967
  static g_verde + #596, #544
  static g_verde + #597, #3967
  static g_verde + #598, #3967
  static g_verde + #599, #3967

  ;Linha 15
  static g_verde + #600, #3967
  static g_verde + #601, #3967
  static g_verde + #602, #3967
  static g_verde + #603, #3967
  static g_verde + #604, #3967
  static g_verde + #605, #3967
  static g_verde + #606, #3967
  static g_verde + #607, #3967
  static g_verde + #608, #3967
  static g_verde + #609, #3967
  static g_verde + #610, #32
  static g_verde + #611, #0
  static g_verde + #612, #0
  static g_verde + #613, #0
  static g_verde + #614, #0
  static g_verde + #615, #0
  static g_verde + #616, #0
  static g_verde + #617, #32
  static g_verde + #618, #32
  static g_verde + #619, #32
  static g_verde + #620, #32
  static g_verde + #621, #32
  static g_verde + #622, #32
  static g_verde + #623, #32
  static g_verde + #624, #0
  static g_verde + #625, #0
  static g_verde + #626, #0
  static g_verde + #627, #0
  static g_verde + #628, #0
  static g_verde + #629, #0
  static g_verde + #630, #32
  static g_verde + #631, #3967
  static g_verde + #632, #3967
  static g_verde + #633, #3967
  static g_verde + #634, #3967
  static g_verde + #635, #3967
  static g_verde + #636, #3967
  static g_verde + #637, #3967
  static g_verde + #638, #3967
  static g_verde + #639, #3967

  ;Linha 16
  static g_verde + #640, #3967
  static g_verde + #641, #3967
  static g_verde + #642, #3967
  static g_verde + #643, #3967
  static g_verde + #644, #3967
  static g_verde + #645, #3967
  static g_verde + #646, #3967
  static g_verde + #647, #3967
  static g_verde + #648, #3967
  static g_verde + #649, #3967
  static g_verde + #650, #32
  static g_verde + #651, #0
  static g_verde + #652, #2048
  static g_verde + #653, #2048
  static g_verde + #654, #2048
  static g_verde + #655, #2048
  static g_verde + #656, #0
  static g_verde + #657, #3967
  static g_verde + #658, #2080
  static g_verde + #659, #544
  static g_verde + #660, #558
  static g_verde + #661, #544
  static g_verde + #662, #32
  static g_verde + #663, #32
  static g_verde + #664, #0
  static g_verde + #665, #2048
  static g_verde + #666, #2048
  static g_verde + #667, #2048
  static g_verde + #668, #2048
  static g_verde + #669, #0
  static g_verde + #670, #32
  static g_verde + #671, #32
  static g_verde + #672, #3967
  static g_verde + #673, #3967
  static g_verde + #674, #3967
  static g_verde + #675, #544
  static g_verde + #676, #3967
  static g_verde + #677, #3967
  static g_verde + #678, #3967
  static g_verde + #679, #3967

  ;Linha 17
  static g_verde + #680, #3967
  static g_verde + #681, #3967
  static g_verde + #682, #3967
  static g_verde + #683, #3967
  static g_verde + #684, #3967
  static g_verde + #685, #3967
  static g_verde + #686, #3967
  static g_verde + #687, #3967
  static g_verde + #688, #3967
  static g_verde + #689, #3967
  static g_verde + #690, #3967
  static g_verde + #691, #0
  static g_verde + #692, #2048
  static g_verde + #693, #2048
  static g_verde + #694, #2048
  static g_verde + #695, #2048
  static g_verde + #696, #0
  static g_verde + #697, #3967
  static g_verde + #698, #3967
  static g_verde + #699, #3967
  static g_verde + #700, #3967
  static g_verde + #701, #3967
  static g_verde + #702, #32
  static g_verde + #703, #32
  static g_verde + #704, #0
  static g_verde + #705, #2048
  static g_verde + #706, #2048
  static g_verde + #707, #2048
  static g_verde + #708, #2048
  static g_verde + #709, #0
  static g_verde + #710, #3967
  static g_verde + #711, #3967
  static g_verde + #712, #3967
  static g_verde + #713, #3967
  static g_verde + #714, #3967
  static g_verde + #715, #3967
  static g_verde + #716, #3967
  static g_verde + #717, #3967
  static g_verde + #718, #3967
  static g_verde + #719, #3967

  ;Linha 18
  static g_verde + #720, #3967
  static g_verde + #721, #3967
  static g_verde + #722, #3967
  static g_verde + #723, #3967
  static g_verde + #724, #3967
  static g_verde + #725, #3967
  static g_verde + #726, #3967
  static g_verde + #727, #3967
  static g_verde + #728, #3967
  static g_verde + #729, #3967
  static g_verde + #730, #3967
  static g_verde + #731, #0
  static g_verde + #732, #2048
  static g_verde + #733, #2048
  static g_verde + #734, #2048
  static g_verde + #735, #2048
  static g_verde + #736, #2048
  static g_verde + #737, #0
  static g_verde + #738, #3967
  static g_verde + #739, #3967
  static g_verde + #740, #3967
  static g_verde + #741, #3967
  static g_verde + #742, #32
  static g_verde + #743, #0
  static g_verde + #744, #2048
  static g_verde + #745, #2048
  static g_verde + #746, #2048
  static g_verde + #747, #2048
  static g_verde + #748, #2048
  static g_verde + #749, #0
  static g_verde + #750, #3967
  static g_verde + #751, #3967
  static g_verde + #752, #3967
  static g_verde + #753, #3967
  static g_verde + #754, #3967
  static g_verde + #755, #544
  static g_verde + #756, #3967
  static g_verde + #757, #3967
  static g_verde + #758, #3967
  static g_verde + #759, #3967

  ;Linha 19
  static g_verde + #760, #3967
  static g_verde + #761, #3967
  static g_verde + #762, #3967
  static g_verde + #763, #3967
  static g_verde + #764, #3967
  static g_verde + #765, #3967
  static g_verde + #766, #3967
  static g_verde + #767, #3967
  static g_verde + #768, #3967
  static g_verde + #769, #3967
  static g_verde + #770, #3967
  static g_verde + #771, #3967
  static g_verde + #772, #0
  static g_verde + #773, #2048
  static g_verde + #774, #2048
  static g_verde + #775, #2048
  static g_verde + #776, #2048
  static g_verde + #777, #2048
  static g_verde + #778, #0
  static g_verde + #779, #0
  static g_verde + #780, #0
  static g_verde + #781, #0
  static g_verde + #782, #0
  static g_verde + #783, #2048
  static g_verde + #784, #2048
  static g_verde + #785, #2048
  static g_verde + #786, #2048
  static g_verde + #787, #2048
  static g_verde + #788, #0
  static g_verde + #789, #3967
  static g_verde + #790, #3967
  static g_verde + #791, #3967
  static g_verde + #792, #3967
  static g_verde + #793, #3967
  static g_verde + #794, #3967
  static g_verde + #795, #3967
  static g_verde + #796, #3967
  static g_verde + #797, #3967
  static g_verde + #798, #3967
  static g_verde + #799, #3967

  ;Linha 20
  static g_verde + #800, #3967
  static g_verde + #801, #3967
  static g_verde + #802, #3967
  static g_verde + #803, #3967
  static g_verde + #804, #3967
  static g_verde + #805, #3967
  static g_verde + #806, #3967
  static g_verde + #807, #3967
  static g_verde + #808, #3967
  static g_verde + #809, #3967
  static g_verde + #810, #3967
  static g_verde + #811, #3967
  static g_verde + #812, #0
  static g_verde + #813, #2048
  static g_verde + #814, #2048
  static g_verde + #815, #2048
  static g_verde + #816, #2048
  static g_verde + #817, #2048
  static g_verde + #818, #2048
  static g_verde + #819, #2048
  static g_verde + #820, #0
  static g_verde + #821, #2048
  static g_verde + #822, #2048
  static g_verde + #823, #2048
  static g_verde + #824, #2048
  static g_verde + #825, #2048
  static g_verde + #826, #2048
  static g_verde + #827, #2048
  static g_verde + #828, #0
  static g_verde + #829, #3967
  static g_verde + #830, #3967
  static g_verde + #831, #3967
  static g_verde + #832, #3967
  static g_verde + #833, #3967
  static g_verde + #834, #3967
  static g_verde + #835, #544
  static g_verde + #836, #3967
  static g_verde + #837, #3967
  static g_verde + #838, #3967
  static g_verde + #839, #3967

  ;Linha 21
  static g_verde + #840, #3967
  static g_verde + #841, #3967
  static g_verde + #842, #3967
  static g_verde + #843, #3967
  static g_verde + #844, #3967
  static g_verde + #845, #3967
  static g_verde + #846, #3967
  static g_verde + #847, #3967
  static g_verde + #848, #3967
  static g_verde + #849, #3967
  static g_verde + #850, #3967
  static g_verde + #851, #3967
  static g_verde + #852, #0
  static g_verde + #853, #2048
  static g_verde + #854, #2048
  static g_verde + #855, #2048
  static g_verde + #856, #2048
  static g_verde + #857, #2048
  static g_verde + #858, #2048
  static g_verde + #859, #2048
  static g_verde + #860, #0
  static g_verde + #861, #2048
  static g_verde + #862, #2048
  static g_verde + #863, #2048
  static g_verde + #864, #2048
  static g_verde + #865, #2048
  static g_verde + #866, #2048
  static g_verde + #867, #2048
  static g_verde + #868, #0
  static g_verde + #869, #3967
  static g_verde + #870, #3967
  static g_verde + #871, #3967
  static g_verde + #872, #3967
  static g_verde + #873, #3967
  static g_verde + #874, #544
  static g_verde + #875, #3967
  static g_verde + #876, #3967
  static g_verde + #877, #3967
  static g_verde + #878, #3967
  static g_verde + #879, #3967

  ;Linha 22
  static g_verde + #880, #3967
  static g_verde + #881, #3967
  static g_verde + #882, #3967
  static g_verde + #883, #3967
  static g_verde + #884, #3967
  static g_verde + #885, #3967
  static g_verde + #886, #3967
  static g_verde + #887, #3967
  static g_verde + #888, #3967
  static g_verde + #889, #3967
  static g_verde + #890, #3967
  static g_verde + #891, #3967
  static g_verde + #892, #3967
  static g_verde + #893, #0
  static g_verde + #894, #0
  static g_verde + #895, #2048
  static g_verde + #896, #2048
  static g_verde + #897, #2048
  static g_verde + #898, #2048
  static g_verde + #899, #2048
  static g_verde + #900, #0
  static g_verde + #901, #2048
  static g_verde + #902, #2048
  static g_verde + #903, #2048
  static g_verde + #904, #2048
  static g_verde + #905, #2048
  static g_verde + #906, #0
  static g_verde + #907, #0
  static g_verde + #908, #3967
  static g_verde + #909, #3967
  static g_verde + #910, #3967
  static g_verde + #911, #3967
  static g_verde + #912, #3967
  static g_verde + #913, #3967
  static g_verde + #914, #544
  static g_verde + #915, #3967
  static g_verde + #916, #3967
  static g_verde + #917, #3967
  static g_verde + #918, #3967
  static g_verde + #919, #3967

  ;Linha 23
  static g_verde + #920, #3967
  static g_verde + #921, #3967
  static g_verde + #922, #3967
  static g_verde + #923, #3967
  static g_verde + #924, #3967
  static g_verde + #925, #3967
  static g_verde + #926, #3967
  static g_verde + #927, #3967
  static g_verde + #928, #3967
  static g_verde + #929, #3967
  static g_verde + #930, #3967
  static g_verde + #931, #3967
  static g_verde + #932, #3967
  static g_verde + #933, #3967
  static g_verde + #934, #3967
  static g_verde + #935, #0
  static g_verde + #936, #0
  static g_verde + #937, #2048
  static g_verde + #938, #2048
  static g_verde + #939, #2048
  static g_verde + #940, #0
  static g_verde + #941, #2048
  static g_verde + #942, #2048
  static g_verde + #943, #2048
  static g_verde + #944, #0
  static g_verde + #945, #0
  static g_verde + #946, #3967
  static g_verde + #947, #3967
  static g_verde + #948, #3967
  static g_verde + #949, #3967
  static g_verde + #950, #3967
  static g_verde + #951, #3967
  static g_verde + #952, #3967
  static g_verde + #953, #544
  static g_verde + #954, #544
  static g_verde + #955, #3967
  static g_verde + #956, #3967
  static g_verde + #957, #3967
  static g_verde + #958, #3967
  static g_verde + #959, #3967

  ;Linha 24
  static g_verde + #960, #3967
  static g_verde + #961, #3967
  static g_verde + #962, #3967
  static g_verde + #963, #3967
  static g_verde + #964, #3967
  static g_verde + #965, #544
  static g_verde + #966, #544
  static g_verde + #967, #544
  static g_verde + #968, #3967
  static g_verde + #969, #3967
  static g_verde + #970, #3967
  static g_verde + #971, #3967
  static g_verde + #972, #3967
  static g_verde + #973, #3967
  static g_verde + #974, #3967
  static g_verde + #975, #3967
  static g_verde + #976, #3967
  static g_verde + #977, #0
  static g_verde + #978, #0
  static g_verde + #979, #0
  static g_verde + #980, #0
  static g_verde + #981, #0
  static g_verde + #982, #0
  static g_verde + #983, #0
  static g_verde + #984, #3967
  static g_verde + #985, #3967
  static g_verde + #986, #3967
  static g_verde + #987, #3967
  static g_verde + #988, #3967
  static g_verde + #989, #3967
  static g_verde + #990, #3967
  static g_verde + #991, #544
  static g_verde + #992, #544
  static g_verde + #993, #544
  static g_verde + #994, #544
  static g_verde + #995, #544
  static g_verde + #996, #3967
  static g_verde + #997, #3967
  static g_verde + #998, #3967
  static g_verde + #999, #3967

  ;Linha 25
  static g_verde + #1000, #3967
  static g_verde + #1001, #3967
  static g_verde + #1002, #3967
  static g_verde + #1003, #3967
  static g_verde + #1004, #3967
  static g_verde + #1005, #544
  static g_verde + #1006, #544
  static g_verde + #1007, #544
  static g_verde + #1008, #544
  static g_verde + #1009, #3967
  static g_verde + #1010, #3967
  static g_verde + #1011, #3967
  static g_verde + #1012, #3967
  static g_verde + #1013, #3967
  static g_verde + #1014, #3967
  static g_verde + #1015, #3967
  static g_verde + #1016, #3967
  static g_verde + #1017, #3967
  static g_verde + #1018, #3967
  static g_verde + #1019, #32
  static g_verde + #1020, #3967
  static g_verde + #1021, #3967
  static g_verde + #1022, #3967
  static g_verde + #1023, #3967
  static g_verde + #1024, #3967
  static g_verde + #1025, #3967
  static g_verde + #1026, #3967
  static g_verde + #1027, #3967
  static g_verde + #1028, #3967
  static g_verde + #1029, #3967
  static g_verde + #1030, #3967
  static g_verde + #1031, #544
  static g_verde + #1032, #544
  static g_verde + #1033, #544
  static g_verde + #1034, #544
  static g_verde + #1035, #3967
  static g_verde + #1036, #3967
  static g_verde + #1037, #3967
  static g_verde + #1038, #3967
  static g_verde + #1039, #3967

  ;Linha 26
  static g_verde + #1040, #3967
  static g_verde + #1041, #3967
  static g_verde + #1042, #3967
  static g_verde + #1043, #3967
  static g_verde + #1044, #3967
  static g_verde + #1045, #3967
  static g_verde + #1046, #3967
  static g_verde + #1047, #3967
  static g_verde + #1048, #3967
  static g_verde + #1049, #544
  static g_verde + #1050, #544
  static g_verde + #1051, #544
  static g_verde + #1052, #544
  static g_verde + #1053, #3967
  static g_verde + #1054, #3967
  static g_verde + #1055, #3967
  static g_verde + #1056, #3967
  static g_verde + #1057, #3967
  static g_verde + #1058, #3967
  static g_verde + #1059, #544
  static g_verde + #1060, #544
  static g_verde + #1061, #3967
  static g_verde + #1062, #544
  static g_verde + #1063, #3967
  static g_verde + #1064, #544
  static g_verde + #1065, #3967
  static g_verde + #1066, #544
  static g_verde + #1067, #3967
  static g_verde + #1068, #544
  static g_verde + #1069, #3967
  static g_verde + #1070, #544
  static g_verde + #1071, #3967
  static g_verde + #1072, #3967
  static g_verde + #1073, #3967
  static g_verde + #1074, #3967
  static g_verde + #1075, #3967
  static g_verde + #1076, #3967
  static g_verde + #1077, #3967
  static g_verde + #1078, #3967
  static g_verde + #1079, #3967

  ;Linha 27
  static g_verde + #1080, #3967
  static g_verde + #1081, #3967
  static g_verde + #1082, #3967
  static g_verde + #1083, #3967
  static g_verde + #1084, #3967
  static g_verde + #1085, #3967
  static g_verde + #1086, #3967
  static g_verde + #1087, #3967
  static g_verde + #1088, #3967
  static g_verde + #1089, #3967
  static g_verde + #1090, #3967
  static g_verde + #1091, #3967
  static g_verde + #1092, #3967
  static g_verde + #1093, #544
  static g_verde + #1094, #544
  static g_verde + #1095, #544
  static g_verde + #1096, #544
  static g_verde + #1097, #544
  static g_verde + #1098, #3967
  static g_verde + #1099, #3967
  static g_verde + #1100, #3967
  static g_verde + #1101, #3967
  static g_verde + #1102, #3967
  static g_verde + #1103, #3967
  static g_verde + #1104, #3967
  static g_verde + #1105, #3967
  static g_verde + #1106, #3967
  static g_verde + #1107, #3967
  static g_verde + #1108, #3967
  static g_verde + #1109, #3967
  static g_verde + #1110, #3967
  static g_verde + #1111, #3967
  static g_verde + #1112, #3967
  static g_verde + #1113, #3967
  static g_verde + #1114, #3967
  static g_verde + #1115, #3967
  static g_verde + #1116, #3967
  static g_verde + #1117, #3967
  static g_verde + #1118, #3967
  static g_verde + #1119, #3967

  ;Linha 28
  static g_verde + #1120, #3967
  static g_verde + #1121, #3967
  static g_verde + #1122, #3967
  static g_verde + #1123, #3967
  static g_verde + #1124, #3967
  static g_verde + #1125, #3967
  static g_verde + #1126, #3967
  static g_verde + #1127, #3967
  static g_verde + #1128, #3967
  static g_verde + #1129, #3967
  static g_verde + #1130, #3967
  static g_verde + #1131, #3967
  static g_verde + #1132, #3967
  static g_verde + #1133, #3967
  static g_verde + #1134, #3967
  static g_verde + #1135, #3967
  static g_verde + #1136, #3967
  static g_verde + #1137, #3967
  static g_verde + #1138, #3967
  static g_verde + #1139, #3967
  static g_verde + #1140, #3967
  static g_verde + #1141, #3967
  static g_verde + #1142, #3967
  static g_verde + #1143, #3967
  static g_verde + #1144, #3967
  static g_verde + #1145, #3967
  static g_verde + #1146, #3967
  static g_verde + #1147, #3967
  static g_verde + #1148, #3967
  static g_verde + #1149, #3967
  static g_verde + #1150, #3967
  static g_verde + #1151, #3967
  static g_verde + #1152, #3967
  static g_verde + #1153, #3967
  static g_verde + #1154, #3967
  static g_verde + #1155, #3967
  static g_verde + #1156, #3967
  static g_verde + #1157, #3967
  static g_verde + #1158, #3967
  static g_verde + #1159, #3967

  ;Linha 29
  static g_verde + #1160, #3967
  static g_verde + #1161, #3967
  static g_verde + #1162, #3967
  static g_verde + #1163, #3967
  static g_verde + #1164, #3967
  static g_verde + #1165, #3967
  static g_verde + #1166, #3967
  static g_verde + #1167, #3967
  static g_verde + #1168, #3967
  static g_verde + #1169, #3967
  static g_verde + #1170, #3967
  static g_verde + #1171, #3967
  static g_verde + #1172, #3967
  static g_verde + #1173, #3967
  static g_verde + #1174, #3967
  static g_verde + #1175, #3967
  static g_verde + #1176, #3967
  static g_verde + #1177, #3967
  static g_verde + #1178, #3967
  static g_verde + #1179, #3967
  static g_verde + #1180, #3967
  static g_verde + #1181, #3967
  static g_verde + #1182, #3967
  static g_verde + #1183, #3967
  static g_verde + #1184, #3967
  static g_verde + #1185, #3967
  static g_verde + #1186, #3967
  static g_verde + #1187, #3967
  static g_verde + #1188, #3967
  static g_verde + #1189, #3967
  static g_verde + #1190, #3967
  static g_verde + #1191, #3967
  static g_verde + #1192, #3967
  static g_verde + #1193, #3967
  static g_verde + #1194, #3967
  static g_verde + #1195, #3967
  static g_verde + #1196, #3967
  static g_verde + #1197, #3967
  static g_verde + #1198, #3967
  static g_verde + #1199, #3967

;===========Tela Azul===============
g_azul : var #1200
  ;Linha 0
  static g_azul + #0, #3967
  static g_azul + #1, #3967
  static g_azul + #2, #3967
  static g_azul + #3, #3967
  static g_azul + #4, #3967
  static g_azul + #5, #3967
  static g_azul + #6, #3967
  static g_azul + #7, #3967
  static g_azul + #8, #3967
  static g_azul + #9, #3967
  static g_azul + #10, #3967
  static g_azul + #11, #3967
  static g_azul + #12, #3967
  static g_azul + #13, #3967
  static g_azul + #14, #3967
  static g_azul + #15, #3967
  static g_azul + #16, #3967
  static g_azul + #17, #3967
  static g_azul + #18, #3967
  static g_azul + #19, #3967
  static g_azul + #20, #3967
  static g_azul + #21, #3967
  static g_azul + #22, #3967
  static g_azul + #23, #3967
  static g_azul + #24, #3967
  static g_azul + #25, #3967
  static g_azul + #26, #3967
  static g_azul + #27, #3967
  static g_azul + #28, #3967
  static g_azul + #29, #3967
  static g_azul + #30, #3967
  static g_azul + #31, #3967
  static g_azul + #32, #3967
  static g_azul + #33, #3967
  static g_azul + #34, #3967
  static g_azul + #35, #3967
  static g_azul + #36, #3967
  static g_azul + #37, #3967
  static g_azul + #38, #3967
  static g_azul + #39, #3967

  ;Linha 1
  static g_azul + #40, #3967
  static g_azul + #41, #3967
  static g_azul + #42, #3967
  static g_azul + #43, #3967
  static g_azul + #44, #3967
  static g_azul + #45, #3967
  static g_azul + #46, #3967
  static g_azul + #47, #3967
  static g_azul + #48, #3967
  static g_azul + #49, #3967
  static g_azul + #50, #3967
  static g_azul + #51, #3967
  static g_azul + #52, #3967
  static g_azul + #53, #3967
  static g_azul + #54, #3967
  static g_azul + #55, #3967
  static g_azul + #56, #3967
  static g_azul + #57, #3967
  static g_azul + #58, #3967
  static g_azul + #59, #3967
  static g_azul + #60, #3967
  static g_azul + #61, #3967
  static g_azul + #62, #3967
  static g_azul + #63, #3967
  static g_azul + #64, #3967
  static g_azul + #65, #3967
  static g_azul + #66, #3967
  static g_azul + #67, #3967
  static g_azul + #68, #3967
  static g_azul + #69, #3967
  static g_azul + #70, #3967
  static g_azul + #71, #3967
  static g_azul + #72, #3967
  static g_azul + #73, #3967
  static g_azul + #74, #3967
  static g_azul + #75, #3967
  static g_azul + #76, #3967
  static g_azul + #77, #3967
  static g_azul + #78, #3967
  static g_azul + #79, #3967

  ;Linha 2
  static g_azul + #80, #3967
  static g_azul + #81, #3967
  static g_azul + #82, #3967
  static g_azul + #83, #3967
  static g_azul + #84, #3967
  static g_azul + #85, #3967
  static g_azul + #86, #3967
  static g_azul + #87, #3967
  static g_azul + #88, #3967
  static g_azul + #89, #3967
  static g_azul + #90, #3967
  static g_azul + #91, #3967
  static g_azul + #92, #3967
  static g_azul + #93, #3967
  static g_azul + #94, #3967
  static g_azul + #95, #3967
  static g_azul + #96, #3967
  static g_azul + #97, #3967
  static g_azul + #98, #3967
  static g_azul + #99, #3967
  static g_azul + #100, #3967
  static g_azul + #101, #3967
  static g_azul + #102, #3967
  static g_azul + #103, #3967
  static g_azul + #104, #3967
  static g_azul + #105, #3967
  static g_azul + #106, #3967
  static g_azul + #107, #3967
  static g_azul + #108, #3967
  static g_azul + #109, #3967
  static g_azul + #110, #3967
  static g_azul + #111, #3967
  static g_azul + #112, #3967
  static g_azul + #113, #3967
  static g_azul + #114, #3967
  static g_azul + #115, #3967
  static g_azul + #116, #3967
  static g_azul + #117, #3967
  static g_azul + #118, #3967
  static g_azul + #119, #3967

  ;Linha 3
  static g_azul + #120, #3967
  static g_azul + #121, #3967
  static g_azul + #122, #3967
  static g_azul + #123, #3967
  static g_azul + #124, #3967
  static g_azul + #125, #3967
  static g_azul + #126, #3967
  static g_azul + #127, #3967
  static g_azul + #128, #3967
  static g_azul + #129, #3967
  static g_azul + #130, #3967
  static g_azul + #131, #3967
  static g_azul + #132, #3967
  static g_azul + #133, #3967
  static g_azul + #134, #3967
  static g_azul + #135, #3967
  static g_azul + #136, #3967
  static g_azul + #137, #3967
  static g_azul + #138, #3967
  static g_azul + #139, #3967
  static g_azul + #140, #3967
  static g_azul + #141, #3967
  static g_azul + #142, #3967
  static g_azul + #143, #3967
  static g_azul + #144, #3967
  static g_azul + #145, #3967
  static g_azul + #146, #3967
  static g_azul + #147, #3967
  static g_azul + #148, #3967
  static g_azul + #149, #3967
  static g_azul + #150, #3967
  static g_azul + #151, #3967
  static g_azul + #152, #3967
  static g_azul + #153, #3967
  static g_azul + #154, #3967
  static g_azul + #155, #3967
  static g_azul + #156, #3967
  static g_azul + #157, #3967
  static g_azul + #158, #3967
  static g_azul + #159, #3967

  ;Linha 4
  static g_azul + #160, #3967
  static g_azul + #161, #3967
  static g_azul + #162, #3967
  static g_azul + #163, #3967
  static g_azul + #164, #3967
  static g_azul + #165, #3967
  static g_azul + #166, #3967
  static g_azul + #167, #3967
  static g_azul + #168, #3967
  static g_azul + #169, #3967
  static g_azul + #170, #3967
  static g_azul + #171, #3967
  static g_azul + #172, #3967
  static g_azul + #173, #3967
  static g_azul + #174, #3967
  static g_azul + #175, #3967
  static g_azul + #176, #3967
  static g_azul + #177, #3967
  static g_azul + #178, #3967
  static g_azul + #179, #3967
  static g_azul + #180, #3967
  static g_azul + #181, #3967
  static g_azul + #182, #3967
  static g_azul + #183, #3967
  static g_azul + #184, #3967
  static g_azul + #185, #3967
  static g_azul + #186, #3967
  static g_azul + #187, #3967
  static g_azul + #188, #3967
  static g_azul + #189, #3967
  static g_azul + #190, #3967
  static g_azul + #191, #3967
  static g_azul + #192, #3967
  static g_azul + #193, #3967
  static g_azul + #194, #3967
  static g_azul + #195, #544
  static g_azul + #196, #3967
  static g_azul + #197, #3967
  static g_azul + #198, #3967
  static g_azul + #199, #3967

  ;Linha 5
  static g_azul + #200, #3967
  static g_azul + #201, #3967
  static g_azul + #202, #3967
  static g_azul + #203, #3967
  static g_azul + #204, #2336
  static g_azul + #205, #2336
  static g_azul + #206, #2336
  static g_azul + #207, #2336
  static g_azul + #208, #3967
  static g_azul + #209, #3967
  static g_azul + #210, #3967
  static g_azul + #211, #3967
  static g_azul + #212, #3967
  static g_azul + #213, #3967
  static g_azul + #214, #3967
  static g_azul + #215, #3967
  static g_azul + #216, #3967
  static g_azul + #217, #3967
  static g_azul + #218, #3967
  static g_azul + #219, #32
  static g_azul + #220, #32
  static g_azul + #221, #3967
  static g_azul + #222, #3967
  static g_azul + #223, #3967
  static g_azul + #224, #3967
  static g_azul + #225, #3967
  static g_azul + #226, #3967
  static g_azul + #227, #3967
  static g_azul + #228, #3967
  static g_azul + #229, #3967
  static g_azul + #230, #3967
  static g_azul + #231, #3967
  static g_azul + #232, #3967
  static g_azul + #233, #3967
  static g_azul + #234, #544
  static g_azul + #235, #544
  static g_azul + #236, #3967
  static g_azul + #237, #3967
  static g_azul + #238, #3967
  static g_azul + #239, #3967

  ;Linha 6
  static g_azul + #240, #3967
  static g_azul + #241, #3967
  static g_azul + #242, #3967
  static g_azul + #243, #3967
  static g_azul + #244, #3967
  static g_azul + #245, #3967
  static g_azul + #246, #3967
  static g_azul + #247, #3967
  static g_azul + #248, #3967
  static g_azul + #249, #3967
  static g_azul + #250, #3967
  static g_azul + #251, #3967
  static g_azul + #252, #3967
  static g_azul + #253, #3967
  static g_azul + #254, #3967
  static g_azul + #255, #3967
  static g_azul + #256, #3967
  static g_azul + #257, #0
  static g_azul + #258, #0
  static g_azul + #259, #0
  static g_azul + #260, #0
  static g_azul + #261, #0
  static g_azul + #262, #0
  static g_azul + #263, #0
  static g_azul + #264, #32
  static g_azul + #265, #3967
  static g_azul + #266, #3967
  static g_azul + #267, #3967
  static g_azul + #268, #3967
  static g_azul + #269, #3967
  static g_azul + #270, #3967
  static g_azul + #271, #3967
  static g_azul + #272, #3967
  static g_azul + #273, #3967
  static g_azul + #274, #544
  static g_azul + #275, #544
  static g_azul + #276, #3967
  static g_azul + #277, #3967
  static g_azul + #278, #3967
  static g_azul + #279, #3967

  ;Linha 7
  static g_azul + #280, #3967
  static g_azul + #281, #3967
  static g_azul + #282, #3967
  static g_azul + #283, #3967
  static g_azul + #284, #3967
  static g_azul + #285, #3967
  static g_azul + #286, #3967
  static g_azul + #287, #3967
  static g_azul + #288, #3967
  static g_azul + #289, #3967
  static g_azul + #290, #3967
  static g_azul + #291, #3967
  static g_azul + #292, #3967
  static g_azul + #293, #3967
  static g_azul + #294, #3967
  static g_azul + #295, #0
  static g_azul + #296, #0
  static g_azul + #297, #2048
  static g_azul + #298, #2048
  static g_azul + #299, #2048
  static g_azul + #300, #0
  static g_azul + #301, #2048
  static g_azul + #302, #2048
  static g_azul + #303, #2048
  static g_azul + #304, #0
  static g_azul + #305, #0
  static g_azul + #306, #3967
  static g_azul + #307, #3967
  static g_azul + #308, #3967
  static g_azul + #309, #3967
  static g_azul + #310, #3967
  static g_azul + #311, #3967
  static g_azul + #312, #3967
  static g_azul + #313, #3967
  static g_azul + #314, #3967
  static g_azul + #315, #544
  static g_azul + #316, #3967
  static g_azul + #317, #3967
  static g_azul + #318, #3967
  static g_azul + #319, #3967

  ;Linha 8
  static g_azul + #320, #3967
  static g_azul + #321, #3967
  static g_azul + #322, #3967
  static g_azul + #323, #3967
  static g_azul + #324, #3967
  static g_azul + #325, #3967
  static g_azul + #326, #544
  static g_azul + #327, #3967
  static g_azul + #328, #3967
  static g_azul + #329, #3967
  static g_azul + #330, #3967
  static g_azul + #331, #3967
  static g_azul + #332, #3967
  static g_azul + #333, #0
  static g_azul + #334, #0
  static g_azul + #335, #2048
  static g_azul + #336, #2048
  static g_azul + #337, #2048
  static g_azul + #338, #2048
  static g_azul + #339, #2048
  static g_azul + #340, #0
  static g_azul + #341, #2048
  static g_azul + #342, #2048
  static g_azul + #343, #2048
  static g_azul + #344, #2048
  static g_azul + #345, #2048
  static g_azul + #346, #0
  static g_azul + #347, #0
  static g_azul + #348, #3967
  static g_azul + #349, #3967
  static g_azul + #350, #3967
  static g_azul + #351, #3967
  static g_azul + #352, #3967
  static g_azul + #353, #3967
  static g_azul + #354, #3967
  static g_azul + #355, #544
  static g_azul + #356, #3967
  static g_azul + #357, #3967
  static g_azul + #358, #3967
  static g_azul + #359, #3967

  ;Linha 9
  static g_azul + #360, #3967
  static g_azul + #361, #3967
  static g_azul + #362, #3967
  static g_azul + #363, #3967
  static g_azul + #364, #3967
  static g_azul + #365, #3967
  static g_azul + #366, #544
  static g_azul + #367, #3967
  static g_azul + #368, #3967
  static g_azul + #369, #3967
  static g_azul + #370, #3967
  static g_azul + #371, #3967
  static g_azul + #372, #0
  static g_azul + #373, #2048
  static g_azul + #374, #2048
  static g_azul + #375, #2048
  static g_azul + #376, #2048
  static g_azul + #377, #2048
  static g_azul + #378, #2048
  static g_azul + #379, #2048
  static g_azul + #380, #0
  static g_azul + #381, #2048
  static g_azul + #382, #2048
  static g_azul + #383, #2048
  static g_azul + #384, #2048
  static g_azul + #385, #2048
  static g_azul + #386, #2048
  static g_azul + #387, #2048
  static g_azul + #388, #0
  static g_azul + #389, #3967
  static g_azul + #390, #3967
  static g_azul + #391, #3967
  static g_azul + #392, #3967
  static g_azul + #393, #3967
  static g_azul + #394, #3967
  static g_azul + #395, #3967
  static g_azul + #396, #3967
  static g_azul + #397, #3967
  static g_azul + #398, #3967
  static g_azul + #399, #3967

  ;Linha 10
  static g_azul + #400, #3967
  static g_azul + #401, #3967
  static g_azul + #402, #3967
  static g_azul + #403, #3967
  static g_azul + #404, #3967
  static g_azul + #405, #3967
  static g_azul + #406, #544
  static g_azul + #407, #3967
  static g_azul + #408, #3967
  static g_azul + #409, #3967
  static g_azul + #410, #3967
  static g_azul + #411, #3967
  static g_azul + #412, #0
  static g_azul + #413, #2048
  static g_azul + #414, #2048
  static g_azul + #415, #2048
  static g_azul + #416, #2048
  static g_azul + #417, #2048
  static g_azul + #418, #2048
  static g_azul + #419, #2048
  static g_azul + #420, #0
  static g_azul + #421, #2048
  static g_azul + #422, #2048
  static g_azul + #423, #2048
  static g_azul + #424, #2048
  static g_azul + #425, #2048
  static g_azul + #426, #2048
  static g_azul + #427, #2048
  static g_azul + #428, #0
  static g_azul + #429, #3967
  static g_azul + #430, #3967
  static g_azul + #431, #3967
  static g_azul + #432, #3967
  static g_azul + #433, #3967
  static g_azul + #434, #3967
  static g_azul + #435, #3967
  static g_azul + #436, #544
  static g_azul + #437, #3967
  static g_azul + #438, #3967
  static g_azul + #439, #3967

  ;Linha 11
  static g_azul + #440, #3967
  static g_azul + #441, #3967
  static g_azul + #442, #3967
  static g_azul + #443, #3967
  static g_azul + #444, #3967
  static g_azul + #445, #3967
  static g_azul + #446, #3967
  static g_azul + #447, #3967
  static g_azul + #448, #3967
  static g_azul + #449, #3967
  static g_azul + #450, #3967
  static g_azul + #451, #3967
  static g_azul + #452, #0
  static g_azul + #453, #2048
  static g_azul + #454, #2048
  static g_azul + #455, #2048
  static g_azul + #456, #2048
  static g_azul + #457, #2048
  static g_azul + #458, #0
  static g_azul + #459, #0
  static g_azul + #460, #0
  static g_azul + #461, #0
  static g_azul + #462, #0
  static g_azul + #463, #2048
  static g_azul + #464, #2048
  static g_azul + #465, #2048
  static g_azul + #466, #2048
  static g_azul + #467, #2048
  static g_azul + #468, #0
  static g_azul + #469, #3967
  static g_azul + #470, #3967
  static g_azul + #471, #3967
  static g_azul + #472, #3967
  static g_azul + #473, #3967
  static g_azul + #474, #3967
  static g_azul + #475, #3967
  static g_azul + #476, #544
  static g_azul + #477, #3967
  static g_azul + #478, #3967
  static g_azul + #479, #3967

  ;Linha 12
  static g_azul + #480, #3967
  static g_azul + #481, #3967
  static g_azul + #482, #3967
  static g_azul + #483, #3967
  static g_azul + #484, #3967
  static g_azul + #485, #3967
  static g_azul + #486, #3967
  static g_azul + #487, #3967
  static g_azul + #488, #3967
  static g_azul + #489, #3967
  static g_azul + #490, #3967
  static g_azul + #491, #0
  static g_azul + #492, #2048
  static g_azul + #493, #2048
  static g_azul + #494, #2048
  static g_azul + #495, #2048
  static g_azul + #496, #2048
  static g_azul + #497, #0
  static g_azul + #498, #32
  static g_azul + #499, #32
  static g_azul + #500, #3967
  static g_azul + #501, #3967
  static g_azul + #502, #32
  static g_azul + #503, #0
  static g_azul + #504, #2048
  static g_azul + #505, #2048
  static g_azul + #506, #2048
  static g_azul + #507, #2048
  static g_azul + #508, #2048
  static g_azul + #509, #0
  static g_azul + #510, #3967
  static g_azul + #511, #3967
  static g_azul + #512, #3967
  static g_azul + #513, #3967
  static g_azul + #514, #3967
  static g_azul + #515, #3967
  static g_azul + #516, #3967
  static g_azul + #517, #3967
  static g_azul + #518, #3967
  static g_azul + #519, #3967

  ;Linha 13
  static g_azul + #520, #3967
  static g_azul + #521, #3967
  static g_azul + #522, #3967
  static g_azul + #523, #3967
  static g_azul + #524, #3967
  static g_azul + #525, #3967
  static g_azul + #526, #3967
  static g_azul + #527, #3967
  static g_azul + #528, #3967
  static g_azul + #529, #3967
  static g_azul + #530, #3967
  static g_azul + #531, #0
  static g_azul + #532, #2048
  static g_azul + #533, #2048
  static g_azul + #534, #2048
  static g_azul + #535, #2048
  static g_azul + #536, #0
  static g_azul + #537, #3967
  static g_azul + #538, #3104
  static g_azul + #539, #3967
  static g_azul + #540, #3967
  static g_azul + #541, #3967
  static g_azul + #542, #32
  static g_azul + #543, #32
  static g_azul + #544, #0
  static g_azul + #545, #2048
  static g_azul + #546, #2048
  static g_azul + #547, #2048
  static g_azul + #548, #2048
  static g_azul + #549, #0
  static g_azul + #550, #3967
  static g_azul + #551, #3967
  static g_azul + #552, #3967
  static g_azul + #553, #3967
  static g_azul + #554, #3967
  static g_azul + #555, #3967
  static g_azul + #556, #544
  static g_azul + #557, #3967
  static g_azul + #558, #3967
  static g_azul + #559, #3967

  ;Linha 14
  static g_azul + #560, #3967
  static g_azul + #561, #3967
  static g_azul + #562, #3967
  static g_azul + #563, #3967
  static g_azul + #564, #3967
  static g_azul + #565, #3967
  static g_azul + #566, #3967
  static g_azul + #567, #3967
  static g_azul + #568, #3967
  static g_azul + #569, #3967
  static g_azul + #570, #32
  static g_azul + #571, #0
  static g_azul + #572, #2048
  static g_azul + #573, #2048
  static g_azul + #574, #2048
  static g_azul + #575, #2048
  static g_azul + #576, #0
  static g_azul + #577, #3967
  static g_azul + #578, #3167
  static g_azul + #579, #3167
  static g_azul + #580, #3104
  static g_azul + #581, #3167
  static g_azul + #582, #3167
  static g_azul + #583, #3104
  static g_azul + #584, #0
  static g_azul + #585, #2048
  static g_azul + #586, #2048
  static g_azul + #587, #2048
  static g_azul + #588, #2048
  static g_azul + #589, #0
  static g_azul + #590, #3967
  static g_azul + #591, #3967
  static g_azul + #592, #3967
  static g_azul + #593, #3967
  static g_azul + #594, #3967
  static g_azul + #595, #3967
  static g_azul + #596, #544
  static g_azul + #597, #3967
  static g_azul + #598, #3967
  static g_azul + #599, #3967

  ;Linha 15
  static g_azul + #600, #3967
  static g_azul + #601, #3967
  static g_azul + #602, #3967
  static g_azul + #603, #3967
  static g_azul + #604, #3967
  static g_azul + #605, #3967
  static g_azul + #606, #3967
  static g_azul + #607, #3967
  static g_azul + #608, #3967
  static g_azul + #609, #3967
  static g_azul + #610, #32
  static g_azul + #611, #0
  static g_azul + #612, #0
  static g_azul + #613, #0
  static g_azul + #614, #0
  static g_azul + #615, #0
  static g_azul + #616, #0
  static g_azul + #617, #32
  static g_azul + #618, #32
  static g_azul + #619, #32
  static g_azul + #620, #32
  static g_azul + #621, #32
  static g_azul + #622, #32
  static g_azul + #623, #32
  static g_azul + #624, #0
  static g_azul + #625, #0
  static g_azul + #626, #0
  static g_azul + #627, #0
  static g_azul + #628, #0
  static g_azul + #629, #0
  static g_azul + #630, #32
  static g_azul + #631, #3967
  static g_azul + #632, #3967
  static g_azul + #633, #3967
  static g_azul + #634, #3967
  static g_azul + #635, #3967
  static g_azul + #636, #3967
  static g_azul + #637, #3967
  static g_azul + #638, #3967
  static g_azul + #639, #3967

  ;Linha 16
  static g_azul + #640, #3967
  static g_azul + #641, #3967
  static g_azul + #642, #3967
  static g_azul + #643, #3967
  static g_azul + #644, #3967
  static g_azul + #645, #3967
  static g_azul + #646, #3967
  static g_azul + #647, #3967
  static g_azul + #648, #3967
  static g_azul + #649, #3967
  static g_azul + #650, #32
  static g_azul + #651, #0
  static g_azul + #652, #2048
  static g_azul + #653, #2048
  static g_azul + #654, #2048
  static g_azul + #655, #2048
  static g_azul + #656, #0
  static g_azul + #657, #3967
  static g_azul + #658, #2080
  static g_azul + #659, #544
  static g_azul + #660, #3123
  static g_azul + #661, #544
  static g_azul + #662, #32
  static g_azul + #663, #32
  static g_azul + #664, #0
  static g_azul + #665, #3072
  static g_azul + #666, #3072
  static g_azul + #667, #3072
  static g_azul + #668, #3072
  static g_azul + #669, #0
  static g_azul + #670, #32
  static g_azul + #671, #32
  static g_azul + #672, #3967
  static g_azul + #673, #3967
  static g_azul + #674, #3967
  static g_azul + #675, #544
  static g_azul + #676, #3967
  static g_azul + #677, #3967
  static g_azul + #678, #3967
  static g_azul + #679, #3967

  ;Linha 17
  static g_azul + #680, #3967
  static g_azul + #681, #3967
  static g_azul + #682, #3967
  static g_azul + #683, #3967
  static g_azul + #684, #3967
  static g_azul + #685, #3967
  static g_azul + #686, #3967
  static g_azul + #687, #3967
  static g_azul + #688, #3967
  static g_azul + #689, #3967
  static g_azul + #690, #3967
  static g_azul + #691, #0
  static g_azul + #692, #2048
  static g_azul + #693, #2048
  static g_azul + #694, #2048
  static g_azul + #695, #2048
  static g_azul + #696, #0
  static g_azul + #697, #3967
  static g_azul + #698, #3967
  static g_azul + #699, #3967
  static g_azul + #700, #3967
  static g_azul + #701, #3967
  static g_azul + #702, #32
  static g_azul + #703, #32
  static g_azul + #704, #0
  static g_azul + #705, #3072
  static g_azul + #706, #3072
  static g_azul + #707, #3072
  static g_azul + #708, #3072
  static g_azul + #709, #0
  static g_azul + #710, #3967
  static g_azul + #711, #3967
  static g_azul + #712, #3967
  static g_azul + #713, #3967
  static g_azul + #714, #3967
  static g_azul + #715, #3967
  static g_azul + #716, #3967
  static g_azul + #717, #3967
  static g_azul + #718, #3967
  static g_azul + #719, #3967

  ;Linha 18
  static g_azul + #720, #3967
  static g_azul + #721, #3967
  static g_azul + #722, #3967
  static g_azul + #723, #3967
  static g_azul + #724, #3967
  static g_azul + #725, #3967
  static g_azul + #726, #3967
  static g_azul + #727, #3967
  static g_azul + #728, #3967
  static g_azul + #729, #3967
  static g_azul + #730, #3967
  static g_azul + #731, #0
  static g_azul + #732, #2048
  static g_azul + #733, #2048
  static g_azul + #734, #2048
  static g_azul + #735, #2048
  static g_azul + #736, #2048
  static g_azul + #737, #0
  static g_azul + #738, #3967
  static g_azul + #739, #3967
  static g_azul + #740, #3967
  static g_azul + #741, #3967
  static g_azul + #742, #32
  static g_azul + #743, #0
  static g_azul + #744, #3072
  static g_azul + #745, #3072
  static g_azul + #746, #3072
  static g_azul + #747, #3072
  static g_azul + #748, #3072
  static g_azul + #749, #0
  static g_azul + #750, #3967
  static g_azul + #751, #3967
  static g_azul + #752, #3967
  static g_azul + #753, #3967
  static g_azul + #754, #3967
  static g_azul + #755, #544
  static g_azul + #756, #3967
  static g_azul + #757, #3967
  static g_azul + #758, #3967
  static g_azul + #759, #3967

  ;Linha 19
  static g_azul + #760, #3967
  static g_azul + #761, #3967
  static g_azul + #762, #3967
  static g_azul + #763, #3967
  static g_azul + #764, #3967
  static g_azul + #765, #3967
  static g_azul + #766, #3967
  static g_azul + #767, #3967
  static g_azul + #768, #3967
  static g_azul + #769, #3967
  static g_azul + #770, #3967
  static g_azul + #771, #3967
  static g_azul + #772, #0
  static g_azul + #773, #2048
  static g_azul + #774, #2048
  static g_azul + #775, #2048
  static g_azul + #776, #2048
  static g_azul + #777, #2048
  static g_azul + #778, #0
  static g_azul + #779, #0
  static g_azul + #780, #0
  static g_azul + #781, #0
  static g_azul + #782, #0
  static g_azul + #783, #3072
  static g_azul + #784, #3072
  static g_azul + #785, #3072
  static g_azul + #786, #3072
  static g_azul + #787, #3072
  static g_azul + #788, #0
  static g_azul + #789, #3967
  static g_azul + #790, #3967
  static g_azul + #791, #3967
  static g_azul + #792, #3967
  static g_azul + #793, #3967
  static g_azul + #794, #3967
  static g_azul + #795, #3967
  static g_azul + #796, #3967
  static g_azul + #797, #3967
  static g_azul + #798, #3967
  static g_azul + #799, #3967

  ;Linha 20
  static g_azul + #800, #3967
  static g_azul + #801, #3967
  static g_azul + #802, #3967
  static g_azul + #803, #3967
  static g_azul + #804, #3967
  static g_azul + #805, #3967
  static g_azul + #806, #3967
  static g_azul + #807, #3967
  static g_azul + #808, #3967
  static g_azul + #809, #3967
  static g_azul + #810, #3967
  static g_azul + #811, #3967
  static g_azul + #812, #0
  static g_azul + #813, #2048
  static g_azul + #814, #2048
  static g_azul + #815, #2048
  static g_azul + #816, #2048
  static g_azul + #817, #2048
  static g_azul + #818, #2048
  static g_azul + #819, #2048
  static g_azul + #820, #0
  static g_azul + #821, #3072
  static g_azul + #822, #3072
  static g_azul + #823, #3072
  static g_azul + #824, #3072
  static g_azul + #825, #3072
  static g_azul + #826, #3072
  static g_azul + #827, #3072
  static g_azul + #828, #0
  static g_azul + #829, #3967
  static g_azul + #830, #3967
  static g_azul + #831, #3967
  static g_azul + #832, #3967
  static g_azul + #833, #3967
  static g_azul + #834, #3967
  static g_azul + #835, #544
  static g_azul + #836, #3967
  static g_azul + #837, #3967
  static g_azul + #838, #3967
  static g_azul + #839, #3967

  ;Linha 21
  static g_azul + #840, #3967
  static g_azul + #841, #3967
  static g_azul + #842, #3967
  static g_azul + #843, #3967
  static g_azul + #844, #3967
  static g_azul + #845, #3967
  static g_azul + #846, #3967
  static g_azul + #847, #3967
  static g_azul + #848, #3967
  static g_azul + #849, #3967
  static g_azul + #850, #3967
  static g_azul + #851, #3967
  static g_azul + #852, #0
  static g_azul + #853, #2048
  static g_azul + #854, #2048
  static g_azul + #855, #2048
  static g_azul + #856, #2048
  static g_azul + #857, #2048
  static g_azul + #858, #2048
  static g_azul + #859, #2048
  static g_azul + #860, #0
  static g_azul + #861, #3072
  static g_azul + #862, #3072
  static g_azul + #863, #3072
  static g_azul + #864, #3072
  static g_azul + #865, #3072
  static g_azul + #866, #3072
  static g_azul + #867, #3072
  static g_azul + #868, #0
  static g_azul + #869, #3967
  static g_azul + #870, #3967
  static g_azul + #871, #3967
  static g_azul + #872, #3967
  static g_azul + #873, #3967
  static g_azul + #874, #544
  static g_azul + #875, #3967
  static g_azul + #876, #3967
  static g_azul + #877, #3967
  static g_azul + #878, #3967
  static g_azul + #879, #3967

  ;Linha 22
  static g_azul + #880, #3967
  static g_azul + #881, #3967
  static g_azul + #882, #3967
  static g_azul + #883, #3967
  static g_azul + #884, #3967
  static g_azul + #885, #3967
  static g_azul + #886, #3967
  static g_azul + #887, #3967
  static g_azul + #888, #3967
  static g_azul + #889, #3967
  static g_azul + #890, #3967
  static g_azul + #891, #3967
  static g_azul + #892, #3967
  static g_azul + #893, #0
  static g_azul + #894, #0
  static g_azul + #895, #2048
  static g_azul + #896, #2048
  static g_azul + #897, #2048
  static g_azul + #898, #2048
  static g_azul + #899, #2048
  static g_azul + #900, #0
  static g_azul + #901, #3072
  static g_azul + #902, #3072
  static g_azul + #903, #3072
  static g_azul + #904, #3072
  static g_azul + #905, #3072
  static g_azul + #906, #0
  static g_azul + #907, #0
  static g_azul + #908, #3967
  static g_azul + #909, #3967
  static g_azul + #910, #3967
  static g_azul + #911, #3967
  static g_azul + #912, #3967
  static g_azul + #913, #3967
  static g_azul + #914, #544
  static g_azul + #915, #3967
  static g_azul + #916, #3967
  static g_azul + #917, #3967
  static g_azul + #918, #3967
  static g_azul + #919, #3967

  ;Linha 23
  static g_azul + #920, #3967
  static g_azul + #921, #3967
  static g_azul + #922, #3967
  static g_azul + #923, #3967
  static g_azul + #924, #3967
  static g_azul + #925, #3967
  static g_azul + #926, #3967
  static g_azul + #927, #3967
  static g_azul + #928, #3967
  static g_azul + #929, #3967
  static g_azul + #930, #3967
  static g_azul + #931, #3967
  static g_azul + #932, #3967
  static g_azul + #933, #3967
  static g_azul + #934, #3967
  static g_azul + #935, #0
  static g_azul + #936, #0
  static g_azul + #937, #2048
  static g_azul + #938, #2048
  static g_azul + #939, #2048
  static g_azul + #940, #0
  static g_azul + #941, #3072
  static g_azul + #942, #3072
  static g_azul + #943, #3072
  static g_azul + #944, #0
  static g_azul + #945, #0
  static g_azul + #946, #3967
  static g_azul + #947, #3967
  static g_azul + #948, #3967
  static g_azul + #949, #3967
  static g_azul + #950, #3967
  static g_azul + #951, #3967
  static g_azul + #952, #3967
  static g_azul + #953, #544
  static g_azul + #954, #544
  static g_azul + #955, #3967
  static g_azul + #956, #3967
  static g_azul + #957, #3967
  static g_azul + #958, #3967
  static g_azul + #959, #3967

  ;Linha 24
  static g_azul + #960, #3967
  static g_azul + #961, #3967
  static g_azul + #962, #3967
  static g_azul + #963, #3967
  static g_azul + #964, #3104
  static g_azul + #965, #3104
  static g_azul + #966, #3104
  static g_azul + #967, #3104
  static g_azul + #968, #3967
  static g_azul + #969, #3967
  static g_azul + #970, #3967
  static g_azul + #971, #3967
  static g_azul + #972, #3967
  static g_azul + #973, #3967
  static g_azul + #974, #3967
  static g_azul + #975, #3967
  static g_azul + #976, #3967
  static g_azul + #977, #0
  static g_azul + #978, #0
  static g_azul + #979, #0
  static g_azul + #980, #0
  static g_azul + #981, #0
  static g_azul + #982, #0
  static g_azul + #983, #0
  static g_azul + #984, #3967
  static g_azul + #985, #3967
  static g_azul + #986, #3967
  static g_azul + #987, #3967
  static g_azul + #988, #3967
  static g_azul + #989, #3967
  static g_azul + #990, #3967
  static g_azul + #991, #544
  static g_azul + #992, #544
  static g_azul + #993, #3163
  static g_azul + #994, #3123
  static g_azul + #995, #3165
  static g_azul + #996, #3967
  static g_azul + #997, #3967
  static g_azul + #998, #3967
  static g_azul + #999, #3967

  ;Linha 25
  static g_azul + #1000, #3967
  static g_azul + #1001, #3967
  static g_azul + #1002, #3967
  static g_azul + #1003, #3967
  static g_azul + #1004, #3967
  static g_azul + #1005, #544
  static g_azul + #1006, #544
  static g_azul + #1007, #544
  static g_azul + #1008, #544
  static g_azul + #1009, #3967
  static g_azul + #1010, #3967
  static g_azul + #1011, #3967
  static g_azul + #1012, #3967
  static g_azul + #1013, #3967
  static g_azul + #1014, #3967
  static g_azul + #1015, #3967
  static g_azul + #1016, #3967
  static g_azul + #1017, #3967
  static g_azul + #1018, #3967
  static g_azul + #1019, #32
  static g_azul + #1020, #3967
  static g_azul + #1021, #3967
  static g_azul + #1022, #3967
  static g_azul + #1023, #3967
  static g_azul + #1024, #3967
  static g_azul + #1025, #3967
  static g_azul + #1026, #3967
  static g_azul + #1027, #3967
  static g_azul + #1028, #3967
  static g_azul + #1029, #3967
  static g_azul + #1030, #3967
  static g_azul + #1031, #544
  static g_azul + #1032, #544
  static g_azul + #1033, #544
  static g_azul + #1034, #544
  static g_azul + #1035, #3967
  static g_azul + #1036, #3967
  static g_azul + #1037, #3967
  static g_azul + #1038, #3967
  static g_azul + #1039, #3967

  ;Linha 26
  static g_azul + #1040, #3967
  static g_azul + #1041, #3967
  static g_azul + #1042, #3967
  static g_azul + #1043, #3967
  static g_azul + #1044, #3967
  static g_azul + #1045, #3967
  static g_azul + #1046, #3967
  static g_azul + #1047, #3967
  static g_azul + #1048, #3967
  static g_azul + #1049, #544
  static g_azul + #1050, #544
  static g_azul + #1051, #544
  static g_azul + #1052, #544
  static g_azul + #1053, #3967
  static g_azul + #1054, #3967
  static g_azul + #1055, #3967
  static g_azul + #1056, #3967
  static g_azul + #1057, #3967
  static g_azul + #1058, #3967
  static g_azul + #1059, #544
  static g_azul + #1060, #544
  static g_azul + #1061, #3967
  static g_azul + #1062, #544
  static g_azul + #1063, #3967
  static g_azul + #1064, #544
  static g_azul + #1065, #3967
  static g_azul + #1066, #544
  static g_azul + #1067, #3967
  static g_azul + #1068, #544
  static g_azul + #1069, #3967
  static g_azul + #1070, #544
  static g_azul + #1071, #3967
  static g_azul + #1072, #3967
  static g_azul + #1073, #3967
  static g_azul + #1074, #3967
  static g_azul + #1075, #3967
  static g_azul + #1076, #3967
  static g_azul + #1077, #3967
  static g_azul + #1078, #3967
  static g_azul + #1079, #3967

  ;Linha 27
  static g_azul + #1080, #3967
  static g_azul + #1081, #3967
  static g_azul + #1082, #3967
  static g_azul + #1083, #3967
  static g_azul + #1084, #3967
  static g_azul + #1085, #3967
  static g_azul + #1086, #3967
  static g_azul + #1087, #3967
  static g_azul + #1088, #3967
  static g_azul + #1089, #3967
  static g_azul + #1090, #3967
  static g_azul + #1091, #3967
  static g_azul + #1092, #3967
  static g_azul + #1093, #544
  static g_azul + #1094, #544
  static g_azul + #1095, #544
  static g_azul + #1096, #544
  static g_azul + #1097, #544
  static g_azul + #1098, #3967
  static g_azul + #1099, #3967
  static g_azul + #1100, #3967
  static g_azul + #1101, #3967
  static g_azul + #1102, #3967
  static g_azul + #1103, #3967
  static g_azul + #1104, #3967
  static g_azul + #1105, #3967
  static g_azul + #1106, #3967
  static g_azul + #1107, #3967
  static g_azul + #1108, #3967
  static g_azul + #1109, #3967
  static g_azul + #1110, #3967
  static g_azul + #1111, #3967
  static g_azul + #1112, #3967
  static g_azul + #1113, #3967
  static g_azul + #1114, #3967
  static g_azul + #1115, #3967
  static g_azul + #1116, #3967
  static g_azul + #1117, #3967
  static g_azul + #1118, #3967
  static g_azul + #1119, #3967

  ;Linha 28
  static g_azul + #1120, #3967
  static g_azul + #1121, #3967
  static g_azul + #1122, #3967
  static g_azul + #1123, #3967
  static g_azul + #1124, #3967
  static g_azul + #1125, #3967
  static g_azul + #1126, #3967
  static g_azul + #1127, #3967
  static g_azul + #1128, #3967
  static g_azul + #1129, #3967
  static g_azul + #1130, #3967
  static g_azul + #1131, #3967
  static g_azul + #1132, #3967
  static g_azul + #1133, #3967
  static g_azul + #1134, #3967
  static g_azul + #1135, #3967
  static g_azul + #1136, #3967
  static g_azul + #1137, #3967
  static g_azul + #1138, #3967
  static g_azul + #1139, #3967
  static g_azul + #1140, #3967
  static g_azul + #1141, #3967
  static g_azul + #1142, #3967
  static g_azul + #1143, #3967
  static g_azul + #1144, #3967
  static g_azul + #1145, #3967
  static g_azul + #1146, #3967
  static g_azul + #1147, #3967
  static g_azul + #1148, #3967
  static g_azul + #1149, #3967
  static g_azul + #1150, #3967
  static g_azul + #1151, #3967
  static g_azul + #1152, #3967
  static g_azul + #1153, #3967
  static g_azul + #1154, #3967
  static g_azul + #1155, #3967
  static g_azul + #1156, #3967
  static g_azul + #1157, #3967
  static g_azul + #1158, #3967
  static g_azul + #1159, #3967

  ;Linha 29
  static g_azul + #1160, #3967
  static g_azul + #1161, #3967
  static g_azul + #1162, #3967
  static g_azul + #1163, #3967
  static g_azul + #1164, #3967
  static g_azul + #1165, #3967
  static g_azul + #1166, #3967
  static g_azul + #1167, #3967
  static g_azul + #1168, #3967
  static g_azul + #1169, #3967
  static g_azul + #1170, #3967
  static g_azul + #1171, #3967
  static g_azul + #1172, #3967
  static g_azul + #1173, #3967
  static g_azul + #1174, #3967
  static g_azul + #1175, #3967
  static g_azul + #1176, #3967
  static g_azul + #1177, #3967
  static g_azul + #1178, #3967
  static g_azul + #1179, #3967
  static g_azul + #1180, #3967
  static g_azul + #1181, #3967
  static g_azul + #1182, #3967
  static g_azul + #1183, #3967
  static g_azul + #1184, #3967
  static g_azul + #1185, #3967
  static g_azul + #1186, #3967
  static g_azul + #1187, #3967
  static g_azul + #1188, #3967
  static g_azul + #1189, #3967
  static g_azul + #1190, #3967
  static g_azul + #1191, #3967
  static g_azul + #1192, #3967
  static g_azul + #1193, #3967
  static g_azul + #1194, #3967
  static g_azul + #1195, #3967
  static g_azul + #1196, #3967
  static g_azul + #1197, #3967
  static g_azul + #1198, #3967
  static g_azul + #1199, #3967


;===========Tela Vermelha===========

g_vermelho : var #1200
  ;Linha 0
  static g_vermelho + #0, #3967
  static g_vermelho + #1, #3967
  static g_vermelho + #2, #3967
  static g_vermelho + #3, #3967
  static g_vermelho + #4, #3967
  static g_vermelho + #5, #3967
  static g_vermelho + #6, #3967
  static g_vermelho + #7, #3967
  static g_vermelho + #8, #3967
  static g_vermelho + #9, #3967
  static g_vermelho + #10, #3967
  static g_vermelho + #11, #3967
  static g_vermelho + #12, #3967
  static g_vermelho + #13, #3967
  static g_vermelho + #14, #3967
  static g_vermelho + #15, #3967
  static g_vermelho + #16, #3967
  static g_vermelho + #17, #3967
  static g_vermelho + #18, #3967
  static g_vermelho + #19, #3967
  static g_vermelho + #20, #3967
  static g_vermelho + #21, #3967
  static g_vermelho + #22, #3967
  static g_vermelho + #23, #3967
  static g_vermelho + #24, #3967
  static g_vermelho + #25, #3967
  static g_vermelho + #26, #3967
  static g_vermelho + #27, #3967
  static g_vermelho + #28, #3967
  static g_vermelho + #29, #3967
  static g_vermelho + #30, #3967
  static g_vermelho + #31, #3967
  static g_vermelho + #32, #3967
  static g_vermelho + #33, #3967
  static g_vermelho + #34, #3967
  static g_vermelho + #35, #3967
  static g_vermelho + #36, #3967
  static g_vermelho + #37, #3967
  static g_vermelho + #38, #3967
  static g_vermelho + #39, #3967

  ;Linha 1
  static g_vermelho + #40, #3967
  static g_vermelho + #41, #3967
  static g_vermelho + #42, #3967
  static g_vermelho + #43, #3967
  static g_vermelho + #44, #3967
  static g_vermelho + #45, #3967
  static g_vermelho + #46, #3967
  static g_vermelho + #47, #3967
  static g_vermelho + #48, #3967
  static g_vermelho + #49, #3967
  static g_vermelho + #50, #3967
  static g_vermelho + #51, #3967
  static g_vermelho + #52, #3967
  static g_vermelho + #53, #3967
  static g_vermelho + #54, #3967
  static g_vermelho + #55, #3967
  static g_vermelho + #56, #3967
  static g_vermelho + #57, #3967
  static g_vermelho + #58, #3967
  static g_vermelho + #59, #3967
  static g_vermelho + #60, #3967
  static g_vermelho + #61, #3967
  static g_vermelho + #62, #3967
  static g_vermelho + #63, #3967
  static g_vermelho + #64, #3967
  static g_vermelho + #65, #3967
  static g_vermelho + #66, #3967
  static g_vermelho + #67, #3967
  static g_vermelho + #68, #3967
  static g_vermelho + #69, #3967
  static g_vermelho + #70, #3967
  static g_vermelho + #71, #3967
  static g_vermelho + #72, #3967
  static g_vermelho + #73, #3967
  static g_vermelho + #74, #3967
  static g_vermelho + #75, #3967
  static g_vermelho + #76, #3967
  static g_vermelho + #77, #3967
  static g_vermelho + #78, #3967
  static g_vermelho + #79, #3967

  ;Linha 2
  static g_vermelho + #80, #3967
  static g_vermelho + #81, #3967
  static g_vermelho + #82, #3967
  static g_vermelho + #83, #3967
  static g_vermelho + #84, #3967
  static g_vermelho + #85, #3967
  static g_vermelho + #86, #3967
  static g_vermelho + #87, #3967
  static g_vermelho + #88, #3967
  static g_vermelho + #89, #3967
  static g_vermelho + #90, #3967
  static g_vermelho + #91, #3967
  static g_vermelho + #92, #3967
  static g_vermelho + #93, #3967
  static g_vermelho + #94, #3967
  static g_vermelho + #95, #3967
  static g_vermelho + #96, #3967
  static g_vermelho + #97, #3967
  static g_vermelho + #98, #3967
  static g_vermelho + #99, #3967
  static g_vermelho + #100, #3967
  static g_vermelho + #101, #3967
  static g_vermelho + #102, #3967
  static g_vermelho + #103, #3967
  static g_vermelho + #104, #3967
  static g_vermelho + #105, #3967
  static g_vermelho + #106, #3967
  static g_vermelho + #107, #3967
  static g_vermelho + #108, #3967
  static g_vermelho + #109, #3967
  static g_vermelho + #110, #3967
  static g_vermelho + #111, #3967
  static g_vermelho + #112, #3967
  static g_vermelho + #113, #3967
  static g_vermelho + #114, #3967
  static g_vermelho + #115, #3967
  static g_vermelho + #116, #3967
  static g_vermelho + #117, #3967
  static g_vermelho + #118, #3967
  static g_vermelho + #119, #3967

  ;Linha 3
  static g_vermelho + #120, #3967
  static g_vermelho + #121, #3967
  static g_vermelho + #122, #3967
  static g_vermelho + #123, #3967
  static g_vermelho + #124, #3967
  static g_vermelho + #125, #3967
  static g_vermelho + #126, #3967
  static g_vermelho + #127, #3967
  static g_vermelho + #128, #3967
  static g_vermelho + #129, #3967
  static g_vermelho + #130, #3967
  static g_vermelho + #131, #3967
  static g_vermelho + #132, #3967
  static g_vermelho + #133, #3967
  static g_vermelho + #134, #3967
  static g_vermelho + #135, #3967
  static g_vermelho + #136, #3967
  static g_vermelho + #137, #3967
  static g_vermelho + #138, #3967
  static g_vermelho + #139, #3967
  static g_vermelho + #140, #3967
  static g_vermelho + #141, #3967
  static g_vermelho + #142, #3967
  static g_vermelho + #143, #3967
  static g_vermelho + #144, #3967
  static g_vermelho + #145, #3967
  static g_vermelho + #146, #3967
  static g_vermelho + #147, #3967
  static g_vermelho + #148, #3967
  static g_vermelho + #149, #3967
  static g_vermelho + #150, #3967
  static g_vermelho + #151, #3967
  static g_vermelho + #152, #3967
  static g_vermelho + #153, #3967
  static g_vermelho + #154, #3967
  static g_vermelho + #155, #3967
  static g_vermelho + #156, #3967
  static g_vermelho + #157, #3967
  static g_vermelho + #158, #3967
  static g_vermelho + #159, #3967

  ;Linha 4
  static g_vermelho + #160, #3967
  static g_vermelho + #161, #3967
  static g_vermelho + #162, #3967
  static g_vermelho + #163, #3967
  static g_vermelho + #164, #3967
  static g_vermelho + #165, #3967
  static g_vermelho + #166, #3967
  static g_vermelho + #167, #3967
  static g_vermelho + #168, #3967
  static g_vermelho + #169, #3967
  static g_vermelho + #170, #3967
  static g_vermelho + #171, #3967
  static g_vermelho + #172, #3967
  static g_vermelho + #173, #3967
  static g_vermelho + #174, #3967
  static g_vermelho + #175, #3967
  static g_vermelho + #176, #3967
  static g_vermelho + #177, #3967
  static g_vermelho + #178, #3967
  static g_vermelho + #179, #3967
  static g_vermelho + #180, #3967
  static g_vermelho + #181, #3967
  static g_vermelho + #182, #3967
  static g_vermelho + #183, #3967
  static g_vermelho + #184, #3967
  static g_vermelho + #185, #3967
  static g_vermelho + #186, #3967
  static g_vermelho + #187, #3967
  static g_vermelho + #188, #3967
  static g_vermelho + #189, #3967
  static g_vermelho + #190, #3967
  static g_vermelho + #191, #3967
  static g_vermelho + #192, #3967
  static g_vermelho + #193, #3967
  static g_vermelho + #194, #3967
  static g_vermelho + #195, #544
  static g_vermelho + #196, #3967
  static g_vermelho + #197, #3967
  static g_vermelho + #198, #3967
  static g_vermelho + #199, #3967

  ;Linha 5
  static g_vermelho + #200, #3967
  static g_vermelho + #201, #3967
  static g_vermelho + #202, #3967
  static g_vermelho + #203, #3967
  static g_vermelho + #204, #2336
  static g_vermelho + #205, #2336
  static g_vermelho + #206, #2336
  static g_vermelho + #207, #2336
  static g_vermelho + #208, #3967
  static g_vermelho + #209, #3967
  static g_vermelho + #210, #3967
  static g_vermelho + #211, #3967
  static g_vermelho + #212, #3967
  static g_vermelho + #213, #3967
  static g_vermelho + #214, #3967
  static g_vermelho + #215, #3967
  static g_vermelho + #216, #3967
  static g_vermelho + #217, #3967
  static g_vermelho + #218, #3967
  static g_vermelho + #219, #32
  static g_vermelho + #220, #32
  static g_vermelho + #221, #3967
  static g_vermelho + #222, #3967
  static g_vermelho + #223, #3967
  static g_vermelho + #224, #3967
  static g_vermelho + #225, #3967
  static g_vermelho + #226, #3967
  static g_vermelho + #227, #3967
  static g_vermelho + #228, #3967
  static g_vermelho + #229, #3967
  static g_vermelho + #230, #3967
  static g_vermelho + #231, #3967
  static g_vermelho + #232, #3967
  static g_vermelho + #233, #3967
  static g_vermelho + #234, #544
  static g_vermelho + #235, #544
  static g_vermelho + #236, #3967
  static g_vermelho + #237, #3967
  static g_vermelho + #238, #3967
  static g_vermelho + #239, #3967

  ;Linha 6
  static g_vermelho + #240, #3967
  static g_vermelho + #241, #3967
  static g_vermelho + #242, #3967
  static g_vermelho + #243, #3967
  static g_vermelho + #244, #3967
  static g_vermelho + #245, #3967
  static g_vermelho + #246, #3967
  static g_vermelho + #247, #3967
  static g_vermelho + #248, #3967
  static g_vermelho + #249, #3967
  static g_vermelho + #250, #3967
  static g_vermelho + #251, #3967
  static g_vermelho + #252, #3967
  static g_vermelho + #253, #3967
  static g_vermelho + #254, #3967
  static g_vermelho + #255, #3967
  static g_vermelho + #256, #3967
  static g_vermelho + #257, #0
  static g_vermelho + #258, #0
  static g_vermelho + #259, #0
  static g_vermelho + #260, #0
  static g_vermelho + #261, #0
  static g_vermelho + #262, #0
  static g_vermelho + #263, #0
  static g_vermelho + #264, #32
  static g_vermelho + #265, #3967
  static g_vermelho + #266, #3967
  static g_vermelho + #267, #3967
  static g_vermelho + #268, #3967
  static g_vermelho + #269, #3967
  static g_vermelho + #270, #3967
  static g_vermelho + #271, #3967
  static g_vermelho + #272, #3967
  static g_vermelho + #273, #3967
  static g_vermelho + #274, #544
  static g_vermelho + #275, #544
  static g_vermelho + #276, #3967
  static g_vermelho + #277, #3967
  static g_vermelho + #278, #3967
  static g_vermelho + #279, #3967

  ;Linha 7
  static g_vermelho + #280, #3967
  static g_vermelho + #281, #3967
  static g_vermelho + #282, #3967
  static g_vermelho + #283, #3967
  static g_vermelho + #284, #3967
  static g_vermelho + #285, #3967
  static g_vermelho + #286, #3967
  static g_vermelho + #287, #3967
  static g_vermelho + #288, #3967
  static g_vermelho + #289, #3967
  static g_vermelho + #290, #3967
  static g_vermelho + #291, #3967
  static g_vermelho + #292, #3967
  static g_vermelho + #293, #3967
  static g_vermelho + #294, #3967
  static g_vermelho + #295, #0
  static g_vermelho + #296, #0
  static g_vermelho + #297, #2048
  static g_vermelho + #298, #2048
  static g_vermelho + #299, #2048
  static g_vermelho + #300, #0
  static g_vermelho + #301, #2048
  static g_vermelho + #302, #2048
  static g_vermelho + #303, #2048
  static g_vermelho + #304, #0
  static g_vermelho + #305, #0
  static g_vermelho + #306, #3967
  static g_vermelho + #307, #3967
  static g_vermelho + #308, #3967
  static g_vermelho + #309, #3967
  static g_vermelho + #310, #3967
  static g_vermelho + #311, #3967
  static g_vermelho + #312, #3967
  static g_vermelho + #313, #3967
  static g_vermelho + #314, #3967
  static g_vermelho + #315, #544
  static g_vermelho + #316, #3967
  static g_vermelho + #317, #3967
  static g_vermelho + #318, #3967
  static g_vermelho + #319, #3967

  ;Linha 8
  static g_vermelho + #320, #3967
  static g_vermelho + #321, #3967
  static g_vermelho + #322, #3967
  static g_vermelho + #323, #3967
  static g_vermelho + #324, #3967
  static g_vermelho + #325, #3967
  static g_vermelho + #326, #544
  static g_vermelho + #327, #3967
  static g_vermelho + #328, #3967
  static g_vermelho + #329, #3967
  static g_vermelho + #330, #3967
  static g_vermelho + #331, #3967
  static g_vermelho + #332, #3967
  static g_vermelho + #333, #0
  static g_vermelho + #334, #0
  static g_vermelho + #335, #2048
  static g_vermelho + #336, #2048
  static g_vermelho + #337, #2048
  static g_vermelho + #338, #2048
  static g_vermelho + #339, #2048
  static g_vermelho + #340, #0
  static g_vermelho + #341, #2048
  static g_vermelho + #342, #2048
  static g_vermelho + #343, #2048
  static g_vermelho + #344, #2048
  static g_vermelho + #345, #2048
  static g_vermelho + #346, #0
  static g_vermelho + #347, #0
  static g_vermelho + #348, #3967
  static g_vermelho + #349, #3967
  static g_vermelho + #350, #3967
  static g_vermelho + #351, #3967
  static g_vermelho + #352, #3967
  static g_vermelho + #353, #3967
  static g_vermelho + #354, #3967
  static g_vermelho + #355, #544
  static g_vermelho + #356, #3967
  static g_vermelho + #357, #3967
  static g_vermelho + #358, #3967
  static g_vermelho + #359, #3967

  ;Linha 9
  static g_vermelho + #360, #3967
  static g_vermelho + #361, #3967
  static g_vermelho + #362, #3967
  static g_vermelho + #363, #3967
  static g_vermelho + #364, #3967
  static g_vermelho + #365, #3967
  static g_vermelho + #366, #544
  static g_vermelho + #367, #3967
  static g_vermelho + #368, #3967
  static g_vermelho + #369, #3967
  static g_vermelho + #370, #3967
  static g_vermelho + #371, #3967
  static g_vermelho + #372, #0
  static g_vermelho + #373, #2048
  static g_vermelho + #374, #2048
  static g_vermelho + #375, #2048
  static g_vermelho + #376, #2048
  static g_vermelho + #377, #2048
  static g_vermelho + #378, #2048
  static g_vermelho + #379, #2048
  static g_vermelho + #380, #0
  static g_vermelho + #381, #2048
  static g_vermelho + #382, #2048
  static g_vermelho + #383, #2048
  static g_vermelho + #384, #2048
  static g_vermelho + #385, #2048
  static g_vermelho + #386, #2048
  static g_vermelho + #387, #2048
  static g_vermelho + #388, #0
  static g_vermelho + #389, #3967
  static g_vermelho + #390, #3967
  static g_vermelho + #391, #3967
  static g_vermelho + #392, #3967
  static g_vermelho + #393, #3967
  static g_vermelho + #394, #3967
  static g_vermelho + #395, #3967
  static g_vermelho + #396, #3967
  static g_vermelho + #397, #3967
  static g_vermelho + #398, #3967
  static g_vermelho + #399, #3967

  ;Linha 10
  static g_vermelho + #400, #3967
  static g_vermelho + #401, #3967
  static g_vermelho + #402, #3967
  static g_vermelho + #403, #3967
  static g_vermelho + #404, #3967
  static g_vermelho + #405, #3967
  static g_vermelho + #406, #544
  static g_vermelho + #407, #3967
  static g_vermelho + #408, #3967
  static g_vermelho + #409, #3967
  static g_vermelho + #410, #3967
  static g_vermelho + #411, #3967
  static g_vermelho + #412, #0
  static g_vermelho + #413, #2048
  static g_vermelho + #414, #2048
  static g_vermelho + #415, #2048
  static g_vermelho + #416, #2048
  static g_vermelho + #417, #2048
  static g_vermelho + #418, #2048
  static g_vermelho + #419, #2048
  static g_vermelho + #420, #0
  static g_vermelho + #421, #2048
  static g_vermelho + #422, #2048
  static g_vermelho + #423, #2048
  static g_vermelho + #424, #2048
  static g_vermelho + #425, #2048
  static g_vermelho + #426, #2048
  static g_vermelho + #427, #2048
  static g_vermelho + #428, #0
  static g_vermelho + #429, #3967
  static g_vermelho + #430, #3967
  static g_vermelho + #431, #3967
  static g_vermelho + #432, #3967
  static g_vermelho + #433, #3967
  static g_vermelho + #434, #3967
  static g_vermelho + #435, #3967
  static g_vermelho + #436, #544
  static g_vermelho + #437, #3967
  static g_vermelho + #438, #3967
  static g_vermelho + #439, #3967

  ;Linha 11
  static g_vermelho + #440, #3967
  static g_vermelho + #441, #3967
  static g_vermelho + #442, #3967
  static g_vermelho + #443, #3967
  static g_vermelho + #444, #3967
  static g_vermelho + #445, #3967
  static g_vermelho + #446, #3967
  static g_vermelho + #447, #3967
  static g_vermelho + #448, #3967
  static g_vermelho + #449, #3967
  static g_vermelho + #450, #3967
  static g_vermelho + #451, #3967
  static g_vermelho + #452, #0
  static g_vermelho + #453, #2048
  static g_vermelho + #454, #2048
  static g_vermelho + #455, #2048
  static g_vermelho + #456, #2048
  static g_vermelho + #457, #2048
  static g_vermelho + #458, #0
  static g_vermelho + #459, #0
  static g_vermelho + #460, #0
  static g_vermelho + #461, #0
  static g_vermelho + #462, #0
  static g_vermelho + #463, #2048
  static g_vermelho + #464, #2048
  static g_vermelho + #465, #2048
  static g_vermelho + #466, #2048
  static g_vermelho + #467, #2048
  static g_vermelho + #468, #0
  static g_vermelho + #469, #3967
  static g_vermelho + #470, #3967
  static g_vermelho + #471, #3967
  static g_vermelho + #472, #3967
  static g_vermelho + #473, #3967
  static g_vermelho + #474, #3967
  static g_vermelho + #475, #3967
  static g_vermelho + #476, #544
  static g_vermelho + #477, #3967
  static g_vermelho + #478, #3967
  static g_vermelho + #479, #3967

  ;Linha 12
  static g_vermelho + #480, #3967
  static g_vermelho + #481, #3967
  static g_vermelho + #482, #3967
  static g_vermelho + #483, #3967
  static g_vermelho + #484, #3967
  static g_vermelho + #485, #3967
  static g_vermelho + #486, #3967
  static g_vermelho + #487, #3967
  static g_vermelho + #488, #3967
  static g_vermelho + #489, #3967
  static g_vermelho + #490, #3967
  static g_vermelho + #491, #0
  static g_vermelho + #492, #2048
  static g_vermelho + #493, #2048
  static g_vermelho + #494, #2048
  static g_vermelho + #495, #2048
  static g_vermelho + #496, #2048
  static g_vermelho + #497, #0
  static g_vermelho + #498, #32
  static g_vermelho + #499, #32
  static g_vermelho + #500, #3967
  static g_vermelho + #501, #3967
  static g_vermelho + #502, #32
  static g_vermelho + #503, #0
  static g_vermelho + #504, #2048
  static g_vermelho + #505, #2048
  static g_vermelho + #506, #2048
  static g_vermelho + #507, #2048
  static g_vermelho + #508, #2048
  static g_vermelho + #509, #0
  static g_vermelho + #510, #3967
  static g_vermelho + #511, #3967
  static g_vermelho + #512, #3967
  static g_vermelho + #513, #3967
  static g_vermelho + #514, #3967
  static g_vermelho + #515, #3967
  static g_vermelho + #516, #3967
  static g_vermelho + #517, #3967
  static g_vermelho + #518, #3967
  static g_vermelho + #519, #3967

  ;Linha 13
  static g_vermelho + #520, #3967
  static g_vermelho + #521, #3967
  static g_vermelho + #522, #3967
  static g_vermelho + #523, #3967
  static g_vermelho + #524, #3967
  static g_vermelho + #525, #3967
  static g_vermelho + #526, #3967
  static g_vermelho + #527, #3967
  static g_vermelho + #528, #3967
  static g_vermelho + #529, #3967
  static g_vermelho + #530, #3967
  static g_vermelho + #531, #0
  static g_vermelho + #532, #2048
  static g_vermelho + #533, #2048
  static g_vermelho + #534, #2048
  static g_vermelho + #535, #2048
  static g_vermelho + #536, #0
  static g_vermelho + #537, #3967
  static g_vermelho + #538, #32
  static g_vermelho + #539, #3967
  static g_vermelho + #540, #3967
  static g_vermelho + #541, #3967
  static g_vermelho + #542, #32
  static g_vermelho + #543, #32
  static g_vermelho + #544, #0
  static g_vermelho + #545, #2048
  static g_vermelho + #546, #2048
  static g_vermelho + #547, #2048
  static g_vermelho + #548, #2048
  static g_vermelho + #549, #0
  static g_vermelho + #550, #3967
  static g_vermelho + #551, #3967
  static g_vermelho + #552, #3967
  static g_vermelho + #553, #3967
  static g_vermelho + #554, #3967
  static g_vermelho + #555, #3967
  static g_vermelho + #556, #544
  static g_vermelho + #557, #3967
  static g_vermelho + #558, #3967
  static g_vermelho + #559, #3967

  ;Linha 14
  static g_vermelho + #560, #3967
  static g_vermelho + #561, #3967
  static g_vermelho + #562, #3967
  static g_vermelho + #563, #3967
  static g_vermelho + #564, #3967
  static g_vermelho + #565, #3967
  static g_vermelho + #566, #3967
  static g_vermelho + #567, #3967
  static g_vermelho + #568, #3967
  static g_vermelho + #569, #3967
  static g_vermelho + #570, #32
  static g_vermelho + #571, #0
  static g_vermelho + #572, #2048
  static g_vermelho + #573, #2048
  static g_vermelho + #574, #2048
  static g_vermelho + #575, #2048
  static g_vermelho + #576, #0
  static g_vermelho + #577, #3967
  static g_vermelho + #578, #2351
  static g_vermelho + #579, #2396
  static g_vermelho + #580, #3967
  static g_vermelho + #581, #2351
  static g_vermelho + #582, #2396
  static g_vermelho + #583, #32
  static g_vermelho + #584, #0
  static g_vermelho + #585, #2048
  static g_vermelho + #586, #2048
  static g_vermelho + #587, #2048
  static g_vermelho + #588, #2048
  static g_vermelho + #589, #0
  static g_vermelho + #590, #3967
  static g_vermelho + #591, #3967
  static g_vermelho + #592, #3967
  static g_vermelho + #593, #3967
  static g_vermelho + #594, #3967
  static g_vermelho + #595, #3967
  static g_vermelho + #596, #544
  static g_vermelho + #597, #3967
  static g_vermelho + #598, #3967
  static g_vermelho + #599, #3967

  ;Linha 15
  static g_vermelho + #600, #3967
  static g_vermelho + #601, #3967
  static g_vermelho + #602, #3967
  static g_vermelho + #603, #3967
  static g_vermelho + #604, #3967
  static g_vermelho + #605, #3967
  static g_vermelho + #606, #3967
  static g_vermelho + #607, #3967
  static g_vermelho + #608, #3967
  static g_vermelho + #609, #3967
  static g_vermelho + #610, #32
  static g_vermelho + #611, #0
  static g_vermelho + #612, #0
  static g_vermelho + #613, #0
  static g_vermelho + #614, #0
  static g_vermelho + #615, #0
  static g_vermelho + #616, #0
  static g_vermelho + #617, #32
  static g_vermelho + #618, #32
  static g_vermelho + #619, #32
  static g_vermelho + #620, #32
  static g_vermelho + #621, #32
  static g_vermelho + #622, #32
  static g_vermelho + #623, #32
  static g_vermelho + #624, #0
  static g_vermelho + #625, #0
  static g_vermelho + #626, #0
  static g_vermelho + #627, #0
  static g_vermelho + #628, #0
  static g_vermelho + #629, #0
  static g_vermelho + #630, #32
  static g_vermelho + #631, #3967
  static g_vermelho + #632, #3967
  static g_vermelho + #633, #3967
  static g_vermelho + #634, #3967
  static g_vermelho + #635, #3967
  static g_vermelho + #636, #3967
  static g_vermelho + #637, #3967
  static g_vermelho + #638, #3967
  static g_vermelho + #639, #3967

  ;Linha 16
  static g_vermelho + #640, #3967
  static g_vermelho + #641, #3967
  static g_vermelho + #642, #3967
  static g_vermelho + #643, #3967
  static g_vermelho + #644, #3967
  static g_vermelho + #645, #3967
  static g_vermelho + #646, #3967
  static g_vermelho + #647, #3967
  static g_vermelho + #648, #3967
  static g_vermelho + #649, #3967
  static g_vermelho + #650, #32
  static g_vermelho + #651, #0
  static g_vermelho + #652, #2304
  static g_vermelho + #653, #2304
  static g_vermelho + #654, #2304
  static g_vermelho + #655, #2304
  static g_vermelho + #656, #0
  static g_vermelho + #657, #3967
  static g_vermelho + #658, #2080
  static g_vermelho + #659, #544
  static g_vermelho + #660, #2383
  static g_vermelho + #661, #544
  static g_vermelho + #662, #32
  static g_vermelho + #663, #32
  static g_vermelho + #664, #0
  static g_vermelho + #665, #2048
  static g_vermelho + #666, #2048
  static g_vermelho + #667, #2048
  static g_vermelho + #668, #2048
  static g_vermelho + #669, #0
  static g_vermelho + #670, #32
  static g_vermelho + #671, #32
  static g_vermelho + #672, #3967
  static g_vermelho + #673, #3967
  static g_vermelho + #674, #3967
  static g_vermelho + #675, #544
  static g_vermelho + #676, #3967
  static g_vermelho + #677, #3967
  static g_vermelho + #678, #3967
  static g_vermelho + #679, #3967

  ;Linha 17
  static g_vermelho + #680, #3967
  static g_vermelho + #681, #3967
  static g_vermelho + #682, #3967
  static g_vermelho + #683, #3967
  static g_vermelho + #684, #3967
  static g_vermelho + #685, #3967
  static g_vermelho + #686, #3967
  static g_vermelho + #687, #3967
  static g_vermelho + #688, #3967
  static g_vermelho + #689, #3967
  static g_vermelho + #690, #3967
  static g_vermelho + #691, #0
  static g_vermelho + #692, #2304
  static g_vermelho + #693, #2304
  static g_vermelho + #694, #2304
  static g_vermelho + #695, #2304
  static g_vermelho + #696, #0
  static g_vermelho + #697, #3967
  static g_vermelho + #698, #3967
  static g_vermelho + #699, #3967
  static g_vermelho + #700, #3967
  static g_vermelho + #701, #3967
  static g_vermelho + #702, #32
  static g_vermelho + #703, #32
  static g_vermelho + #704, #0
  static g_vermelho + #705, #2048
  static g_vermelho + #706, #2048
  static g_vermelho + #707, #2048
  static g_vermelho + #708, #2048
  static g_vermelho + #709, #0
  static g_vermelho + #710, #3967
  static g_vermelho + #711, #3967
  static g_vermelho + #712, #3967
  static g_vermelho + #713, #3967
  static g_vermelho + #714, #3967
  static g_vermelho + #715, #3967
  static g_vermelho + #716, #3967
  static g_vermelho + #717, #3967
  static g_vermelho + #718, #3967
  static g_vermelho + #719, #3967

  ;Linha 18
  static g_vermelho + #720, #3967
  static g_vermelho + #721, #3967
  static g_vermelho + #722, #3967
  static g_vermelho + #723, #3967
  static g_vermelho + #724, #3967
  static g_vermelho + #725, #3967
  static g_vermelho + #726, #3967
  static g_vermelho + #727, #3967
  static g_vermelho + #728, #3967
  static g_vermelho + #729, #3967
  static g_vermelho + #730, #3967
  static g_vermelho + #731, #0
  static g_vermelho + #732, #2304
  static g_vermelho + #733, #2304
  static g_vermelho + #734, #2304
  static g_vermelho + #735, #2304
  static g_vermelho + #736, #2304
  static g_vermelho + #737, #0
  static g_vermelho + #738, #3967
  static g_vermelho + #739, #3967
  static g_vermelho + #740, #3967
  static g_vermelho + #741, #3967
  static g_vermelho + #742, #32
  static g_vermelho + #743, #0
  static g_vermelho + #744, #2048
  static g_vermelho + #745, #2048
  static g_vermelho + #746, #2048
  static g_vermelho + #747, #2048
  static g_vermelho + #748, #2048
  static g_vermelho + #749, #0
  static g_vermelho + #750, #3967
  static g_vermelho + #751, #3967
  static g_vermelho + #752, #3967
  static g_vermelho + #753, #3967
  static g_vermelho + #754, #3967
  static g_vermelho + #755, #544
  static g_vermelho + #756, #3967
  static g_vermelho + #757, #3967
  static g_vermelho + #758, #3967
  static g_vermelho + #759, #3967

  ;Linha 19
  static g_vermelho + #760, #3967
  static g_vermelho + #761, #3967
  static g_vermelho + #762, #3967
  static g_vermelho + #763, #3967
  static g_vermelho + #764, #3967
  static g_vermelho + #765, #3967
  static g_vermelho + #766, #3967
  static g_vermelho + #767, #3967
  static g_vermelho + #768, #3967
  static g_vermelho + #769, #3967
  static g_vermelho + #770, #3967
  static g_vermelho + #771, #3967
  static g_vermelho + #772, #0
  static g_vermelho + #773, #2304
  static g_vermelho + #774, #2304
  static g_vermelho + #775, #2304
  static g_vermelho + #776, #2304
  static g_vermelho + #777, #2304
  static g_vermelho + #778, #0
  static g_vermelho + #779, #0
  static g_vermelho + #780, #0
  static g_vermelho + #781, #0
  static g_vermelho + #782, #0
  static g_vermelho + #783, #2048
  static g_vermelho + #784, #2048
  static g_vermelho + #785, #2048
  static g_vermelho + #786, #2048
  static g_vermelho + #787, #2048
  static g_vermelho + #788, #0
  static g_vermelho + #789, #3967
  static g_vermelho + #790, #3967
  static g_vermelho + #791, #3967
  static g_vermelho + #792, #3967
  static g_vermelho + #793, #3967
  static g_vermelho + #794, #3967
  static g_vermelho + #795, #3967
  static g_vermelho + #796, #3967
  static g_vermelho + #797, #3967
  static g_vermelho + #798, #3967
  static g_vermelho + #799, #3967

  ;Linha 20
  static g_vermelho + #800, #3967
  static g_vermelho + #801, #3967
  static g_vermelho + #802, #3967
  static g_vermelho + #803, #3967
  static g_vermelho + #804, #3967
  static g_vermelho + #805, #3967
  static g_vermelho + #806, #3967
  static g_vermelho + #807, #3967
  static g_vermelho + #808, #3967
  static g_vermelho + #809, #3967
  static g_vermelho + #810, #3967
  static g_vermelho + #811, #3967
  static g_vermelho + #812, #0
  static g_vermelho + #813, #2304
  static g_vermelho + #814, #2304
  static g_vermelho + #815, #2304
  static g_vermelho + #816, #2304
  static g_vermelho + #817, #2304
  static g_vermelho + #818, #2304
  static g_vermelho + #819, #2304
  static g_vermelho + #820, #0
  static g_vermelho + #821, #2048
  static g_vermelho + #822, #2048
  static g_vermelho + #823, #2048
  static g_vermelho + #824, #2048
  static g_vermelho + #825, #2048
  static g_vermelho + #826, #2048
  static g_vermelho + #827, #2048
  static g_vermelho + #828, #0
  static g_vermelho + #829, #3967
  static g_vermelho + #830, #3967
  static g_vermelho + #831, #3967
  static g_vermelho + #832, #3967
  static g_vermelho + #833, #3967
  static g_vermelho + #834, #3967
  static g_vermelho + #835, #544
  static g_vermelho + #836, #3967
  static g_vermelho + #837, #3967
  static g_vermelho + #838, #3967
  static g_vermelho + #839, #3967

  ;Linha 21
  static g_vermelho + #840, #3967
  static g_vermelho + #841, #3967
  static g_vermelho + #842, #3967
  static g_vermelho + #843, #3967
  static g_vermelho + #844, #3967
  static g_vermelho + #845, #3967
  static g_vermelho + #846, #3967
  static g_vermelho + #847, #3967
  static g_vermelho + #848, #3967
  static g_vermelho + #849, #3967
  static g_vermelho + #850, #3967
  static g_vermelho + #851, #3967
  static g_vermelho + #852, #0
  static g_vermelho + #853, #2304
  static g_vermelho + #854, #2304
  static g_vermelho + #855, #2304
  static g_vermelho + #856, #2304
  static g_vermelho + #857, #2304
  static g_vermelho + #858, #2304
  static g_vermelho + #859, #2304
  static g_vermelho + #860, #0
  static g_vermelho + #861, #2048
  static g_vermelho + #862, #2048
  static g_vermelho + #863, #2048
  static g_vermelho + #864, #2048
  static g_vermelho + #865, #2048
  static g_vermelho + #866, #2048
  static g_vermelho + #867, #2048
  static g_vermelho + #868, #0
  static g_vermelho + #869, #3967
  static g_vermelho + #870, #3967
  static g_vermelho + #871, #3967
  static g_vermelho + #872, #3967
  static g_vermelho + #873, #3967
  static g_vermelho + #874, #544
  static g_vermelho + #875, #3967
  static g_vermelho + #876, #3967
  static g_vermelho + #877, #3967
  static g_vermelho + #878, #3967
  static g_vermelho + #879, #3967

  ;Linha 22
  static g_vermelho + #880, #3967
  static g_vermelho + #881, #3967
  static g_vermelho + #882, #3967
  static g_vermelho + #883, #3967
  static g_vermelho + #884, #3967
  static g_vermelho + #885, #3967
  static g_vermelho + #886, #3967
  static g_vermelho + #887, #3967
  static g_vermelho + #888, #3967
  static g_vermelho + #889, #3967
  static g_vermelho + #890, #3967
  static g_vermelho + #891, #3967
  static g_vermelho + #892, #3967
  static g_vermelho + #893, #0
  static g_vermelho + #894, #0
  static g_vermelho + #895, #2304
  static g_vermelho + #896, #2304
  static g_vermelho + #897, #2304
  static g_vermelho + #898, #2304
  static g_vermelho + #899, #2304
  static g_vermelho + #900, #0
  static g_vermelho + #901, #2048
  static g_vermelho + #902, #2048
  static g_vermelho + #903, #2048
  static g_vermelho + #904, #2048
  static g_vermelho + #905, #2048
  static g_vermelho + #906, #0
  static g_vermelho + #907, #0
  static g_vermelho + #908, #3967
  static g_vermelho + #909, #3967
  static g_vermelho + #910, #3967
  static g_vermelho + #911, #3967
  static g_vermelho + #912, #3967
  static g_vermelho + #913, #3967
  static g_vermelho + #914, #544
  static g_vermelho + #915, #3967
  static g_vermelho + #916, #3967
  static g_vermelho + #917, #3967
  static g_vermelho + #918, #3967
  static g_vermelho + #919, #3967

  ;Linha 23
  static g_vermelho + #920, #3967
  static g_vermelho + #921, #3967
  static g_vermelho + #922, #3967
  static g_vermelho + #923, #3967
  static g_vermelho + #924, #3967
  static g_vermelho + #925, #3967
  static g_vermelho + #926, #3967
  static g_vermelho + #927, #3967
  static g_vermelho + #928, #3967
  static g_vermelho + #929, #3967
  static g_vermelho + #930, #3967
  static g_vermelho + #931, #3967
  static g_vermelho + #932, #3967
  static g_vermelho + #933, #3967
  static g_vermelho + #934, #3967
  static g_vermelho + #935, #0
  static g_vermelho + #936, #0
  static g_vermelho + #937, #2304
  static g_vermelho + #938, #2304
  static g_vermelho + #939, #2304
  static g_vermelho + #940, #0
  static g_vermelho + #941, #2048
  static g_vermelho + #942, #2048
  static g_vermelho + #943, #2048
  static g_vermelho + #944, #0
  static g_vermelho + #945, #0
  static g_vermelho + #946, #3967
  static g_vermelho + #947, #3967
  static g_vermelho + #948, #3967
  static g_vermelho + #949, #3967
  static g_vermelho + #950, #3967
  static g_vermelho + #951, #3967
  static g_vermelho + #952, #3967
  static g_vermelho + #953, #544
  static g_vermelho + #954, #544
  static g_vermelho + #955, #3967
  static g_vermelho + #956, #3967
  static g_vermelho + #957, #3967
  static g_vermelho + #958, #3967
  static g_vermelho + #959, #3967

  ;Linha 24
  static g_vermelho + #960, #3967
  static g_vermelho + #961, #3967
  static g_vermelho + #962, #3967
  static g_vermelho + #963, #3967
  static g_vermelho + #964, #3967
  static g_vermelho + #965, #2395
  static g_vermelho + #966, #2354
  static g_vermelho + #967, #2397
  static g_vermelho + #968, #3967
  static g_vermelho + #969, #3967
  static g_vermelho + #970, #3967
  static g_vermelho + #971, #3967
  static g_vermelho + #972, #3967
  static g_vermelho + #973, #3967
  static g_vermelho + #974, #3967
  static g_vermelho + #975, #3967
  static g_vermelho + #976, #3967
  static g_vermelho + #977, #0
  static g_vermelho + #978, #0
  static g_vermelho + #979, #0
  static g_vermelho + #980, #0
  static g_vermelho + #981, #0
  static g_vermelho + #982, #0
  static g_vermelho + #983, #0
  static g_vermelho + #984, #3967
  static g_vermelho + #985, #3967
  static g_vermelho + #986, #3967
  static g_vermelho + #987, #3967
  static g_vermelho + #988, #3967
  static g_vermelho + #989, #3967
  static g_vermelho + #990, #3967
  static g_vermelho + #991, #544
  static g_vermelho + #992, #544
  static g_vermelho + #993, #544
  static g_vermelho + #994, #544
  static g_vermelho + #995, #544
  static g_vermelho + #996, #3967
  static g_vermelho + #997, #3967
  static g_vermelho + #998, #3967
  static g_vermelho + #999, #3967

  ;Linha 25
  static g_vermelho + #1000, #3967
  static g_vermelho + #1001, #3967
  static g_vermelho + #1002, #3967
  static g_vermelho + #1003, #3967
  static g_vermelho + #1004, #3967
  static g_vermelho + #1005, #544
  static g_vermelho + #1006, #544
  static g_vermelho + #1007, #544
  static g_vermelho + #1008, #544
  static g_vermelho + #1009, #3967
  static g_vermelho + #1010, #3967
  static g_vermelho + #1011, #3967
  static g_vermelho + #1012, #3967
  static g_vermelho + #1013, #3967
  static g_vermelho + #1014, #3967
  static g_vermelho + #1015, #3967
  static g_vermelho + #1016, #3967
  static g_vermelho + #1017, #3967
  static g_vermelho + #1018, #3967
  static g_vermelho + #1019, #32
  static g_vermelho + #1020, #3967
  static g_vermelho + #1021, #3967
  static g_vermelho + #1022, #3967
  static g_vermelho + #1023, #3967
  static g_vermelho + #1024, #3967
  static g_vermelho + #1025, #3967
  static g_vermelho + #1026, #3967
  static g_vermelho + #1027, #3967
  static g_vermelho + #1028, #3967
  static g_vermelho + #1029, #3967
  static g_vermelho + #1030, #3967
  static g_vermelho + #1031, #544
  static g_vermelho + #1032, #544
  static g_vermelho + #1033, #544
  static g_vermelho + #1034, #544
  static g_vermelho + #1035, #3967
  static g_vermelho + #1036, #3967
  static g_vermelho + #1037, #3967
  static g_vermelho + #1038, #3967
  static g_vermelho + #1039, #3967

  ;Linha 26
  static g_vermelho + #1040, #3967
  static g_vermelho + #1041, #3967
  static g_vermelho + #1042, #3967
  static g_vermelho + #1043, #3967
  static g_vermelho + #1044, #3967
  static g_vermelho + #1045, #3967
  static g_vermelho + #1046, #3967
  static g_vermelho + #1047, #3967
  static g_vermelho + #1048, #3967
  static g_vermelho + #1049, #544
  static g_vermelho + #1050, #544
  static g_vermelho + #1051, #544
  static g_vermelho + #1052, #544
  static g_vermelho + #1053, #3967
  static g_vermelho + #1054, #3967
  static g_vermelho + #1055, #3967
  static g_vermelho + #1056, #3967
  static g_vermelho + #1057, #3967
  static g_vermelho + #1058, #3967
  static g_vermelho + #1059, #544
  static g_vermelho + #1060, #544
  static g_vermelho + #1061, #3967
  static g_vermelho + #1062, #544
  static g_vermelho + #1063, #3967
  static g_vermelho + #1064, #544
  static g_vermelho + #1065, #3967
  static g_vermelho + #1066, #544
  static g_vermelho + #1067, #3967
  static g_vermelho + #1068, #544
  static g_vermelho + #1069, #3967
  static g_vermelho + #1070, #544
  static g_vermelho + #1071, #3967
  static g_vermelho + #1072, #3967
  static g_vermelho + #1073, #3967
  static g_vermelho + #1074, #3967
  static g_vermelho + #1075, #3967
  static g_vermelho + #1076, #3967
  static g_vermelho + #1077, #3967
  static g_vermelho + #1078, #3967
  static g_vermelho + #1079, #3967

  ;Linha 27
  static g_vermelho + #1080, #3967
  static g_vermelho + #1081, #3967
  static g_vermelho + #1082, #3967
  static g_vermelho + #1083, #3967
  static g_vermelho + #1084, #3967
  static g_vermelho + #1085, #3967
  static g_vermelho + #1086, #3967
  static g_vermelho + #1087, #3967
  static g_vermelho + #1088, #3967
  static g_vermelho + #1089, #3967
  static g_vermelho + #1090, #3967
  static g_vermelho + #1091, #3967
  static g_vermelho + #1092, #3967
  static g_vermelho + #1093, #544
  static g_vermelho + #1094, #544
  static g_vermelho + #1095, #544
  static g_vermelho + #1096, #544
  static g_vermelho + #1097, #544
  static g_vermelho + #1098, #3967
  static g_vermelho + #1099, #3967
  static g_vermelho + #1100, #3967
  static g_vermelho + #1101, #3967
  static g_vermelho + #1102, #3967
  static g_vermelho + #1103, #3967
  static g_vermelho + #1104, #3967
  static g_vermelho + #1105, #3967
  static g_vermelho + #1106, #3967
  static g_vermelho + #1107, #3967
  static g_vermelho + #1108, #3967
  static g_vermelho + #1109, #3967
  static g_vermelho + #1110, #3967
  static g_vermelho + #1111, #3967
  static g_vermelho + #1112, #3967
  static g_vermelho + #1113, #3967
  static g_vermelho + #1114, #3967
  static g_vermelho + #1115, #3967
  static g_vermelho + #1116, #3967
  static g_vermelho + #1117, #3967
  static g_vermelho + #1118, #3967
  static g_vermelho + #1119, #3967

  ;Linha 28
  static g_vermelho + #1120, #3967
  static g_vermelho + #1121, #3967
  static g_vermelho + #1122, #3967
  static g_vermelho + #1123, #3967
  static g_vermelho + #1124, #3967
  static g_vermelho + #1125, #3967
  static g_vermelho + #1126, #3967
  static g_vermelho + #1127, #3967
  static g_vermelho + #1128, #3967
  static g_vermelho + #1129, #3967
  static g_vermelho + #1130, #3967
  static g_vermelho + #1131, #3967
  static g_vermelho + #1132, #3967
  static g_vermelho + #1133, #3967
  static g_vermelho + #1134, #3967
  static g_vermelho + #1135, #3967
  static g_vermelho + #1136, #3967
  static g_vermelho + #1137, #3967
  static g_vermelho + #1138, #3967
  static g_vermelho + #1139, #3967
  static g_vermelho + #1140, #3967
  static g_vermelho + #1141, #3967
  static g_vermelho + #1142, #3967
  static g_vermelho + #1143, #3967
  static g_vermelho + #1144, #3967
  static g_vermelho + #1145, #3967
  static g_vermelho + #1146, #3967
  static g_vermelho + #1147, #3967
  static g_vermelho + #1148, #3967
  static g_vermelho + #1149, #3967
  static g_vermelho + #1150, #3967
  static g_vermelho + #1151, #3967
  static g_vermelho + #1152, #3967
  static g_vermelho + #1153, #3967
  static g_vermelho + #1154, #3967
  static g_vermelho + #1155, #3967
  static g_vermelho + #1156, #3967
  static g_vermelho + #1157, #3967
  static g_vermelho + #1158, #3967
  static g_vermelho + #1159, #3967

  ;Linha 29
  static g_vermelho + #1160, #3967
  static g_vermelho + #1161, #3967
  static g_vermelho + #1162, #3967
  static g_vermelho + #1163, #3967
  static g_vermelho + #1164, #3967
  static g_vermelho + #1165, #3967
  static g_vermelho + #1166, #3967
  static g_vermelho + #1167, #3967
  static g_vermelho + #1168, #3967
  static g_vermelho + #1169, #3967
  static g_vermelho + #1170, #3967
  static g_vermelho + #1171, #3967
  static g_vermelho + #1172, #3967
  static g_vermelho + #1173, #3967
  static g_vermelho + #1174, #3967
  static g_vermelho + #1175, #3967
  static g_vermelho + #1176, #3967
  static g_vermelho + #1177, #3967
  static g_vermelho + #1178, #3967
  static g_vermelho + #1179, #3967
  static g_vermelho + #1180, #3967
  static g_vermelho + #1181, #3967
  static g_vermelho + #1182, #3967
  static g_vermelho + #1183, #3967
  static g_vermelho + #1184, #3967
  static g_vermelho + #1185, #3967
  static g_vermelho + #1186, #3967
  static g_vermelho + #1187, #3967
  static g_vermelho + #1188, #3967
  static g_vermelho + #1189, #3967
  static g_vermelho + #1190, #3967
  static g_vermelho + #1191, #3967
  static g_vermelho + #1192, #3967
  static g_vermelho + #1193, #3967
  static g_vermelho + #1194, #3967
  static g_vermelho + #1195, #3967
  static g_vermelho + #1196, #3967
  static g_vermelho + #1197, #3967
  static g_vermelho + #1198, #3967
  static g_vermelho + #1199, #3967

;===========Tela Neutra=============

g_neutro : var #1200
  ;Linha 0
  static g_neutro + #0, #3967
  static g_neutro + #1, #3967
  static g_neutro + #2, #3967
  static g_neutro + #3, #3967
  static g_neutro + #4, #3967
  static g_neutro + #5, #3967
  static g_neutro + #6, #3967
  static g_neutro + #7, #3967
  static g_neutro + #8, #3967
  static g_neutro + #9, #3967
  static g_neutro + #10, #3967
  static g_neutro + #11, #3967
  static g_neutro + #12, #3967
  static g_neutro + #13, #3967
  static g_neutro + #14, #3967
  static g_neutro + #15, #3967
  static g_neutro + #16, #3967
  static g_neutro + #17, #3967
  static g_neutro + #18, #3967
  static g_neutro + #19, #3967
  static g_neutro + #20, #3967
  static g_neutro + #21, #3967
  static g_neutro + #22, #3967
  static g_neutro + #23, #3967
  static g_neutro + #24, #3967
  static g_neutro + #25, #3967
  static g_neutro + #26, #3967
  static g_neutro + #27, #3967
  static g_neutro + #28, #3967
  static g_neutro + #29, #3967
  static g_neutro + #30, #3967
  static g_neutro + #31, #3967
  static g_neutro + #32, #3967
  static g_neutro + #33, #3967
  static g_neutro + #34, #3967
  static g_neutro + #35, #3967
  static g_neutro + #36, #3967
  static g_neutro + #37, #3967
  static g_neutro + #38, #3967
  static g_neutro + #39, #3967

  ;Linha 1
  static g_neutro + #40, #3967
  static g_neutro + #41, #3967
  static g_neutro + #42, #3967
  static g_neutro + #43, #3967
  static g_neutro + #44, #3967
  static g_neutro + #45, #3967
  static g_neutro + #46, #3967
  static g_neutro + #47, #3967
  static g_neutro + #48, #3967
  static g_neutro + #49, #3967
  static g_neutro + #50, #3967
  static g_neutro + #51, #3967
  static g_neutro + #52, #3967
  static g_neutro + #53, #3967
  static g_neutro + #54, #3967
  static g_neutro + #55, #3967
  static g_neutro + #56, #3967
  static g_neutro + #57, #3967
  static g_neutro + #58, #3967
  static g_neutro + #59, #3967
  static g_neutro + #60, #3967
  static g_neutro + #61, #3967
  static g_neutro + #62, #3967
  static g_neutro + #63, #3967
  static g_neutro + #64, #3967
  static g_neutro + #65, #3967
  static g_neutro + #66, #3967
  static g_neutro + #67, #3967
  static g_neutro + #68, #3967
  static g_neutro + #69, #3967
  static g_neutro + #70, #3967
  static g_neutro + #71, #3967
  static g_neutro + #72, #3967
  static g_neutro + #73, #3967
  static g_neutro + #74, #3967
  static g_neutro + #75, #3967
  static g_neutro + #76, #3967
  static g_neutro + #77, #3967
  static g_neutro + #78, #3967
  static g_neutro + #79, #3967

  ;Linha 2
  static g_neutro + #80, #3967
  static g_neutro + #81, #3967
  static g_neutro + #82, #3967
  static g_neutro + #83, #3967
  static g_neutro + #84, #3967
  static g_neutro + #85, #3967
  static g_neutro + #86, #3967
  static g_neutro + #87, #3967
  static g_neutro + #88, #3967
  static g_neutro + #89, #3967
  static g_neutro + #90, #3967
  static g_neutro + #91, #3967
  static g_neutro + #92, #3967
  static g_neutro + #93, #3967
  static g_neutro + #94, #3967
  static g_neutro + #95, #3967
  static g_neutro + #96, #3967
  static g_neutro + #97, #3967
  static g_neutro + #98, #3967
  static g_neutro + #99, #3967
  static g_neutro + #100, #3967
  static g_neutro + #101, #3967
  static g_neutro + #102, #3967
  static g_neutro + #103, #3967
  static g_neutro + #104, #3967
  static g_neutro + #105, #3967
  static g_neutro + #106, #3967
  static g_neutro + #107, #3967
  static g_neutro + #108, #3967
  static g_neutro + #109, #3967
  static g_neutro + #110, #3967
  static g_neutro + #111, #3967
  static g_neutro + #112, #3967
  static g_neutro + #113, #3967
  static g_neutro + #114, #3967
  static g_neutro + #115, #3967
  static g_neutro + #116, #3967
  static g_neutro + #117, #3967
  static g_neutro + #118, #3967
  static g_neutro + #119, #3967

  ;Linha 3
  static g_neutro + #120, #3967
  static g_neutro + #121, #3967
  static g_neutro + #122, #3967
  static g_neutro + #123, #3967
  static g_neutro + #124, #3967
  static g_neutro + #125, #3967
  static g_neutro + #126, #3967
  static g_neutro + #127, #3967
  static g_neutro + #128, #3967
  static g_neutro + #129, #3967
  static g_neutro + #130, #3967
  static g_neutro + #131, #3967
  static g_neutro + #132, #3967
  static g_neutro + #133, #3967
  static g_neutro + #134, #3967
  static g_neutro + #135, #3967
  static g_neutro + #136, #3967
  static g_neutro + #137, #3967
  static g_neutro + #138, #3967
  static g_neutro + #139, #3967
  static g_neutro + #140, #3967
  static g_neutro + #141, #3967
  static g_neutro + #142, #3967
  static g_neutro + #143, #3967
  static g_neutro + #144, #3967
  static g_neutro + #145, #3967
  static g_neutro + #146, #3967
  static g_neutro + #147, #3967
  static g_neutro + #148, #3967
  static g_neutro + #149, #3967
  static g_neutro + #150, #3967
  static g_neutro + #151, #3967
  static g_neutro + #152, #3967
  static g_neutro + #153, #3967
  static g_neutro + #154, #3967
  static g_neutro + #155, #3967
  static g_neutro + #156, #3967
  static g_neutro + #157, #3967
  static g_neutro + #158, #3967
  static g_neutro + #159, #3967

  ;Linha 4
  static g_neutro + #160, #3967
  static g_neutro + #161, #3967
  static g_neutro + #162, #3967
  static g_neutro + #163, #3967
  static g_neutro + #164, #3967
  static g_neutro + #165, #3967
  static g_neutro + #166, #3967
  static g_neutro + #167, #3967
  static g_neutro + #168, #3967
  static g_neutro + #169, #3967
  static g_neutro + #170, #3967
  static g_neutro + #171, #3967
  static g_neutro + #172, #3967
  static g_neutro + #173, #3967
  static g_neutro + #174, #3967
  static g_neutro + #175, #3967
  static g_neutro + #176, #3967
  static g_neutro + #177, #3967
  static g_neutro + #178, #3967
  static g_neutro + #179, #3967
  static g_neutro + #180, #3967
  static g_neutro + #181, #3967
  static g_neutro + #182, #3967
  static g_neutro + #183, #3967
  static g_neutro + #184, #3967
  static g_neutro + #185, #3967
  static g_neutro + #186, #3967
  static g_neutro + #187, #3967
  static g_neutro + #188, #3967
  static g_neutro + #189, #3967
  static g_neutro + #190, #3967
  static g_neutro + #191, #3967
  static g_neutro + #192, #3967
  static g_neutro + #193, #3967
  static g_neutro + #194, #3967
  static g_neutro + #195, #3967
  static g_neutro + #196, #3967
  static g_neutro + #197, #3967
  static g_neutro + #198, #3967
  static g_neutro + #199, #3967

  ;Linha 5
  static g_neutro + #200, #3967
  static g_neutro + #201, #3967
  static g_neutro + #202, #3967
  static g_neutro + #203, #3967
  static g_neutro + #204, #3967
  static g_neutro + #205, #3967
  static g_neutro + #206, #3967
  static g_neutro + #207, #3967
  static g_neutro + #208, #3967
  static g_neutro + #209, #3967
  static g_neutro + #210, #3967
  static g_neutro + #211, #3967
  static g_neutro + #212, #3967
  static g_neutro + #213, #3967
  static g_neutro + #214, #3967
  static g_neutro + #215, #3967
  static g_neutro + #216, #3967
  static g_neutro + #217, #3967
  static g_neutro + #218, #3967
  static g_neutro + #219, #32
  static g_neutro + #220, #32
  static g_neutro + #221, #3967
  static g_neutro + #222, #3967
  static g_neutro + #223, #3967
  static g_neutro + #224, #3967
  static g_neutro + #225, #3967
  static g_neutro + #226, #3967
  static g_neutro + #227, #3967
  static g_neutro + #228, #3967
  static g_neutro + #229, #3967
  static g_neutro + #230, #3967
  static g_neutro + #231, #3967
  static g_neutro + #232, #3967
  static g_neutro + #233, #3967
  static g_neutro + #234, #3967
  static g_neutro + #235, #3967
  static g_neutro + #236, #3967
  static g_neutro + #237, #3967
  static g_neutro + #238, #3967
  static g_neutro + #239, #3967

  ;Linha 6
  static g_neutro + #240, #3967
  static g_neutro + #241, #3967
  static g_neutro + #242, #3967
  static g_neutro + #243, #3967
  static g_neutro + #244, #3967
  static g_neutro + #245, #3967
  static g_neutro + #246, #3967
  static g_neutro + #247, #3967
  static g_neutro + #248, #3967
  static g_neutro + #249, #3967
  static g_neutro + #250, #3967
  static g_neutro + #251, #3967
  static g_neutro + #252, #3967
  static g_neutro + #253, #3967
  static g_neutro + #254, #3967
  static g_neutro + #255, #3967
  static g_neutro + #256, #3967
  static g_neutro + #257, #0
  static g_neutro + #258, #0
  static g_neutro + #259, #0
  static g_neutro + #260, #0
  static g_neutro + #261, #0
  static g_neutro + #262, #0
  static g_neutro + #263, #0
  static g_neutro + #264, #32
  static g_neutro + #265, #3967
  static g_neutro + #266, #3967
  static g_neutro + #267, #3967
  static g_neutro + #268, #3967
  static g_neutro + #269, #3967
  static g_neutro + #270, #3967
  static g_neutro + #271, #3967
  static g_neutro + #272, #3967
  static g_neutro + #273, #3967
  static g_neutro + #274, #3967
  static g_neutro + #275, #3967
  static g_neutro + #276, #3967
  static g_neutro + #277, #3967
  static g_neutro + #278, #3967
  static g_neutro + #279, #3967

  ;Linha 7
  static g_neutro + #280, #3967
  static g_neutro + #281, #3967
  static g_neutro + #282, #3967
  static g_neutro + #283, #3967
  static g_neutro + #284, #3967
  static g_neutro + #285, #3967
  static g_neutro + #286, #3967
  static g_neutro + #287, #3967
  static g_neutro + #288, #3967
  static g_neutro + #289, #3967
  static g_neutro + #290, #3967
  static g_neutro + #291, #3967
  static g_neutro + #292, #3967
  static g_neutro + #293, #3967
  static g_neutro + #294, #3967
  static g_neutro + #295, #0
  static g_neutro + #296, #0
  static g_neutro + #297, #2048
  static g_neutro + #298, #2048
  static g_neutro + #299, #2048
  static g_neutro + #300, #0
  static g_neutro + #301, #2048
  static g_neutro + #302, #2048
  static g_neutro + #303, #2048
  static g_neutro + #304, #0
  static g_neutro + #305, #0
  static g_neutro + #306, #3967
  static g_neutro + #307, #3967
  static g_neutro + #308, #3967
  static g_neutro + #309, #3967
  static g_neutro + #310, #3967
  static g_neutro + #311, #3967
  static g_neutro + #312, #3967
  static g_neutro + #313, #3967
  static g_neutro + #314, #3967
  static g_neutro + #315, #3967
  static g_neutro + #316, #3967
  static g_neutro + #317, #3967
  static g_neutro + #318, #3967
  static g_neutro + #319, #3967

  ;Linha 8
  static g_neutro + #320, #3967
  static g_neutro + #321, #3967
  static g_neutro + #322, #3967
  static g_neutro + #323, #3967
  static g_neutro + #324, #3967
  static g_neutro + #325, #3967
  static g_neutro + #326, #3967
  static g_neutro + #327, #3967
  static g_neutro + #328, #3967
  static g_neutro + #329, #3967
  static g_neutro + #330, #3967
  static g_neutro + #331, #3967
  static g_neutro + #332, #3967
  static g_neutro + #333, #0
  static g_neutro + #334, #0
  static g_neutro + #335, #2048
  static g_neutro + #336, #2048
  static g_neutro + #337, #2048
  static g_neutro + #338, #2048
  static g_neutro + #339, #2048
  static g_neutro + #340, #0
  static g_neutro + #341, #2048
  static g_neutro + #342, #2048
  static g_neutro + #343, #2048
  static g_neutro + #344, #2048
  static g_neutro + #345, #2048
  static g_neutro + #346, #0
  static g_neutro + #347, #0
  static g_neutro + #348, #3967
  static g_neutro + #349, #3967
  static g_neutro + #350, #3967
  static g_neutro + #351, #3967
  static g_neutro + #352, #3967
  static g_neutro + #353, #3967
  static g_neutro + #354, #3967
  static g_neutro + #355, #3967
  static g_neutro + #356, #3967
  static g_neutro + #357, #3967
  static g_neutro + #358, #3967
  static g_neutro + #359, #3967

  ;Linha 9
  static g_neutro + #360, #3967
  static g_neutro + #361, #3967
  static g_neutro + #362, #3967
  static g_neutro + #363, #3967
  static g_neutro + #364, #3967
  static g_neutro + #365, #3967
  static g_neutro + #366, #3967
  static g_neutro + #367, #3967
  static g_neutro + #368, #3967
  static g_neutro + #369, #3967
  static g_neutro + #370, #3967
  static g_neutro + #371, #3967
  static g_neutro + #372, #0
  static g_neutro + #373, #2048
  static g_neutro + #374, #2048
  static g_neutro + #375, #2048
  static g_neutro + #376, #2048
  static g_neutro + #377, #2048
  static g_neutro + #378, #2048
  static g_neutro + #379, #2048
  static g_neutro + #380, #0
  static g_neutro + #381, #2048
  static g_neutro + #382, #2048
  static g_neutro + #383, #2048
  static g_neutro + #384, #2048
  static g_neutro + #385, #2048
  static g_neutro + #386, #2048
  static g_neutro + #387, #2048
  static g_neutro + #388, #0
  static g_neutro + #389, #3967
  static g_neutro + #390, #3967
  static g_neutro + #391, #3967
  static g_neutro + #392, #3967
  static g_neutro + #393, #3967
  static g_neutro + #394, #3967
  static g_neutro + #395, #3967
  static g_neutro + #396, #3967
  static g_neutro + #397, #3967
  static g_neutro + #398, #3967
  static g_neutro + #399, #3967

  ;Linha 10
  static g_neutro + #400, #3967
  static g_neutro + #401, #3967
  static g_neutro + #402, #3967
  static g_neutro + #403, #3967
  static g_neutro + #404, #3967
  static g_neutro + #405, #3967
  static g_neutro + #406, #3967
  static g_neutro + #407, #3967
  static g_neutro + #408, #3967
  static g_neutro + #409, #3967
  static g_neutro + #410, #3967
  static g_neutro + #411, #3967
  static g_neutro + #412, #0
  static g_neutro + #413, #2048
  static g_neutro + #414, #2048
  static g_neutro + #415, #2048
  static g_neutro + #416, #2048
  static g_neutro + #417, #2048
  static g_neutro + #418, #2048
  static g_neutro + #419, #2048
  static g_neutro + #420, #0
  static g_neutro + #421, #2048
  static g_neutro + #422, #2048
  static g_neutro + #423, #2048
  static g_neutro + #424, #2048
  static g_neutro + #425, #2048
  static g_neutro + #426, #2048
  static g_neutro + #427, #2048
  static g_neutro + #428, #0
  static g_neutro + #429, #3967
  static g_neutro + #430, #3967
  static g_neutro + #431, #3967
  static g_neutro + #432, #3967
  static g_neutro + #433, #3967
  static g_neutro + #434, #3967
  static g_neutro + #435, #3967
  static g_neutro + #436, #3967
  static g_neutro + #437, #3967
  static g_neutro + #438, #3967
  static g_neutro + #439, #3967

  ;Linha 11
  static g_neutro + #440, #3967
  static g_neutro + #441, #3967
  static g_neutro + #442, #3967
  static g_neutro + #443, #3967
  static g_neutro + #444, #3967
  static g_neutro + #445, #3967
  static g_neutro + #446, #3967
  static g_neutro + #447, #3967
  static g_neutro + #448, #3967
  static g_neutro + #449, #3967
  static g_neutro + #450, #3967
  static g_neutro + #451, #3967
  static g_neutro + #452, #0
  static g_neutro + #453, #2048
  static g_neutro + #454, #2048
  static g_neutro + #455, #2048
  static g_neutro + #456, #2048
  static g_neutro + #457, #2048
  static g_neutro + #458, #0
  static g_neutro + #459, #0
  static g_neutro + #460, #0
  static g_neutro + #461, #0
  static g_neutro + #462, #0
  static g_neutro + #463, #2048
  static g_neutro + #464, #2048
  static g_neutro + #465, #2048
  static g_neutro + #466, #2048
  static g_neutro + #467, #2048
  static g_neutro + #468, #0
  static g_neutro + #469, #3967
  static g_neutro + #470, #3967
  static g_neutro + #471, #3967
  static g_neutro + #472, #3967
  static g_neutro + #473, #3967
  static g_neutro + #474, #3967
  static g_neutro + #475, #3967
  static g_neutro + #476, #3967
  static g_neutro + #477, #3967
  static g_neutro + #478, #3967
  static g_neutro + #479, #3967

  ;Linha 12
  static g_neutro + #480, #3967
  static g_neutro + #481, #3967
  static g_neutro + #482, #3967
  static g_neutro + #483, #3967
  static g_neutro + #484, #3967
  static g_neutro + #485, #3967
  static g_neutro + #486, #3967
  static g_neutro + #487, #3967
  static g_neutro + #488, #3967
  static g_neutro + #489, #3967
  static g_neutro + #490, #3967
  static g_neutro + #491, #0
  static g_neutro + #492, #2048
  static g_neutro + #493, #2048
  static g_neutro + #494, #2048
  static g_neutro + #495, #2048
  static g_neutro + #496, #2048
  static g_neutro + #497, #0
  static g_neutro + #498, #32
  static g_neutro + #499, #32
  static g_neutro + #500, #3967
  static g_neutro + #501, #3967
  static g_neutro + #502, #32
  static g_neutro + #503, #0
  static g_neutro + #504, #2048
  static g_neutro + #505, #2048
  static g_neutro + #506, #2048
  static g_neutro + #507, #2048
  static g_neutro + #508, #2048
  static g_neutro + #509, #0
  static g_neutro + #510, #3967
  static g_neutro + #511, #3967
  static g_neutro + #512, #3967
  static g_neutro + #513, #3967
  static g_neutro + #514, #3967
  static g_neutro + #515, #3967
  static g_neutro + #516, #3967
  static g_neutro + #517, #3967
  static g_neutro + #518, #3967
  static g_neutro + #519, #3967

  ;Linha 13
  static g_neutro + #520, #3967
  static g_neutro + #521, #3967
  static g_neutro + #522, #3967
  static g_neutro + #523, #3967
  static g_neutro + #524, #3967
  static g_neutro + #525, #3967
  static g_neutro + #526, #3967
  static g_neutro + #527, #3967
  static g_neutro + #528, #3967
  static g_neutro + #529, #3967
  static g_neutro + #530, #3967
  static g_neutro + #531, #0
  static g_neutro + #532, #2048
  static g_neutro + #533, #2048
  static g_neutro + #534, #2048
  static g_neutro + #535, #2048
  static g_neutro + #536, #0
  static g_neutro + #537, #3967
  static g_neutro + #538, #32
  static g_neutro + #539, #3967
  static g_neutro + #540, #3967
  static g_neutro + #541, #3967
  static g_neutro + #542, #32
  static g_neutro + #543, #32
  static g_neutro + #544, #0
  static g_neutro + #545, #2048
  static g_neutro + #546, #2048
  static g_neutro + #547, #2048
  static g_neutro + #548, #2048
  static g_neutro + #549, #0
  static g_neutro + #550, #3967
  static g_neutro + #551, #3967
  static g_neutro + #552, #3967
  static g_neutro + #553, #3967
  static g_neutro + #554, #3967
  static g_neutro + #555, #3967
  static g_neutro + #556, #3967
  static g_neutro + #557, #3967
  static g_neutro + #558, #3967
  static g_neutro + #559, #3967

  ;Linha 14
  static g_neutro + #560, #3967
  static g_neutro + #561, #3967
  static g_neutro + #562, #3967
  static g_neutro + #563, #3967
  static g_neutro + #564, #3967
  static g_neutro + #565, #3967
  static g_neutro + #566, #3967
  static g_neutro + #567, #3967
  static g_neutro + #568, #3967
  static g_neutro + #569, #3967
  static g_neutro + #570, #32
  static g_neutro + #571, #0
  static g_neutro + #572, #2048
  static g_neutro + #573, #2048
  static g_neutro + #574, #2048
  static g_neutro + #575, #2048
  static g_neutro + #576, #0
  static g_neutro + #577, #3967
  static g_neutro + #578, #2174
  static g_neutro + #579, #2174
  static g_neutro + #580, #3967
  static g_neutro + #581, #2174
  static g_neutro + #582, #2174
  static g_neutro + #583, #32
  static g_neutro + #584, #0
  static g_neutro + #585, #2048
  static g_neutro + #586, #2048
  static g_neutro + #587, #2048
  static g_neutro + #588, #2048
  static g_neutro + #589, #0
  static g_neutro + #590, #3967
  static g_neutro + #591, #3967
  static g_neutro + #592, #3967
  static g_neutro + #593, #3967
  static g_neutro + #594, #3967
  static g_neutro + #595, #3967
  static g_neutro + #596, #3967
  static g_neutro + #597, #3967
  static g_neutro + #598, #3967
  static g_neutro + #599, #3967

  ;Linha 15
  static g_neutro + #600, #3967
  static g_neutro + #601, #3967
  static g_neutro + #602, #3967
  static g_neutro + #603, #3967
  static g_neutro + #604, #3967
  static g_neutro + #605, #3967
  static g_neutro + #606, #3967
  static g_neutro + #607, #3967
  static g_neutro + #608, #3967
  static g_neutro + #609, #3967
  static g_neutro + #610, #32
  static g_neutro + #611, #0
  static g_neutro + #612, #0
  static g_neutro + #613, #0
  static g_neutro + #614, #0
  static g_neutro + #615, #0
  static g_neutro + #616, #0
  static g_neutro + #617, #32
  static g_neutro + #618, #32
  static g_neutro + #619, #32
  static g_neutro + #620, #32
  static g_neutro + #621, #32
  static g_neutro + #622, #32
  static g_neutro + #623, #32
  static g_neutro + #624, #0
  static g_neutro + #625, #0
  static g_neutro + #626, #0
  static g_neutro + #627, #0
  static g_neutro + #628, #0
  static g_neutro + #629, #0
  static g_neutro + #630, #32
  static g_neutro + #631, #3967
  static g_neutro + #632, #3967
  static g_neutro + #633, #3967
  static g_neutro + #634, #3967
  static g_neutro + #635, #3967
  static g_neutro + #636, #3967
  static g_neutro + #637, #3967
  static g_neutro + #638, #3967
  static g_neutro + #639, #3967

  ;Linha 16
  static g_neutro + #640, #3967
  static g_neutro + #641, #3967
  static g_neutro + #642, #3967
  static g_neutro + #643, #3967
  static g_neutro + #644, #3967
  static g_neutro + #645, #3967
  static g_neutro + #646, #3967
  static g_neutro + #647, #3967
  static g_neutro + #648, #3967
  static g_neutro + #649, #3967
  static g_neutro + #650, #32
  static g_neutro + #651, #0
  static g_neutro + #652, #2048
  static g_neutro + #653, #2048
  static g_neutro + #654, #2048
  static g_neutro + #655, #2048
  static g_neutro + #656, #0
  static g_neutro + #657, #3967
  static g_neutro + #658, #2080
  static g_neutro + #659, #2143
  static g_neutro + #660, #2143
  static g_neutro + #661, #2143
  static g_neutro + #662, #32
  static g_neutro + #663, #32
  static g_neutro + #664, #0
  static g_neutro + #665, #2048
  static g_neutro + #666, #2048
  static g_neutro + #667, #2048
  static g_neutro + #668, #2048
  static g_neutro + #669, #0
  static g_neutro + #670, #32
  static g_neutro + #671, #32
  static g_neutro + #672, #3967
  static g_neutro + #673, #3967
  static g_neutro + #674, #3967
  static g_neutro + #675, #3967
  static g_neutro + #676, #3967
  static g_neutro + #677, #3967
  static g_neutro + #678, #3967
  static g_neutro + #679, #3967

  ;Linha 17
  static g_neutro + #680, #3967
  static g_neutro + #681, #3967
  static g_neutro + #682, #3967
  static g_neutro + #683, #3967
  static g_neutro + #684, #3967
  static g_neutro + #685, #3967
  static g_neutro + #686, #3967
  static g_neutro + #687, #3967
  static g_neutro + #688, #3967
  static g_neutro + #689, #3967
  static g_neutro + #690, #3967
  static g_neutro + #691, #0
  static g_neutro + #692, #2048
  static g_neutro + #693, #2048
  static g_neutro + #694, #2048
  static g_neutro + #695, #2048
  static g_neutro + #696, #0
  static g_neutro + #697, #3967
  static g_neutro + #698, #3967
  static g_neutro + #699, #3967
  static g_neutro + #700, #3967
  static g_neutro + #701, #3967
  static g_neutro + #702, #32
  static g_neutro + #703, #32
  static g_neutro + #704, #0
  static g_neutro + #705, #2048
  static g_neutro + #706, #2048
  static g_neutro + #707, #2048
  static g_neutro + #708, #2048
  static g_neutro + #709, #0
  static g_neutro + #710, #3967
  static g_neutro + #711, #3967
  static g_neutro + #712, #3967
  static g_neutro + #713, #3967
  static g_neutro + #714, #3967
  static g_neutro + #715, #3967
  static g_neutro + #716, #3967
  static g_neutro + #717, #3967
  static g_neutro + #718, #3967
  static g_neutro + #719, #3967

  ;Linha 18
  static g_neutro + #720, #3967
  static g_neutro + #721, #3967
  static g_neutro + #722, #3967
  static g_neutro + #723, #3967
  static g_neutro + #724, #3967
  static g_neutro + #725, #3967
  static g_neutro + #726, #3967
  static g_neutro + #727, #3967
  static g_neutro + #728, #3967
  static g_neutro + #729, #3967
  static g_neutro + #730, #3967
  static g_neutro + #731, #0
  static g_neutro + #732, #2048
  static g_neutro + #733, #2048
  static g_neutro + #734, #2048
  static g_neutro + #735, #2048
  static g_neutro + #736, #2048
  static g_neutro + #737, #0
  static g_neutro + #738, #3967
  static g_neutro + #739, #3967
  static g_neutro + #740, #3967
  static g_neutro + #741, #3967
  static g_neutro + #742, #32
  static g_neutro + #743, #0
  static g_neutro + #744, #2048
  static g_neutro + #745, #2048
  static g_neutro + #746, #2048
  static g_neutro + #747, #2048
  static g_neutro + #748, #2048
  static g_neutro + #749, #0
  static g_neutro + #750, #3967
  static g_neutro + #751, #3967
  static g_neutro + #752, #3967
  static g_neutro + #753, #3967
  static g_neutro + #754, #3967
  static g_neutro + #755, #3967
  static g_neutro + #756, #3967
  static g_neutro + #757, #3967
  static g_neutro + #758, #3967
  static g_neutro + #759, #3967

  ;Linha 19
  static g_neutro + #760, #3967
  static g_neutro + #761, #3967
  static g_neutro + #762, #3967
  static g_neutro + #763, #3967
  static g_neutro + #764, #3967
  static g_neutro + #765, #3967
  static g_neutro + #766, #3967
  static g_neutro + #767, #3967
  static g_neutro + #768, #3967
  static g_neutro + #769, #3967
  static g_neutro + #770, #3967
  static g_neutro + #771, #3967
  static g_neutro + #772, #0
  static g_neutro + #773, #2048
  static g_neutro + #774, #2048
  static g_neutro + #775, #2048
  static g_neutro + #776, #2048
  static g_neutro + #777, #2048
  static g_neutro + #778, #0
  static g_neutro + #779, #0
  static g_neutro + #780, #0
  static g_neutro + #781, #0
  static g_neutro + #782, #0
  static g_neutro + #783, #2048
  static g_neutro + #784, #2048
  static g_neutro + #785, #2048
  static g_neutro + #786, #2048
  static g_neutro + #787, #2048
  static g_neutro + #788, #0
  static g_neutro + #789, #3967
  static g_neutro + #790, #3967
  static g_neutro + #791, #3967
  static g_neutro + #792, #3967
  static g_neutro + #793, #3967
  static g_neutro + #794, #3967
  static g_neutro + #795, #3967
  static g_neutro + #796, #3967
  static g_neutro + #797, #3967
  static g_neutro + #798, #3967
  static g_neutro + #799, #3967

  ;Linha 20
  static g_neutro + #800, #3967
  static g_neutro + #801, #3967
  static g_neutro + #802, #3967
  static g_neutro + #803, #3967
  static g_neutro + #804, #3967
  static g_neutro + #805, #3967
  static g_neutro + #806, #3967
  static g_neutro + #807, #3967
  static g_neutro + #808, #3967
  static g_neutro + #809, #3967
  static g_neutro + #810, #3967
  static g_neutro + #811, #3967
  static g_neutro + #812, #0
  static g_neutro + #813, #2048
  static g_neutro + #814, #2048
  static g_neutro + #815, #2048
  static g_neutro + #816, #2048
  static g_neutro + #817, #2048
  static g_neutro + #818, #2048
  static g_neutro + #819, #2048
  static g_neutro + #820, #0
  static g_neutro + #821, #2048
  static g_neutro + #822, #2048
  static g_neutro + #823, #2048
  static g_neutro + #824, #2048
  static g_neutro + #825, #2048
  static g_neutro + #826, #2048
  static g_neutro + #827, #2048
  static g_neutro + #828, #0
  static g_neutro + #829, #3967
  static g_neutro + #830, #3967
  static g_neutro + #831, #3967
  static g_neutro + #832, #3967
  static g_neutro + #833, #3967
  static g_neutro + #834, #3967
  static g_neutro + #835, #3967
  static g_neutro + #836, #3967
  static g_neutro + #837, #3967
  static g_neutro + #838, #3967
  static g_neutro + #839, #3967

  ;Linha 21
  static g_neutro + #840, #3967
  static g_neutro + #841, #3967
  static g_neutro + #842, #3967
  static g_neutro + #843, #3967
  static g_neutro + #844, #3967
  static g_neutro + #845, #3967
  static g_neutro + #846, #3967
  static g_neutro + #847, #3967
  static g_neutro + #848, #3967
  static g_neutro + #849, #3967
  static g_neutro + #850, #3967
  static g_neutro + #851, #3967
  static g_neutro + #852, #0
  static g_neutro + #853, #2048
  static g_neutro + #854, #2048
  static g_neutro + #855, #2048
  static g_neutro + #856, #2048
  static g_neutro + #857, #2048
  static g_neutro + #858, #2048
  static g_neutro + #859, #2048
  static g_neutro + #860, #0
  static g_neutro + #861, #2048
  static g_neutro + #862, #2048
  static g_neutro + #863, #2048
  static g_neutro + #864, #2048
  static g_neutro + #865, #2048
  static g_neutro + #866, #2048
  static g_neutro + #867, #2048
  static g_neutro + #868, #0
  static g_neutro + #869, #3967
  static g_neutro + #870, #3967
  static g_neutro + #871, #3967
  static g_neutro + #872, #3967
  static g_neutro + #873, #3967
  static g_neutro + #874, #3967
  static g_neutro + #875, #3967
  static g_neutro + #876, #3967
  static g_neutro + #877, #3967
  static g_neutro + #878, #3967
  static g_neutro + #879, #3967

  ;Linha 22
  static g_neutro + #880, #3967
  static g_neutro + #881, #3967
  static g_neutro + #882, #3967
  static g_neutro + #883, #3967
  static g_neutro + #884, #3967
  static g_neutro + #885, #3967
  static g_neutro + #886, #3967
  static g_neutro + #887, #3967
  static g_neutro + #888, #3967
  static g_neutro + #889, #3967
  static g_neutro + #890, #3967
  static g_neutro + #891, #3967
  static g_neutro + #892, #3967
  static g_neutro + #893, #0
  static g_neutro + #894, #0
  static g_neutro + #895, #2048
  static g_neutro + #896, #2048
  static g_neutro + #897, #2048
  static g_neutro + #898, #2048
  static g_neutro + #899, #2048
  static g_neutro + #900, #0
  static g_neutro + #901, #2048
  static g_neutro + #902, #2048
  static g_neutro + #903, #2048
  static g_neutro + #904, #2048
  static g_neutro + #905, #2048
  static g_neutro + #906, #0
  static g_neutro + #907, #0
  static g_neutro + #908, #3967
  static g_neutro + #909, #3967
  static g_neutro + #910, #3967
  static g_neutro + #911, #3967
  static g_neutro + #912, #3967
  static g_neutro + #913, #3967
  static g_neutro + #914, #3967
  static g_neutro + #915, #3967
  static g_neutro + #916, #3967
  static g_neutro + #917, #3967
  static g_neutro + #918, #3967
  static g_neutro + #919, #3967

  ;Linha 23
  static g_neutro + #920, #3967
  static g_neutro + #921, #3967
  static g_neutro + #922, #3967
  static g_neutro + #923, #3967
  static g_neutro + #924, #3967
  static g_neutro + #925, #3967
  static g_neutro + #926, #3967
  static g_neutro + #927, #3967
  static g_neutro + #928, #3967
  static g_neutro + #929, #3967
  static g_neutro + #930, #3967
  static g_neutro + #931, #3967
  static g_neutro + #932, #3967
  static g_neutro + #933, #3967
  static g_neutro + #934, #3967
  static g_neutro + #935, #0
  static g_neutro + #936, #0
  static g_neutro + #937, #2048
  static g_neutro + #938, #2048
  static g_neutro + #939, #2048
  static g_neutro + #940, #0
  static g_neutro + #941, #2048
  static g_neutro + #942, #2048
  static g_neutro + #943, #2048
  static g_neutro + #944, #0
  static g_neutro + #945, #0
  static g_neutro + #946, #3967
  static g_neutro + #947, #3967
  static g_neutro + #948, #3967
  static g_neutro + #949, #3967
  static g_neutro + #950, #3967
  static g_neutro + #951, #3967
  static g_neutro + #952, #3967
  static g_neutro + #953, #3967
  static g_neutro + #954, #3967
  static g_neutro + #955, #3967
  static g_neutro + #956, #3967
  static g_neutro + #957, #3967
  static g_neutro + #958, #3967
  static g_neutro + #959, #3967

  ;Linha 24
  static g_neutro + #960, #3967
  static g_neutro + #961, #3967
  static g_neutro + #962, #3967
  static g_neutro + #963, #3967
  static g_neutro + #964, #3967
  static g_neutro + #965, #3967
  static g_neutro + #966, #3967
  static g_neutro + #967, #3967
  static g_neutro + #968, #3967
  static g_neutro + #969, #3967
  static g_neutro + #970, #3967
  static g_neutro + #971, #3967
  static g_neutro + #972, #3967
  static g_neutro + #973, #3967
  static g_neutro + #974, #3967
  static g_neutro + #975, #3967
  static g_neutro + #976, #3967
  static g_neutro + #977, #0
  static g_neutro + #978, #0
  static g_neutro + #979, #0
  static g_neutro + #980, #0
  static g_neutro + #981, #0
  static g_neutro + #982, #0
  static g_neutro + #983, #0
  static g_neutro + #984, #3967
  static g_neutro + #985, #3967
  static g_neutro + #986, #3967
  static g_neutro + #987, #3967
  static g_neutro + #988, #3967
  static g_neutro + #989, #3967
  static g_neutro + #990, #3967
  static g_neutro + #991, #3967
  static g_neutro + #992, #3967
  static g_neutro + #993, #3967
  static g_neutro + #994, #3967
  static g_neutro + #995, #3967
  static g_neutro + #996, #3967
  static g_neutro + #997, #3967
  static g_neutro + #998, #3967
  static g_neutro + #999, #3967

  ;Linha 25
  static g_neutro + #1000, #3967
  static g_neutro + #1001, #3967
  static g_neutro + #1002, #3967
  static g_neutro + #1003, #3967
  static g_neutro + #1004, #3967
  static g_neutro + #1005, #3967
  static g_neutro + #1006, #3967
  static g_neutro + #1007, #3967
  static g_neutro + #1008, #3967
  static g_neutro + #1009, #3967
  static g_neutro + #1010, #3967
  static g_neutro + #1011, #3967
  static g_neutro + #1012, #3967
  static g_neutro + #1013, #3967
  static g_neutro + #1014, #3967
  static g_neutro + #1015, #3967
  static g_neutro + #1016, #3967
  static g_neutro + #1017, #3967
  static g_neutro + #1018, #3967
  static g_neutro + #1019, #32
  static g_neutro + #1020, #3967
  static g_neutro + #1021, #3967
  static g_neutro + #1022, #3967
  static g_neutro + #1023, #3967
  static g_neutro + #1024, #3967
  static g_neutro + #1025, #3967
  static g_neutro + #1026, #3967
  static g_neutro + #1027, #3967
  static g_neutro + #1028, #3967
  static g_neutro + #1029, #3967
  static g_neutro + #1030, #3967
  static g_neutro + #1031, #3967
  static g_neutro + #1032, #3967
  static g_neutro + #1033, #3967
  static g_neutro + #1034, #3967
  static g_neutro + #1035, #3967
  static g_neutro + #1036, #3967
  static g_neutro + #1037, #3967
  static g_neutro + #1038, #3967
  static g_neutro + #1039, #3967

  ;Linha 26
  static g_neutro + #1040, #3967
  static g_neutro + #1041, #3967
  static g_neutro + #1042, #3967
  static g_neutro + #1043, #3967
  static g_neutro + #1044, #3967
  static g_neutro + #1045, #3967
  static g_neutro + #1046, #3967
  static g_neutro + #1047, #3967
  static g_neutro + #1048, #3967
  static g_neutro + #1049, #3967
  static g_neutro + #1050, #3967
  static g_neutro + #1051, #3967
  static g_neutro + #1052, #3967
  static g_neutro + #1053, #3967
  static g_neutro + #1054, #3967
  static g_neutro + #1055, #3967
  static g_neutro + #1056, #3967
  static g_neutro + #1057, #3967
  static g_neutro + #1058, #3967
  static g_neutro + #1059, #3967
  static g_neutro + #1060, #3967
  static g_neutro + #1061, #3967
  static g_neutro + #1062, #3967
  static g_neutro + #1063, #3967
  static g_neutro + #1064, #3967
  static g_neutro + #1065, #3967
  static g_neutro + #1066, #3967
  static g_neutro + #1067, #3967
  static g_neutro + #1068, #3967
  static g_neutro + #1069, #3967
  static g_neutro + #1070, #3967
  static g_neutro + #1071, #3967
  static g_neutro + #1072, #3967
  static g_neutro + #1073, #3967
  static g_neutro + #1074, #3967
  static g_neutro + #1075, #3967
  static g_neutro + #1076, #3967
  static g_neutro + #1077, #3967
  static g_neutro + #1078, #3967
  static g_neutro + #1079, #3967

  ;Linha 27
  static g_neutro + #1080, #3967
  static g_neutro + #1081, #3967
  static g_neutro + #1082, #3967
  static g_neutro + #1083, #3967
  static g_neutro + #1084, #3967
  static g_neutro + #1085, #3967
  static g_neutro + #1086, #3967
  static g_neutro + #1087, #3967
  static g_neutro + #1088, #3967
  static g_neutro + #1089, #3967
  static g_neutro + #1090, #3967
  static g_neutro + #1091, #3967
  static g_neutro + #1092, #3967
  static g_neutro + #1093, #3967
  static g_neutro + #1094, #3967
  static g_neutro + #1095, #3967
  static g_neutro + #1096, #3967
  static g_neutro + #1097, #3967
  static g_neutro + #1098, #3967
  static g_neutro + #1099, #3967
  static g_neutro + #1100, #3967
  static g_neutro + #1101, #3967
  static g_neutro + #1102, #3967
  static g_neutro + #1103, #3967
  static g_neutro + #1104, #3967
  static g_neutro + #1105, #3967
  static g_neutro + #1106, #3967
  static g_neutro + #1107, #3967
  static g_neutro + #1108, #3967
  static g_neutro + #1109, #3967
  static g_neutro + #1110, #3967
  static g_neutro + #1111, #3967
  static g_neutro + #1112, #3967
  static g_neutro + #1113, #3967
  static g_neutro + #1114, #3967
  static g_neutro + #1115, #3967
  static g_neutro + #1116, #3967
  static g_neutro + #1117, #3967
  static g_neutro + #1118, #3967
  static g_neutro + #1119, #3967

  ;Linha 28
  static g_neutro + #1120, #3967
  static g_neutro + #1121, #3967
  static g_neutro + #1122, #3967
  static g_neutro + #1123, #3967
  static g_neutro + #1124, #3967
  static g_neutro + #1125, #3967
  static g_neutro + #1126, #3967
  static g_neutro + #1127, #3967
  static g_neutro + #1128, #3967
  static g_neutro + #1129, #3967
  static g_neutro + #1130, #3967
  static g_neutro + #1131, #3967
  static g_neutro + #1132, #3967
  static g_neutro + #1133, #3967
  static g_neutro + #1134, #3967
  static g_neutro + #1135, #3967
  static g_neutro + #1136, #3967
  static g_neutro + #1137, #3967
  static g_neutro + #1138, #3967
  static g_neutro + #1139, #3967
  static g_neutro + #1140, #3967
  static g_neutro + #1141, #3967
  static g_neutro + #1142, #3967
  static g_neutro + #1143, #3967
  static g_neutro + #1144, #3967
  static g_neutro + #1145, #3967
  static g_neutro + #1146, #3967
  static g_neutro + #1147, #3967
  static g_neutro + #1148, #3967
  static g_neutro + #1149, #3967
  static g_neutro + #1150, #3967
  static g_neutro + #1151, #3967
  static g_neutro + #1152, #3967
  static g_neutro + #1153, #3967
  static g_neutro + #1154, #3967
  static g_neutro + #1155, #3967
  static g_neutro + #1156, #3967
  static g_neutro + #1157, #3967
  static g_neutro + #1158, #3967
  static g_neutro + #1159, #3967

  ;Linha 29
  static g_neutro + #1160, #3967
  static g_neutro + #1161, #3967
  static g_neutro + #1162, #3967
  static g_neutro + #1163, #3967
  static g_neutro + #1164, #3967
  static g_neutro + #1165, #3967
  static g_neutro + #1166, #3967
  static g_neutro + #1167, #3967
  static g_neutro + #1168, #3967
  static g_neutro + #1169, #3967
  static g_neutro + #1170, #3967
  static g_neutro + #1171, #3967
  static g_neutro + #1172, #3967
  static g_neutro + #1173, #3967
  static g_neutro + #1174, #3967
  static g_neutro + #1175, #3967
  static g_neutro + #1176, #3967
  static g_neutro + #1177, #3967
  static g_neutro + #1178, #3967
  static g_neutro + #1179, #3967
  static g_neutro + #1180, #3967
  static g_neutro + #1181, #3967
  static g_neutro + #1182, #3967
  static g_neutro + #1183, #3967
  static g_neutro + #1184, #3967
  static g_neutro + #1185, #3967
  static g_neutro + #1186, #3967
  static g_neutro + #1187, #3967
  static g_neutro + #1188, #3967
  static g_neutro + #1189, #3967
  static g_neutro + #1190, #3967
  static g_neutro + #1191, #3967
  static g_neutro + #1192, #3967
  static g_neutro + #1193, #3967
  static g_neutro + #1194, #3967
  static g_neutro + #1195, #3967
  static g_neutro + #1196, #3967
  static g_neutro + #1197, #3967
  static g_neutro + #1198, #3967
  static g_neutro + #1199, #3967


;========Variáveis do Jogo==========

fase: var #1
tamanho_seq: var #1
indice: var #1
semente: var #1
resposta_certa: var #1
; Cada valor da sequencia representa uma cor:
; 1 = verde
; 2 = vermelho
; 3 = azul
; 4 = amarelo

sequencia: var #17 ;vão existir 15 fases


;--------------Inicio Programa Main------
main:
    loadn r0, #1
    store fase, r0
    rand r1
    rand r2
    MUL r1, r1, r2
    ;loadn r1, #4
    store semente, r1

    call print_TelaInicial

aperta_space:
    inchar r1
    loadn r2, #' '
    cmp r1, r2
    jne aperta_space

roda_fase:
    call ApagaTela

    ; Gera a sequencia
    call gerar_sequencia

    ; Mostra as cores geradas
    call mostrar_sequencia

    ; Espera o jogador digitar
    call receber_resposta

    ; Informa se acertou ou errou
    call verificar_resposta

    ; A continuacao do jogo sera implementada
    ; pela colega, utilizando resposta_certa.

    halt

nova_fase:
  load r0, fase
    inc r0
    store fase, r0 ;indo para a próxima fase
    
    loadn r7, #16 
    cmp r7, r0 ;ve se ja foram as 15 fases
    jne roda_fase
 
 halt 
  
;---------------Subrotinas---------------


receber_resposta:
    push r0
    push r1
    push r2
    push r3
    push r4

    loadn r0, #0       ; indice
    loadn r4, #1       ; inicialmente considera correto

receber_loop:

    ; Verifica se recebeu todas as cores
    load r1, tamanho_seq
    cmp r0, r1
    jeq fim_resposta

    ; Espera uma tecla
    inchar r2

    ; Tecla 1 = Verde
    loadn r1, #'1'
    cmp r2, r1
    jeq entrada_verde

    ; Tecla 2 = Vermelho
    loadn r1, #'2'
    cmp r2, r1
    jeq entrada_vermelho

    ; Tecla 3 = Azul
    loadn r1, #'3'
    cmp r2, r1
    jeq entrada_azul

    ; Tecla 4 = Amarelo
    loadn r1, #'4'
    cmp r2, r1
    jeq entrada_amarelo

    ; Ignora teclas invalidas
    jmp receber_loop


entrada_verde:
    loadn r3, #1
    call printVerde
    jmp comparar_entrada

entrada_vermelho:
    loadn r3, #2
    call printVermelho
    jmp comparar_entrada

entrada_azul:
    loadn r3, #3
    call printAzul
    jmp comparar_entrada

entrada_amarelo:
    loadn r3, #4
    call printAmarelo
    jmp comparar_entrada


comparar_entrada:

    ; Busca a cor esperada no vetor
    loadn r1, #sequencia
    add r1, r1, r0
    loadi r2, r1

    ; Compara com a cor digitada
    cmp r2, r3
    jne resposta_errada

    jmp continuar_resposta

resposta_errada:
    loadn r4, #0

continuar_resposta:

    ; Pequena pausa para visualizar a cor
    call delay
    call printNeutro
    call delay

    ; Proxima posicao
    inc r0
    jmp receber_loop


fim_resposta:
    store resposta_certa, r4

    pop r4
    pop r3
    pop r2
    pop r1
    pop r0

    rts
  
verificar_resposta:
    push r0
    push r1

    load r0, resposta_certa
    loadn r1, #1
    cmp r0, r1
    jeq resultado_acerto

    jmp resultado_erro


resultado_acerto:
    loadn r1, #576

    loadn r0, #'A'
    outchar r0, r1
    inc r1
    loadn r0, #'C'
    outchar r0, r1
    inc r1
    loadn r0, #'E'
    outchar r0, r1
    inc r1
    loadn r0, #'R'
    outchar r0, r1
    inc r1
    loadn r0, #'T'
    outchar r0, r1
    inc r1
    loadn r0, #'O'
    outchar r0, r1
    inc r1
    loadn r0, #'U'
    outchar r0, r1
    inc r1
    loadn r0, #'!'
    outchar r0, r1

    jmp fim_verificacao


resultado_erro:
    loadn r1, #577

    loadn r0, #'E'
    outchar r0, r1
    inc r1
    loadn r0, #'R'
    outchar r0, r1
    inc r1
    loadn r0, #'R'
    outchar r0, r1
    inc r1
    loadn r0, #'O'
    outchar r0, r1
    inc r1
    loadn r0, #'U'
    outchar r0, r1
    inc r1
    loadn r0, #'!'

    outchar r0, r1

fim_verificacao:
    pop r1
    pop r0
    rts

gerar_sequencia:
  ;Calculo do tamanho da sequencia -> tamanho = fase + 2
  
  load r0, fase
  loadn r1, #2
  add r0, r0, r1
  store tamanho_seq, r0
  
  ;Define indice como 0
  loadn r0, #0
  store indice, r0
  
  push r0
    push r1 
    push r2
    push r3

gerar_loop:
    ; Verifica se ja gerou todos os valores
    load r0, indice
    load r1, tamanho_seq
    cmp r0, r1
    jeq fim_geracao

    ; X = (109 * semente + 89) mod 256
    load r0, semente
    loadn r1, #109
    mul r0, r0, r1 ;r0 *= 109
    loadn r1, #89
    add r0, r0, r1
    loadn r1, #256
    mod r0, r0, r1
    store semente, r0

    loadn r1, #64
    div r1, r0, r1 ; Converte o resultado para 0, 1, 2 ou 3
    inc r1 ; Add 1 no resultado para virar 1, 2, 3 ou 4

    
    loadn r2, #sequencia
    load r3, indice
    add r2, r2, r3 ; Somando ao endereço inicial do vetor o indice
    storei r2, r1 ; Guarda o valor na posicao indice do vetor sequencia

    ; Avanca para a proxima posicao
    inc r3
    store indice, r3

    jmp gerar_loop

fim_geracao:
    pop r3
    pop r2
    pop r1
    pop r0
rts ;nesse ponto, a sequencia ja ta salva na variavel


mostrar_sequencia:
    push r0
    push r1
    push r2
    push r3

    ; Comeca pelo indice zero
    loadn r0, #0


mostrar_loop:

    ; Verifica se ja exibiu toda a sequencia
    load r1, tamanho_seq
    cmp r0, r1
    jeq fim_mostrar

    ; Busca o valor da cor no vetor
    loadn r2, #sequencia
    add r2, r2, r0
    loadi r3, r2

    ; Verifica qual cor deve aparecer
    loadn r1, #1
    cmp r3, r1
    jeq mostrar_verde

    loadn r1, #2
    cmp r3, r1
    jeq mostrar_vermelho

    loadn r1, #3
    cmp r3, r1
    jeq mostrar_azul

    loadn r1, #4
    cmp r3, r1
    jeq mostrar_amarelo

    jmp proxima_cor

mostrar_verde:
    call printVerde
    jmp pausa_cor

mostrar_vermelho:
    call printVermelho
    jmp pausa_cor

mostrar_azul:
    call printAzul
    jmp pausa_cor

mostrar_amarelo:
    call printAmarelo
    jmp pausa_cor

; Espera e volta para tela neutra
pausa_cor:
    call delay
    call printNeutro
    call delay

proxima_cor:
    inc r0
    jmp mostrar_loop

fim_mostrar:
    pop r3
    pop r2
    pop r1
    pop r0
    rts

delay:
  push r0
  push r1
  
  loadn r0, #4000
  
delay_loop2:
  loadn r1, #3000

delay_loop1:
  dec r1
  jnz delay_loop1
  dec r0
  jnz delay_loop2
  
  pop r1
  pop r0
rts

;================Print Telas================

print_TelaInicial:
  push R0
  push R1
  push R2
  push R3

  loadn R0, #inicial_start
  loadn R1, #0
  loadn R2, #1200

  printinicial_startScreenLoop:

    add R3,R0,R1
    loadi R3, R3
    outchar R3, R1
    inc R1
    cmp R1, R2

    jne printinicial_startScreenLoop

  pop R3
  pop R2
  pop R1
  pop R0
  rts


printAmarelo:
  push R0
  push R1
  push R2
  push R3

  loadn R0, #g_amarelo
  loadn R1, #0
  loadn R2, #1200

  printg_amareloScreenLoop:

    add R3,R0,R1
    loadi R3, R3
    outchar R3, R1
    inc R1
    cmp R1, R2

    jne printg_amareloScreenLoop

  pop R3
  pop R2
  pop R1
  pop R0
  rts
  
printAzul:
  push R0
  push R1
  push R2
  push R3

  loadn R0, #g_azul
  loadn R1, #0
  loadn R2, #1200

  printg_azulScreenLoop:

    add R3,R0,R1
    loadi R3, R3
    outchar R3, R1
    inc R1
    cmp R1, R2

    jne printg_azulScreenLoop

  pop R3
  pop R2
  pop R1
  pop R0
  rts
  
printVerde:
  push R0
  push R1
  push R2
  push R3

  loadn R0, #g_verde
  loadn R1, #0
  loadn R2, #1200

  printg_verdeScreenLoop:

    add R3,R0,R1
    loadi R3, R3
    outchar R3, R1
    inc R1
    cmp R1, R2

    jne printg_verdeScreenLoop

  pop R3
  pop R2
  pop R1
  pop R0
  rts
  
printVermelho:
  push R0
  push R1
  push R2
  push R3

  loadn R0, #g_vermelho
  loadn R1, #0
  loadn R2, #1200

  printg_vermelhoScreenLoop:

    add R3,R0,R1
    loadi R3, R3
    outchar R3, R1
    inc R1
    cmp R1, R2

    jne printg_vermelhoScreenLoop

  pop R3
  pop R2
  pop R1
  pop R0
  rts
  
  
printNeutro:
  push R0
  push R1
  push R2
  push R3

  loadn R0, #g_neutro
  loadn R1, #0
  loadn R2, #1200

  printg_neutroScreenLoop:

    add R3,R0,R1
    loadi R3, R3
    outchar R3, R1
    inc R1
    cmp R1, R2

    jne printg_neutroScreenLoop

  pop R3
  pop R2
  pop R1
  pop R0
  rts
  
 ApagaTela:
  push r0
  push r1
  
  loadn r0, #1200   ; apaga as 1200 posicoes da Tela
  loadn r1, #' '    ; com "espaco"
  
     ApagaTela_Loop:  ;;label for(r0=1200;r3>0;r3--)
    dec r0
    outchar r1, r0
    jnz ApagaTela_Loop
 
  pop r1
  pop r0
rts 
  
